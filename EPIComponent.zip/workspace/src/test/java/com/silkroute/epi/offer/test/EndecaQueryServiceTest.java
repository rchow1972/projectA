package com.silkroute.epi.offer.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;

import com.endeca.navigation.ENEQuery;
import com.endeca.navigation.ENEQueryException;
import com.endeca.navigation.ENEQueryResults;
import com.endeca.navigation.ERec;
import com.endeca.navigation.ERecIdList;
import com.endeca.navigation.ERecList;
import com.endeca.navigation.PropertyMap;
import com.silkroute.epi.endeca.service.EndecaQueryService;

@ContextConfiguration(locations = { "classpath:/appContext-test-epi.xml" })
public class EndecaQueryServiceTest extends AbstractJUnit4SpringContextTests {

    @Autowired
    EndecaQueryService eneQueryService;

    @Value("${endeca.host}")
    String hostname;

    @Value("${endeca.port}")
    String port;

    @Before
    public void setUp() throws Exception {
        eneQueryService.setConnection(hostname, Integer.parseInt(port));
    }

    @Test
    public void endecaConnectTest() {
        // Shows that the autowire correctly pulled data into endeca connection

        assertEquals("mdex-es61.qa.epi.web", eneQueryService.getConnection().getHostname());
        assertEquals(16000, eneQueryService.getConnection().getPort());
    }

    @Test
    public void endecaSimpleQueryTest() {
        // Shows that connection completes.

        // "OFO0000000028RL437556RV1";
        // String endecaKey = "OF58057RL331355RV3";
        String endecaKey = "OF58057RL331355RV3";

        // ENEQuery q = eneQueryService.createSimpleQuery(endecaKey);

        ENEQuery q = new ENEQuery();
        ERecIdList list = new ERecIdList();
        list.addERecSpec(endecaKey);
        q.setERecs(list);

        try {
            PropertyMap pMap = null;
            assertNotNull(eneQueryService.getConnection());

            ENEQueryResults results = eneQueryService.getConnection().query(q);

            if (results.containsERecs()) {
                // take first one
                ERecList resultList = results.getERecs();
                ERec result = (ERec) resultList.get(0);
                pMap = result.getProperties();
            } else if (results.containsERec()) {
                // only one, take that
                ERec result = results.getERec();
                pMap = result.getProperties();
            }

            assertNotNull(pMap);

            if (pMap != null) {
                System.out.println((String) pMap.get(EndecaQueryService.PMAP_KEY_MERCHANT));
                System.out.println((String) pMap.get(EndecaQueryService.PMAP_KEY_SHORTOFFERTEXT));
                String address = ((String) pMap.get(EndecaQueryService.PMAP_KEY_ADDRESS)) + "</br>"
                        + ((String) pMap.get(EndecaQueryService.PMAP_KEY_CITY)) + ", "
                        + ((String) pMap.get(EndecaQueryService.PMAP_KEY_STATE)) + " "
                        + ((String) pMap.get(EndecaQueryService.PMAP_KEY_ZIPCODE));

                System.out.println(address);
            }
        } catch (ENEQueryException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            fail();
        }
    }

    @Test
    public void endecaKeyGenerateTest() {
        // Shows that connection completes.
        // String endecaKey = "OFO0000000028RL437556RV1";
        String genKey;
        try {
            genKey = eneQueryService.generateEndecaKeyByFields("OFO00000008HTRL398579", "398579",
                    "SHOW");
            assertEquals("OFO00000008HTRL398579RV5", genKey);

            genKey = eneQueryService
                    .generateEndecaKeyByFields("OF58057RL331355", "331355", "PRINT");
            assertEquals("OF58057RL331355RV3", genKey);

            genKey = eneQueryService.generateEndecaKeyByFields("58057", "331355", "PRINT");
            assertEquals("OF58057RL331355RV3", genKey);
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
            fail();
        }
    }

    @Test
    public void endecaKeyGenerateFailTest() {
        // Shows that connection completes.
        String genKey;
        try {
            genKey = eneQueryService.generateEndecaKeyByFields("58057", "331355", "PRINT");
            assertEquals("OF58057RL331355RV3", genKey);
            
            try {
                genKey = eneQueryService.generateEndecaKeyByFields(null, "331355", "PRINT");
                fail();
            } catch (Exception ex) {
            }

            try {
                genKey = eneQueryService.generateEndecaKeyByFields("58057", null, "PRINT");
                fail();
            } catch (Exception ex) {
            }

            try {
                genKey = eneQueryService.generateEndecaKeyByFields("58057", "331355", null);
                fail();
            } catch (Exception ex) {
            }
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
            fail();
        }
    }

    
    @Test
    public void endecaOfferQueryTest() {
        // Shows that connection completes.
        String endecaKey = "OFO00000008HTRL398579RV5";
        ENEQuery q = new ENEQuery();
        q.setERecSpec(endecaKey);

        try {
            ENEQueryResults results = eneQueryService.getConnection().query(q);
            if (results.containsERecs()) {
                ERecList recList = results.getERecs();
                System.out.println(endecaKey + ": " + recList.size() + " results");
                for (Object rec : recList) {
                    System.out.println("ERec: " + rec.toString());
                }

            }
        } catch (ENEQueryException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}

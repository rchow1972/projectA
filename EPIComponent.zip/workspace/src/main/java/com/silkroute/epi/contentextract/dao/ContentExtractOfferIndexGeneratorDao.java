package com.silkroute.epi.contentextract.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.silkroute.epi.contentextract.entity.ContentExtractOfferSectionRelationTemp;
import com.silkroute.epi.dao.GenericDao;

/**
 * Describes the database functionality necessary for Offer Index Generation
 * 
 * @author Marika Wegiel (marika.wegiel@silkrouteglobal.com)
 * 
 */
public interface ContentExtractOfferIndexGeneratorDao extends
GenericDao<ContentExtractOfferSectionRelationTemp> {

	/**
	 * Clears the temp table of existing data
	 * 
	 * @throws SQLException
	 */
	public void clearTempTable() throws SQLException;

	/**
	 * Joins the information from the temp table to other tables to obtain
	 * information not provided on the file
	 * 
	 * @param geoMarket
	 * 		The geo market ID expected for the offers
	 * @return The data returned from the SQL Statment
	 * @throws SQLException
	 */
	public List<ContentExtractOfferSectionRelationTemp> getExistingData(String geoMarket, String zipCodes) throws SQLException;

	/**
	 * Inserts records to the BOOKTABLE
	 * 
	 * @param records
	 *            The records to insert
	 * @throws SQLException
	 */
	public void insertToBook(List<Map<String, Object>> records)
			throws SQLException;

	/**
	 * Inserts records to the TEMPTABLE
	 * 
	 * @param records
	 *            The records to insert to the table
	 * @throws SQLException
	 */
	public void insertToTemp(List<Map<String, Object>> records)
			throws SQLException;

	/**
	 * Removes data from the BOOKTABLE by product ID
	 * 
	 * @param records
	 *            The records that contain product IDs
	 * @throws SQLException
	 */
	public void removeExistingProducts(List<Map<String, Object>> records)
			throws SQLException;

	/**
	 * Builds SQL statements using a map. Each record's data is contained in a
	 * map. The map key is the column name and the map value is the value to
	 * insert. This method works for a single record
	 * 
	 * @param tableName
	 * 		The table to insert the data to
	 * @param record
	 * 		A map of String column names and Object values
	 * @return
	 * 		The complete statement to execute
	 */
	String insertStatmentBuilder(String tableName,
			Map<String, Object> record);

    /**
     * Clears the entity manager persistence context, causing all managed entities to become detached.
     */
    public void clearEntityManager();
}

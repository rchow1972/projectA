package com.silkroute.epi.phase2.entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ClipCartResetPK implements Serializable {

	// NO PK On this Table - Creating an ID that is composite key

	protected String productId;
	protected String xEdition;
	
	public ClipCartResetPK() {}
	
	public ClipCartResetPK(String productId, String xEdition) {
		this.productId = productId;
		this.xEdition = xEdition;
	}
}

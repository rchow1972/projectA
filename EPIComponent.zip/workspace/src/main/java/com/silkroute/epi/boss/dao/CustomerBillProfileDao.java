package com.silkroute.epi.boss.dao;

import java.util.List;

import com.silkroute.epi.boss.entity.CustomerBillProfile;
import com.silkroute.epi.dao.GenericDao;

public interface CustomerBillProfileDao extends GenericDao<CustomerBillProfile> {

	public CustomerBillProfile findBillProfileByCustomerId(Long customerId);
	
	public List<CustomerBillProfile> findAllBillProfile();
	
}

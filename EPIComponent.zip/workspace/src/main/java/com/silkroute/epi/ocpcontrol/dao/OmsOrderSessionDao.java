package com.silkroute.epi.ocpcontrol.dao;

import java.util.List;

import com.googlecode.ehcache.annotations.Cacheable;
import com.silkroute.epi.dao.GenericDao;
import com.silkroute.epi.ocpcontrol.entity.OmsOrderSession;

public interface OmsOrderSessionDao extends GenericDao<OmsOrderSession> {

	@Cacheable(cacheName="epiadmintool")
	List<OmsOrderSession> getOrdersByGroupId(String fundraisingGroupId);
	
	List<Object[]> getOrdersByGroupIdAndStartDate(String fundraisingGroupId, String startDate);
	
	List<OmsOrderSession> getOrdersByGroupIdWithDateRange(String fundraisingGroupId, String startDate, String endDate);
}

package com.silkroute.epi.contentextract.dao;

import java.util.List;

import com.googlecode.ehcache.annotations.Cacheable;
import com.silkroute.epi.contentextract.entity.ContentExtractProduct;
import com.silkroute.epi.dao.GenericDao;

public interface ContentExtractProductDao extends
		GenericDao<ContentExtractProduct> {
	
	//@Cacheable(cacheName="epiadmintool")
	List<ContentExtractProduct> findByProductName(String name);

	//@Cacheable(cacheName="epiadmintool")
	ContentExtractProduct findByProductId(String id);
}

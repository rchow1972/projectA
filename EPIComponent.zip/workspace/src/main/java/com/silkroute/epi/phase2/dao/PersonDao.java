package com.silkroute.epi.phase2.dao;

import java.util.List;

import com.googlecode.ehcache.annotations.Cacheable;
import com.silkroute.epi.dao.GenericDao;
import com.silkroute.epi.phase2.entity.Person;

public interface PersonDao extends GenericDao<Person> {
	
	List<Person> findPersonByUserName(String userName);

	List<Person> findPersonByUserNamePage(String userName, int page);
	
	List<Person> findPersonLikeUserName(String userName);

	List<Person> findPersonLikeUserNamePage(String userName, int page);

	List<Person> findPersonByEmailAddress(String emailAddress);

	List<Person> findPersonByEmailAddressPage(String emailAddress, int page);

	List<Person> findPersonLikeEmailAddress(String emailAddress);

	List<Person> findPersonLikeEmailAddressPage(String emailAddress, int page);
	
	List<Person> findPersonByName(String fName, String lName);
	
	List<Person> findPersonLikeName(String fName, String lName);
	
	List<Person> findPersonByUserNameOrEmailAddress(String userNameOrEmailAddress);
    
	List<Person> findPersonLikeUserNameOrEmailAddress(String userNameOrEmailAddress);
	
	Person findPersonById(long personId);
	
    @Cacheable(cacheName="epiadmintool")
	List<Person> findPersonByNamePage(String fName, String lName, int page);

    @Cacheable(cacheName="epiadmintool")
	List<Person> findPersonLikeNamePage(String fName, String lName, int page);

	@Cacheable(cacheName="epiadmintool")	
    List<Person> findPersonByUserNameOrEmailAddressPage(String userNameOrEmailAddress, int page);

	@Cacheable(cacheName="epiadmintool")	
    List<Person> findPersonLikeUserNameOrEmailAddressPage(String userNameOrEmailAddress, int page);
	
	@Cacheable(cacheName="epiadmintool")
    Integer resultCountByName(String fName, String lName);
    
	@Cacheable(cacheName="epiadmintool")
    Integer resultCountLikeName(String fName, String lName);
    
	@Cacheable(cacheName="epiadmintool")
    Integer resultCountByUserNameOrEmailAddress(String userNameOrEmailAddress);
	
	@Cacheable(cacheName="epiadmintool")
    Integer resultCountLikeUserNameOrEmailAddress(String userNameOrEmailAddress);
}

package com.silkroute.epi.contentextract.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.contentextract.dao.ContentExtractProductDao;
import com.silkroute.epi.contentextract.entity.ContentExtractProduct;

@Repository
@Transactional
public class ContentExtractProductDaoImpl extends ContentExtractDaoImpl<ContentExtractProduct> implements ContentExtractProductDao
{

	// Product Name is a like query, and can return multiple results.
    public List<ContentExtractProduct> findByProductName(String name)
    {
        em.clear();

        Query query = em.createNativeQuery("select * from content_extraction.product where upper(productname) like ?", ContentExtractProduct.class);
        query.setParameter(1, "%" + name.toUpperCase() + "%");
        
        List<ContentExtractProduct> results = query.getResultList();

        return results.isEmpty() ? new ArrayList<ContentExtractProduct>() : results;
    }

    @SuppressWarnings("unchecked")
    public ContentExtractProduct findByProductId(String id)
    {
        em.clear();

        Query query = em.createNativeQuery("select * from content_extraction.product where upper(productid) = ?", ContentExtractProduct.class);
        query.setParameter(1, id.toUpperCase());

        List<ContentExtractProduct> results = query.getResultList();

        return results.isEmpty() ? null : results.get(0);
    }

}

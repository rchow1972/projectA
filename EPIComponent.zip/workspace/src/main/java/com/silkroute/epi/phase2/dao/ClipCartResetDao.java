/**
 * 
 */
package com.silkroute.epi.phase2.dao;

import java.util.List;

import com.silkroute.epi.dao.GenericDao;
import com.silkroute.epi.phase2.entity.ClipCartReset;

/**
 * @author rajesh
 *
 */
public interface ClipCartResetDao extends GenericDao<ClipCartReset> {
//    ClipReset createClipReset(ClipReset ClipReset, PrintHistory printHistory);
    
    ClipCartReset updateClipReset(ClipCartReset clipCartReset);
    
    boolean deleteClipReset(ClipCartReset ClipCartReset);
    
    ClipCartReset findClipResetById(long validationId);
    
    ClipCartReset findClipResetByOffer(String offerId, long personId);
    
    List<ClipCartReset> findClipResetsByPerson(long personId);
 
    List<ClipCartReset> findClipResetsByPersonPage(long personId, int page);
    
    Integer resultCountClipResetByPerson(long personId);
    
    List<ClipCartReset> findClipResetsByPersonOfferEdition(long personId, String offerId, String edition);
}

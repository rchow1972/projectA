package com.silkroute.epi.phase2.dao;

import java.util.List;

import com.silkroute.epi.dao.GenericDao;
import com.silkroute.epi.phase2.entity.MembershipInstance;

public interface MembershipInstanceDao extends GenericDao<MembershipInstance> {
	
	List<MembershipInstance> findMembershipInstanceByPersonId(Long personId);
	
	MembershipInstance findMembershipInstanceById(Long membershipId);
}

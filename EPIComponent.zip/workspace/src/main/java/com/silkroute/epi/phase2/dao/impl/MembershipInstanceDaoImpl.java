package com.silkroute.epi.phase2.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.phase2.dao.MembershipInstanceDao;
import com.silkroute.epi.phase2.entity.MembershipInstance;

@Repository
@Transactional
public class MembershipInstanceDaoImpl extends Phase2DaoImpl<MembershipInstance> implements
		MembershipInstanceDao {

	public static int RESULTS_PER_PAGE = 15;
	
	public List<MembershipInstance> findMembershipInstanceByPersonId(
			Long personId) {
		phase2em.clear();
		
		String sql = "select * from PHASE2.MEMBERSHIP_INSTANCE where PERSON_ID = ?";
		Query query = phase2em.createNativeQuery(sql, MembershipInstance.class);
		query.setParameter(1, personId);
		List<MembershipInstance> results = (List<MembershipInstance>) query.getResultList();
		
		return results.isEmpty() ? new ArrayList<MembershipInstance>() : results;
		
	}

	public MembershipInstance findMembershipInstanceById(Long membershipId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public Integer findResultCountByPersonId(Long personId){
		phase2em.clear();
		Integer returnCount = 0;
		
		String sql = "select count(1) from PHASE2.MEMBERSHIP_INSTANCE where PERSON_ID = ?";
		Query query = phase2em.createNativeQuery(sql, MembershipInstance.class);
		query.setParameter(1, personId);
		BigDecimal res = (BigDecimal) query.getSingleResult();
		
		int result = res.intValue();
		
		returnCount = result;
		
		return returnCount == 0 ? 1 : returnCount;		
	}

}

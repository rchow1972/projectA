package com.silkroute.epi.contentextract.dao;

import java.util.List;

import com.silkroute.epi.contentextract.entity.ProductIdXEdition;
import com.silkroute.epi.dao.GenericDao;

public interface ProductIdXEditionDao extends GenericDao<ProductIdXEdition>
{
	
	List<ProductIdXEdition> findByProductNamePage(String name, int page);
	
    List<ProductIdXEdition> findByProductName(String name);

    List<ProductIdXEdition> findByProductIdPage(String id, int page);
    
    List<ProductIdXEdition> findByProductId(String id);
    
    List<ProductIdXEdition> findByXEditionPage(String id, int page);
    
    List<ProductIdXEdition> findByXEdition(String id);

    List<Object> joinOnProductId(String id);
    
    Integer deleteMapping(ProductIdXEdition deleteMap);
    
    Integer updateMapping(ProductIdXEdition prevMap, ProductIdXEdition newMap);
    
    Integer resultCountAsPage(String searchType, String searchParam);
}

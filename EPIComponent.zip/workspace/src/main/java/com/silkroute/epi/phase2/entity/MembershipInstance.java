package com.silkroute.epi.phase2.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="MEMBERSHIP_INSTANCE", schema="PHASE2")
public class MembershipInstance {


    // Fields    

     private Long membershipInstanceId;
     private Date dateCreated;
     private Long personId;
     private Date printEndDate;
     private Date printStartDate;
     private Date redeemEndDate;
     private Date redeemStartDate;
     private String edition;
     private Long siteToMembershipModelId;
     private Long orderId;
     private Date inactivatedDate;
     private String cancellationReason;



    // Constructors

    /** default constructor */
    public MembershipInstance() {
    }

    
    /** full constructor */
    public MembershipInstance(Date dateCreated, Long personId, java.util.Date printEndDate, java.util.Date printStartDate, java.util.Date redeemEndDate, java.util.Date redeemStartDate, String edition, Long siteToMembershipModelId, Long orderId, java.util.Date inactivatedDate) {
        this.dateCreated = dateCreated;
        this.personId = personId;
        this.printEndDate = printEndDate;
        this.printStartDate = printStartDate;
        this.redeemEndDate = redeemEndDate;
        this.redeemStartDate = redeemStartDate;
        this.edition = edition;
        this.siteToMembershipModelId = siteToMembershipModelId;
        this.orderId = orderId;
        this.inactivatedDate = inactivatedDate;
    }

   
    // Property accessors

    @Id
    @Column(name="MEMBERSHIP_INSTANCE_ID")
    @GeneratedValue(generator = "seqMemIns")
    @SequenceGenerator(name = "seqMemIns", sequenceName="PHASE2.SEQ_MEMBERSHIP_INSTANCE")
    public Long getMembershipInstanceId() {
        return this.membershipInstanceId;
    }
    
    public void setMembershipInstanceId(Long membershipInstanceId) {
        this.membershipInstanceId = membershipInstanceId;
    }

    @Column(name="DATE_CREATED")
    public Date getDateCreated() {
        return this.dateCreated;
    }
    
    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }

    @Column(name="PERSON_ID")
    public Long getPersonId() {
        return this.personId;
    }
    
    public void setPersonId(Long personId) {
        this.personId = personId;
    }

    @Column(name="PRINT_END_DATE")
    public Date getPrintEndDate() {
        return this.printEndDate;
    }
    
    public void setPrintEndDate(java.util.Date printEndDate) {
        this.printEndDate = printEndDate;
    }

    @Column(name="PRINT_START_DATE")
    public Date getPrintStartDate() {
        return this.printStartDate;
    }
    
    public void setPrintStartDate(java.util.Date printStartDate) {
        this.printStartDate = printStartDate;
    }

    @Column(name="REDEEM_END_DATE")
    public Date getRedeemEndDate() {
        return this.redeemEndDate;
    }
    
    public void setRedeemEndDate(java.util.Date redeemEndDate) {
        this.redeemEndDate = redeemEndDate;
    }

    @Column(name="REDEEM_START_DATE")
    public Date getRedeemStartDate() {
        return this.redeemStartDate;
    }
    
    public void setRedeemStartDate(java.util.Date redeemStartDate) {
        this.redeemStartDate = redeemStartDate;
    }

    @Column(name="EDITION")
    public String getEdition() {
        return this.edition;
    }
    
    public void setEdition(String edition) {
        this.edition = edition;
    }

    @Column(name="SITE_TO_MEMBERSHIP_MODEL_ID")
    public Long getSiteToMembershipModelId() {
        return this.siteToMembershipModelId;
    }
    
    public void setSiteToMembershipModelId(Long siteToMembershipModelId) {
        this.siteToMembershipModelId = siteToMembershipModelId;
    }

    @Column(name="ORDER_ID")
    public Long getOrderId() {
        return this.orderId;
    }
    
    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    @Column(name="INACTIVATED_DATE")
    public Date getInactivatedDate() {
        return this.inactivatedDate;
    }
    
    public void setInactivatedDate(java.util.Date inactivatedDate) {
        this.inactivatedDate = inactivatedDate;
    }

    @Column(name="CANCELLATION_REASON")
	public String getCancellationReason() {
		return cancellationReason;
	}


	public void setCancellationReason(String cancellationReason) {
		this.cancellationReason = cancellationReason;
	}
}
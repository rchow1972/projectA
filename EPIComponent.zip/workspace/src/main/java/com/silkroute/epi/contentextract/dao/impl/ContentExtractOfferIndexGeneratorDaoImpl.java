package com.silkroute.epi.contentextract.dao.impl;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.contentextract.dao.ContentExtractOfferIndexGeneratorDao;
import com.silkroute.epi.contentextract.entity.ContentExtractOfferSectionRelationTemp;

/**
 * Defines the database queries that are necessary to modify the
 * offersectionrelation_book table for offer index generation
 * 
 * @author Marika Wegiel (marika.wegiel@silkrouteglobal.com)
 * 
 */
@Repository
@Transactional
public class ContentExtractOfferIndexGeneratorDaoImpl extends
		ContentExtractDaoImpl<ContentExtractOfferSectionRelationTemp> implements
		ContentExtractOfferIndexGeneratorDao {

	public final static String BOOKTABLE = "CONTENT_EXTRACTION.OFFERSECTIONRELATION_BOOK";
	public final static String TEMPTABLE = "CONTENT_EXTRACTION.OFFERSECTIONRELATION_TEMP";

	/**
	 * Clears the temp table of existing data
	 * 
	 * @throws SQLException
	 */
	public void clearTempTable() throws SQLException {
		System.out.println("Clearing temp table");
//		String stmt = "truncate table " + TEMPTABLE;
		String stmt = "delete from " + TEMPTABLE;
		Query query = em.createNativeQuery(stmt);
		query.executeUpdate();
	}
	
	public void clearEntityManager() {
	    em.clear();
	}

	/**
	 * Joins the information from the temp table to other tables to obtain
	 * information not provided on the file, like redemption locations. Offers
	 * will be returned if they have redemption locations in the geo market or
	 * zip code list. Duplicates may be returned
	 * 
	 * @param geoMarket
	 *            The geo market ID expected for the offers
	 * @param zipCodes
	 *            The list of zip codes that the offers are valid in
	 * @return The data returned from the SQL Statment
	 * @throws SQLException
	 */
	public List<ContentExtractOfferSectionRelationTemp> getExistingData(
			String geoMarket, String zipCodes) throws SQLException {
		System.out.println("Acquiring necessary fields from database");
		String[] zips = zipCodes.split(",");
		String postalCodes = "";
		for (String zip : zips) {
			postalCodes += "'" + zip + "',";
		}
		if (postalCodes.length() > 0) {
			postalCodes = postalCodes.substring(0, postalCodes.length() - 1);
		}
//		String stmt = "select offer.OFFERPK, temp.OFFERID, temp.VERSION, "
//				+ "loc.REDEMPTIONLOCATIONID, temp.FOLIONUMBER "
//				+ "from CONTENT_EXTRACTION.OFFERSECTIONRELATION_TEMP temp, CONTENT_EXTRACTION.OFFER_REDEMPTIONLOCATION loc, "
//				+ "OFFERSELECT.REDEMPTION_LOCATION orl, CONTENT_EXTRACTION.OFFER offer, "
//				+ "OFFERSELECT.POSTALCODE pc "
//				+ "WHERE temp.OFFERID = loc.OFFERID "
//				+ "and temp.VERSION = loc.VERSION "
//				+ "and temp.OFFERID = offer.OFFERID "
//				+ "and temp.VERSION = offer.VERSION "
//				+ "and loc.REDEMPTIONLOCATIONID = orl.REDEMPTIONLOCATIONID "
//				+ "and orl.PHYSICALPOSTALCODE = pc.POSTALCODE "
//				+ "and orl.PHYSICALCITY = pc.CITY " + "and (pc.GEOMARKET = '"
//				+ geoMarket + "' or pc.POSTALCODE in (" + postalCodes + "))";
		
	      String stmt = "select offer.OFFERPK, temp.OFFERID, temp.VERSION, "
	                + "loc.REDEMPTIONLOCATIONID, temp.FOLIONUMBER "
	                + "from CONTENT_EXTRACTION.OFFERSECTIONRELATION_TEMP temp, CONTENT_EXTRACTION.OFFER_REDEMPTIONLOCATION loc, "
	                + "OFFERSELECT.REDEMPTION_LOCATION orl, CONTENT_EXTRACTION.OFFER offer, "
	                + "OFFERSELECT.POSTALCODE pc "
	                + "WHERE temp.OFFERID = loc.OFFERID "
	                + "and temp.VERSION = loc.VERSION "
	                + "and temp.OFFERID = offer.OFFERID "
	                + "and temp.VERSION = offer.VERSION "
	                + "and loc.REDEMPTIONLOCATIONID = orl.REDEMPTIONLOCATIONID "
	                + "and orl.PHYSICALPOSTALCODE = pc.POSTALCODE "
	                + "and orl.PHYSICALCITY = pc.CITY " + "and (pc.GEOMARKET = '"
	                + geoMarket + "' or pc.POSTALCODE in (" + postalCodes + "))";
		
		Query query = em.createNativeQuery(stmt,
				ContentExtractOfferSectionRelationTemp.class);
		List<?> results = query.getResultList();

		List<ContentExtractOfferSectionRelationTemp> r = new ArrayList<ContentExtractOfferSectionRelationTemp>();

		for (Object i : results) {
			r.add((ContentExtractOfferSectionRelationTemp) i);
		}

		return r;
	}

	/**
	 * Builds SQL statements using a map. Each record's data is contained in a
	 * map. The map key is the column name and the map value is the value to
	 * insert. This method works for a single record
	 * 
	 * @param tableName
	 *            The table to insert the data to
	 * @param record
	 *            A map of String column names and Object values
	 * @return The complete statement to execute
	 */
	public String insertStatmentBuilder(String tableName,
			Map<String, Object> record) {
		String sqlValues = "(";
		String sqlParams = "insert into " + tableName + " (";
		for (Entry<String, Object> entry : record.entrySet()) {
			String name = entry.getKey();
			Object value = entry.getValue();
			if (value == null) {
				System.out
						.println(name
								+ " is not defined for offer ID: "
								+ record.get(ContentExtractOfferSectionRelationTemp.offerIdNm));
				value = new String("");
			}
			sqlParams += name + ", ";
			if (!name.equals(ContentExtractOfferSectionRelationTemp.offerPkNm)
					&& !name.equals(ContentExtractOfferSectionRelationTemp.versionNm)) {
				sqlValues += "'";
				sqlValues += value.toString();
				sqlValues += "'";
			} else {
				sqlValues += value.toString();
			}
			sqlValues += ", ";
		}
		sqlValues = sqlValues.substring(0, sqlValues.length() - 2);
		sqlValues += ")";
		sqlParams = sqlParams.substring(0, sqlParams.length() - 2);
		sqlParams += ") values ";

		return sqlParams + sqlValues;

	}

	/**
	 * Inserts records to the BOOKTABLE
	 * 
	 * @param records
	 *            The records to insert
	 * @throws SQLException
	 */
	public void insertToBook(List<Map<String, Object>> records)
			throws SQLException {
		System.out.println("Inserting to " + BOOKTABLE + " table");
		for (int i = 0; i < records.size(); i++) {
			String stmt = insertStatmentBuilder(BOOKTABLE, records.get(i));
			Query query = em.createNativeQuery(stmt);
			query.executeUpdate();
		}
	}

	/**
	 * Inserts records to the TEMPTABLE
	 * 
	 * @param records
	 *            The records to insert to the table
	 * @throws SQLException
	 */
	public void insertToTemp(List<Map<String, Object>> records)
			throws SQLException {
		System.out.println("Inserting to " + TEMPTABLE + " table");
		for (int i = 0; i < records.size(); i++) {
			String stmt = insertStatmentBuilder(TEMPTABLE, records.get(i));
			Query query = em.createNativeQuery(stmt);
			query.executeUpdate();
		}
	}

	/**
	 * Removes data from the BOOKTABLE by product ID
	 * 
	 * @param records
	 *            The records that contain product IDs
	 * @throws SQLException
	 */
	public void removeExistingProducts(List<Map<String, Object>> records)
			throws SQLException {
		System.out.println("Removing records from " + BOOKTABLE
				+ " by product ID");
		for (int i = 0; i < records.size(); i++) {
			String key = ContentExtractOfferSectionRelationTemp.productIdNm;
			String stmt = "delete from " + BOOKTABLE + " where " + key + " = '"
					+ records.get(i).get(key) + "'";
			Query query = em.createNativeQuery(stmt);
			query.executeUpdate();
		}
	}
}

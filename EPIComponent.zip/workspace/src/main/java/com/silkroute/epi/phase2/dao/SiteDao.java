package com.silkroute.epi.phase2.dao;

import com.googlecode.ehcache.annotations.Cacheable;
import com.silkroute.epi.dao.GenericDao;
import com.silkroute.epi.phase2.entity.Site;

public interface SiteDao extends GenericDao<Site> {
	@Cacheable(cacheName="epiadmintool")
	String findSiteNameBySiteId(Long siteId);
	
	Site findSiteBySiteId(Long siteId);
}

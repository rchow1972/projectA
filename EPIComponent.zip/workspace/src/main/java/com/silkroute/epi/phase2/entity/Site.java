package com.silkroute.epi.phase2.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="SITES", schema="PHASE2")
public class Site {

    // Fields

    private long siteId;
    private Integer clientId;
    private String clientUrl;
    private String comments;
    private String contactEmal;
    private Date createDate;
    private String description;
    private String email;
    private Date expiryDate;
    private String homeUrl;
    private Character isHosted;
    private Date lastModified;
    private Date liveDate;
    private String name;
    private Character statusCode;
    private Integer subjectGroupKey;
    private String type;

    // Constructors

    /** default constructor */
    public Site() {
    }

    /** minimal constructor */
    public Site(long siteId) {
        this.siteId = siteId;
    }

    /** full constructor */
    public Site(long siteId, Integer clientId, String clientUrl, String comments, String contactEmal, Date createDate,
            String description, String email, Date expiryDate, String homeUrl, Character isHosted, Date lastModified, Date liveDate, String name,
            String promoCode, Character statusCode, Integer subjectGroupKey, String type) {
        this.siteId = siteId;
        this.clientId = clientId;
        this.clientUrl = clientUrl;
        this.comments = comments;
        this.contactEmal = contactEmal;
        this.createDate = createDate;
        this.description = description;
        this.email = email;
        this.expiryDate = expiryDate;
        this.homeUrl = homeUrl;
        this.isHosted = isHosted;
        this.lastModified = lastModified;
        this.liveDate = liveDate;
        this.name = name;
        this.statusCode = statusCode;
        this.subjectGroupKey = subjectGroupKey;
        this.type = type;
    }

    // Property accessors

    @Id
    @Column(name="SITEID")
    public long getSiteId() {
        return this.siteId;
    }

    public void setSiteId(long siteId) {
        this.siteId = siteId;
    }

    @Column(name="CLIENTID")
    public Integer getClientId() {
        return this.clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    @Column(name="CLIENT_URL")
    public String getClientUrl() {
        return this.clientUrl;
    }

    public void setClientUrl(String clientUrl) {
        this.clientUrl = clientUrl;
    }

    @Column(name="COMMENTS")
    public String getComments() {
        return this.comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Column(name="CONTACT_EMAIL")
    public String getContactEmal() {
        return this.contactEmal;
    }

    public void setContactEmal(String contactEmal) {
        this.contactEmal = contactEmal;
    }

    @Column(name="DATECREATED")
    public Date getCreateDate() {
        return this.createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    @Column(name="DESCRIPTION")
    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Column(name="EMAIL")
    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Column(name="DATETOEXPIRE")
    public Date getExpiryDate() {
        return this.expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    @Column(name="HOMEURL")
    public String getHomeUrl() {
        return this.homeUrl;
    }

    public void setHomeUrl(String homeUrl) {
        this.homeUrl = homeUrl;
    }

    @Column(name="ISHOSTED")
    public Character getIsHosted() {
        return this.isHosted;
    }

    public void setIsHosted(Character isHosted) {
        this.isHosted = isHosted;
    }

    @Column(name="LASTMODIFIED")
    public Date getLastModified() {
        return this.lastModified;
    }

    public void setLastModified(Date lastModified) {
        this.lastModified = lastModified;
    }

    @Column(name="LIVEDATE")
    public Date getLiveDate() {
        return this.liveDate;
    }

    public void setLiveDate(Date liveDate) {
        this.liveDate = liveDate;
    }

    @Column(name="NAME")
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Column(name="STATUSCODE")
    public Character getStatusCode() {
        return this.statusCode;
    }

    public void setStatusCode(Character statusCode) {
        this.statusCode = statusCode;
    }

    @Column(name="SUBJECTGROUPID")
    public Integer getSubjectGroupKey() {
        return this.subjectGroupKey;
    }

    public void setSubjectGroupKey(Integer subjectGroupKey) {
        this.subjectGroupKey = subjectGroupKey;
    }

    @Column(name="TYPE")
    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

}
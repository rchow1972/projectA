package com.silkroute.epi.boss.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.dao.GenericDao;

public abstract class BossDaoImpl<T> implements GenericDao<T> {
	//Getting error on lazy load without the EXTENDED
	@PersistenceContext(type=PersistenceContextType.EXTENDED, unitName = "bossEmf")
	public EntityManager bossem;

	private Class<T> type;

	public BossDaoImpl() {
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType) t;
		type = (Class) pt.getActualTypeArguments()[0];
	}

	@Transactional
	public T persist(final T t) {
		this.bossem.persist(t);
		return t;
	}

	public void delete(final Object id) {
		this.bossem.remove(this.bossem.getReference(type, id));
	}

	public T find(final Object id) {
		return (T) this.bossem.find(type, id);
	}

	public T update(final T t) {
		return this.bossem.merge(t);
	}
	
	public EntityManager getEntityManager(){
	    return bossem;
	}
}

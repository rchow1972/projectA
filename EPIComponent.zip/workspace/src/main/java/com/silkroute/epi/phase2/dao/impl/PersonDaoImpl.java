package com.silkroute.epi.phase2.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.phase2.dao.PersonDao;
import com.silkroute.epi.phase2.entity.Person;

@Repository
@Transactional
public class PersonDaoImpl extends Phase2DaoImpl<Person> implements PersonDao
{
	private static final Logger log = Logger.getLogger(PersonDaoImpl.class);
 
	public static int RESULTS_PER_PAGE = 15;
	
	// Empty Constructor
	private PersonDaoImpl()
	{
	}

	/**
	 * Query to return person by user name.
	 * 
	 * Method returns a result list based on the provided user name.
	 * 
	 * @param userName User name to use in search, matching column PEUSERNAME
	 * @return Person list based on provided user name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByUserName(String userName)
	{
		phase2em.clear();
		
		String upperUserName = userName.toUpperCase();
		String lowerUserName = userName.toLowerCase();
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peusername = ? or peusername = ?)";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);

		List<Person> results = query.getResultList();
		
		return results.isEmpty() ? new ArrayList<Person>() : results;
	}

	/**
	 * Query to return person by user name at requested page.
	 * 
	 * Method returns a result list based on the provided user name for requested page.
	 * 
	 * @param userName User name to use in search, matching column PEUSERNAME
	 * @param page The page to return results for.
	 * @return Person list based on provided user name and requested page.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByUserNamePage(String userName, int page) {
		phase2em.clear();
		
		String upperUserName = userName.toUpperCase();
		String lowerUserName = userName.toLowerCase();
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peusername = ? or peusername = ?)";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return person like user name with wild card search.
	 * 
	 * Method returns a result list based on the provided user name.
	 * 
	 * @param userName User name to use in search, matching column PEUSERNAME
	 * @return Person list based on provided user name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeUserName(String userName)
	{
		phase2em.clear();
		
		String upperUserName = "%" + userName.toUpperCase() + "%";
		String lowerUserName = "%" + userName.toLowerCase() + "%";
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peusername like ? or peusername like ?)";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);

		List<Person> results = query.getResultList();
		
		return results.isEmpty() ? new ArrayList<Person>() : results;
	}

	/**
	 * Query to return person like user name with wild card search at requested page.
	 * 
	 * Method returns a result list based on the provided user name for requested page.
	 * 
	 * @param userName User name to use in search, matching column PEUSERNAME
	 * @param page The page to return results for.
	 * @return Person list based on provided user name and requested page.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeUserNamePage(String userName, int page) {
		phase2em.clear();
		
		String upperUserName = "%" + userName.toUpperCase() + "%";
		String lowerUserName = "%" + userName.toLowerCase() + "%";
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peusername like ? or peusername like ?)";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return person by email address.
	 * 
	 * Method returns a result list based on the provided email address.
	 * 
	 * @param emailAddress User name to use in search, matching column PEEMAIL
	 * @return Person list based on provided user name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByEmailAddress(String emailAddress)
	{
		phase2em.clear();
		
		String upperEmailAddress = emailAddress.toUpperCase();
		String lowerEmailAddress = emailAddress.toLowerCase();
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peemail = ? or peemail = ?)";

		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperEmailAddress);
		query.setParameter(2, lowerEmailAddress);
		
		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}

	/**
	 * Query to return person by email address at requested page.
	 * 
	 * Method returns a result list based on the provided email address for requested page.
	 * 
	 * @param emailAddress User name to use in search, matching column PEEMAIL
	 * @param page The page to return results for.
	 * @return Person list based on provided user name and requested page.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByEmailAddressPage(String emailAddress, int page) {
		phase2em.clear();
		
		String upperEmailAddress = emailAddress.toUpperCase();
		String lowerEmailAddress = emailAddress.toLowerCase();
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peemail = ? or peemail = ?)";

		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperEmailAddress);
		query.setParameter(2, lowerEmailAddress);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return person like email address with wild card search.
	 * 
	 * Method returns a result list based on the provided email address.
	 * 
	 * @param emailAddress User name to use in search, matching column PEEMAIL
	 * @return Person list based on provided user name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeEmailAddress(String emailAddress)
	{
		phase2em.clear();
		
		String upperEmailAddress = "%" + emailAddress.toUpperCase() + "%";
		String lowerEmailAddress = "%" + emailAddress.toLowerCase() + "%";
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peemail like ? or peemail like ?)";

		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperEmailAddress);
		query.setParameter(2, lowerEmailAddress);
		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return person like email address with wild card search at requested page.
	 * 
	 * Method returns a result list based on the provided email address for requested page.
	 * 
	 * @param emailAddress User name to use in search, matching column PEEMAIL
	 * @param page The page to return results for.
	 * @return Person list based on provided user name and requested page.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeEmailAddressPage(String emailAddress, int page) {
		phase2em.clear();
		
		String upperEmailAddress = "%" + emailAddress.toUpperCase() + "%";
		String lowerEmailAddress = "%" + emailAddress.toLowerCase() + "%";
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peemail like ? or peemail like ?)";

		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperEmailAddress);
		query.setParameter(2, lowerEmailAddress);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return person by first name and last name.
	 * 
	 * Method returns a result list based on the provided first name and last name. Must use UPPER() in this method to return accurate results.
	 * 
	 * @param fName First name to use in search, matching column PEFIRSTNAME
	 * @param lName Last name to use in search, matching column PELASTNAME
	 * @return Person list based on provided first name and last name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByName(String fName, String lName){
		phase2em.clear();

		String sql = "select * from PHASE2.PERSON P where UPPER(P.PEFIRSTNAME) = ? and UPPER(P.PELASTNAME) = ?";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, fName.toUpperCase());
		query.setParameter(2, lName.toUpperCase());

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;	
	}
	
	/**
	 * Query to return person by first name and last name.
	 * 
	 * Method returns a result list based on the provided first name and last name. Must use UPPER() in this method to return accurate results.
	 * 
	 * @param fName First name to use in search, matching column PEFIRSTNAME
	 * @param lName Last name to use in search, matching column PELASTNAME
	 * @param page The page to return results for.
	 * @return Person list based on provided first name and last name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByNamePage(String fName, String lName, int page) {
		phase2em.clear();

		String sql = "select * from PHASE2.PERSON P where UPPER(P.PEFIRSTNAME) = ? and UPPER(P.PELASTNAME) = ?";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, fName.toUpperCase());
		query.setParameter(2, lName.toUpperCase());
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;	
	}
	
	/**
	 * Pagination query to return results count by first name and last name.
	 * 
	 * Method returns a pagination count based on the provided RESULTS_PER_PAGE (default 15 per page). Must use UPPER() in this method to return accurate counts.
	 * 
	 * @param fName First name to use in search, matching column PEFIRSTNAME
	 * @param lName Last name to use in search, matching column PELASTNAME
	 * @return Number of pages based on RESULTS_PER_PAGE (default 15 per page)
	 */
	public Integer resultCountByName(String fName, String lName) {
		phase2em.clear();
		
		Integer returnCount = 1;
		
		String sql = "select count(*) from PHASE2.PERSON P where UPPER(P.PEFIRSTNAME) = ? and UPPER(P.PELASTNAME) = ?";
		if ( !"".equals(sql)) {
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, fName.toUpperCase());
			query.setParameter(2, lName.toUpperCase());
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;
	}

	/**
	 * Query to return person with wild card search for first name and last name.
	 * 
	 * Method returns a result list based on the provided first name and last name. Must use UPPER() in this method to return accurate counts.
	 * 
	 * @param fName First name to use in search, matching column PEFIRSTNAME
	 * @param lName Last name to use in search, matching column PELASTNAME
	 * @return Person list based on provided first name and last name.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeName(String fName, String lName){
		phase2em.clear();

		String sql = "select * from PHASE2.PERSON P where UPPER(P.PEFIRSTNAME) like ? and UPPER(P.PELASTNAME) like ?";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, "%" + fName.toUpperCase() + "%");
		query.setParameter(2, "%" + lName.toUpperCase() + "%");

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;	
	}
	
	/**
	 * Query to return person with wild card search for first name and last name with requested page.
	 * 
	 * Method returns a result list based on the provided first name and last name. Must use UPPER() in this method to return accurate counts.
	 * 
	 * @param fName First name to use in search, matching column PEFIRSTNAME
	 * @param lName Last name to use in search, matching column PELASTNAME
	 * @param page The page to return results for.
	 * @return Person list based on provided first name and last name.
	 */	
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeNamePage(String fName, String lName, int page) {
		phase2em.clear();

		String sql = "select * from PHASE2.PERSON P where UPPER(P.PEFIRSTNAME) like ? and UPPER(P.PELASTNAME) like ?";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, "%" + fName.toUpperCase() + "%");
		query.setParameter(2, "%" + lName.toUpperCase() + "%");
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;	
	}
	
	/**
	 * Pagination query to return results count with wild card search for first name and last name.
	 * 
	 * Method returns a pagination count based on the provided RESULTS_PER_PAGE (default 15 per page). Must use UPPER() in this method to return accurate counts.
	 * 
	 * @param fName First name to use in search, matching column PEFIRSTNAME
	 * @param lName Last name to use in search, matching column PELASTNAME
	 * @return Number of pages based on RESULTS_PER_PAGE (default 15 per page)
	 */
	public Integer resultCountLikeName(String fName, String lName) {
		phase2em.clear();
		
		Integer returnCount = 1;
		
		String sql = "select count(*) from PHASE2.PERSON P where UPPER(P.PEFIRSTNAME) like ? and UPPER(P.PELASTNAME) like ?";
		if ( !"".equals(sql)) {
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, "%" + fName.toUpperCase() + "%");
			query.setParameter(2, "%" + lName.toUpperCase() + "%");
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;
	}
	
	/**
	 * Query to return persons by user name or email address.
	 * 
	 * Method returns a a list of persons based on the user name or email address. Query return times reduced by removing UPPER().
	 * @param userNameOrEmailAddress The user name or email address to be used for search.
	 * @return A number of persons based on user name or email address.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByUserNameOrEmailAddress(String userNameOrEmailAddress)
	{
		phase2em.clear();
		
		String upperUserName = userNameOrEmailAddress.toUpperCase();
		String lowerUserName = userNameOrEmailAddress.toLowerCase();
		
		String sql = "SELECT * " +
				"from phase2.person " +
				"WHERE (peusername = ? or peusername = ? " +
				"or peemail = ? or peemail = ?)";
		
//		String sql = "SELECT p.peseqno, p.peusername, p.pesiteid, p.pefirstname, p.pelastname " +
//				"from phase2.person p WHERE " +
//				"(p.peusername = ? or p.peusername = ? " +
//				"or p.peemail = ? or p.peemail = ?) " +
//				"UNION SELECT C.CUSTOMERID as PESEQNO, C.USERNAME AS PEUSERNAME, A.SITEID AS PESITEID, C.FIRSTNAME as PEFIRSTNAME, C.LASTNAME as PELASTNAME " +
//				"FROM PHASE2.CUSTOMERS C, PHASE2.ACCOUNTS A WHERE " +
//				"C.USERNAME = ?	AND A.CUSTOMERID = C.CUSTOMERID";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);
		query.setParameter(3, upperUserName);
		query.setParameter(4, lowerUserName);
//		query.setParameter(5, upperUserName);

		List<Person> results = query.getResultList();
		
		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return persons by user name or email address on provided page.
	 * 
	 * Method returns a a list of persons based on the user name or email address with requested page. Query return times reduced by removing UPPER().
	 * @param userNameOrEmailAddress The user name or email address to be used for search.
	 * @param page The page to return results for.
	 * @return A number of persons based on RESULTS_PER_PAGE (defaults to 15 per page) starting on provided page.
	 */
	@SuppressWarnings("unchecked")
	public List<Person> findPersonByUserNameOrEmailAddressPage(String userNameOrEmailAddress, int page) {
		phase2em.clear();

		String upperUserName = userNameOrEmailAddress.toUpperCase();
		String lowerUserName = userNameOrEmailAddress.toLowerCase();
		
		String sql = "SELECT * " +
				"from phase2.person p " +
				"WHERE (p.peusername = ? or p.peusername = ? " +
				"or p.peemail = ? or p.peemail = ?)";
		
//		String sql = "SELECT peseqno, peusername, pesiteid, pefirstname, pelastname, peemail " +
//				"from phase2.person WHERE " +
//				"(peusername = ? or peusername = ? " +
//				"or peemail = ? or peemail = ?) " +
//				"UNION SELECT C.CUSTOMERID as PESEQNO, C.USERNAME AS PEUSERNAME, A.SITEID AS PESITEID, C.FIRSTNAME as PEFIRSTNAME, C.LASTNAME as PELASTNAME, C.EMAIL as PEEMAIL " +
//				"FROM PHASE2.CUSTOMERS C, PHASE2.ACCOUNTS A WHERE " +
//				"C.USERNAME = ? AND A.CUSTOMERID = C.CUSTOMERID";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);
		query.setParameter(3, upperUserName);
		query.setParameter(4, lowerUserName);
//		query.setParameter(5, upperUserName);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Pagination query to return results count by user name or password.
	 * 
	 * Method returns a pagination count based on the provided RESULTS_PER_PAGE (default 15 per page). Query return times reduced by removing UPPER().
	 * @param userNameOrEmailAddress The user name or email address to be used for search.
	 * @return Number of pages based on RESULTS_PER_PAGE (default 15 per page)
	 */
	public Integer resultCountByUserNameOrEmailAddress(String userNameOrEmailAddress) {
		phase2em.clear();
		
		Integer returnCount = 1;
		
		String sql = "SELECT count(*) " +
				"from phase2.person p " +
				"WHERE (p.peusername = ? or p.peusername = ? " +
				"or p.peemail = ? or p.peemail = ?)";

//		String sql = "select COUNT(*) from (SELECT peseqno AS USERID, peusername AS USERNAME, pesiteid AS SITEID " +
//				"from phase2.person WHERE " +
//				"(peusername = ? or peusername = ? " +
//				"or peemail = ? or peemail = ?) " +
//				"UNION SELECT C.CUSTOMERID as USERID, C.USERNAME, A.SITEID " +
//				"FROM PHASE2.CUSTOMERS C, PHASE2.ACCOUNTS A WHERE " +
//				"C.USERNAME = ?	AND A.CUSTOMERID = C.CUSTOMERID)";

		
		if ( !"".equals(sql)) {
			String upperUserName = userNameOrEmailAddress.toUpperCase();
			String lowerUserName = userNameOrEmailAddress.toLowerCase();
			
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, upperUserName);
			query.setParameter(2, lowerUserName);
			query.setParameter(3, upperUserName);
			query.setParameter(4, lowerUserName);
//			query.setParameter(5, upperUserName);
			
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;
	}
	
	/**
	 * Query to return persons by user name or email address with wild card search.
	 * 
	 * Method returns a a list of persons based on the user name or email address with requested page. Query return times reduced by removing UPPER().
	 * @param userNameOrEmailAddress The user name or email address to be used for search.
	 * @return Person results provided on requested search.
	 */	
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeUserNameOrEmailAddress(String userNameOrEmailAddress)
	{
		phase2em.clear();

		String upperUserName = "%" + userNameOrEmailAddress.toUpperCase() + "%";
		String lowerUserName = "%" + userNameOrEmailAddress.toLowerCase() + "%";
		
		String sql = "SELECT * " +
				"from phase2.person p " +
				"WHERE (p.peusername like ? or p.peusername like ? " +
				"or p.peemail like ? or p.peemail like ?)";
		
//		String sql = "SELECT peseqno AS USERID, peusername AS USERNAME, pesiteid AS SITEID " +
//				"from phase2.person WHERE " +
//				"(peusername like ? or peusername like ? " +
//				"or peemail like ? or peemail like ?) " +
//				"UNION SELECT C.CUSTOMERID as USERID, C.USERNAME, A.SITEID " +
//				"FROM PHASE2.CUSTOMERS C, PHASE2.ACCOUNTS A WHERE " +
//				"C.USERNAME like ?	AND A.CUSTOMERID = C.CUSTOMERID";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);
		query.setParameter(3, upperUserName);
		query.setParameter(4, lowerUserName);
//		query.setParameter(5, upperUserName);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Query to return persons by user name or email address with wild card search on provided page.
	 * 
	 * Method returns a a list of persons based on the user name or email address with requested page. Query return times reduced by removing UPPER().
	 * @param userNameOrEmailAddress The user name or email address to be used for search.
	 * @param page The page to return results for.
	 * @return A number of persons based on RESULTS_PER_PAGE (defaults to 15 per page) starting on provided page.
	 */	
	@SuppressWarnings("unchecked")
	public List<Person> findPersonLikeUserNameOrEmailAddressPage(String userNameOrEmailAddress, int page) {
		phase2em.clear();

		String upperUserName = "%" + userNameOrEmailAddress.toUpperCase() + "%";
		String lowerUserName = "%" + userNameOrEmailAddress.toLowerCase() + "%";
		
		String sql = "SELECT * " +
				"from phase2.person p " +
				"WHERE (p.peusername like ? or p.peusername like ? " +
				"or p.peemail like ? or p.peemail like ?)";
		
		Query query = phase2em.createNativeQuery(sql, Person.class);
		query.setParameter(1, upperUserName);
		query.setParameter(2, lowerUserName);
		query.setParameter(3, upperUserName);
		query.setParameter(4, lowerUserName);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

		List<Person> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<Person>() : results;
	}
	
	/**
	 * Pagination query to return results count with wild card search for user name or email address.
	 * 
	 * Method returns a pagination count based on the provided RESULTS_PER_PAGE (default 15 per page). Removed UPPER to decrease query time.
	 * 
	 * @param userNameOrEmailAddress The user name or email address to be used for search.
	 * @return Number of pages based on RESULTS_PER_PAGE (default 15 per page)
	 */
	public Integer resultCountLikeUserNameOrEmailAddress(String userNameOrEmailAddress) {
		phase2em.clear();
		
		Integer returnCount = 1;
		
		String sql = "SELECT count(*) " +
				"from phase2.person p " +
				"WHERE (p.peusername like ? or p.peusername like ? " +
				"or p.peemail like ? or p.peemail like ?)";
		
		if ( !"".equals(sql)) {
			String upperUserName = "%" + userNameOrEmailAddress.toUpperCase() + "%";
			String lowerUserName = "%" + userNameOrEmailAddress.toLowerCase() + "%";
			
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, upperUserName);
			query.setParameter(2, lowerUserName);
			query.setParameter(3, upperUserName);
			query.setParameter(4, lowerUserName);
			
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;
	}
	
	/**
	 * Query to return persons by user id provided.
	 * 
	 * Method returns a a list of persons based on the user id provided.
	 * @param personId The user name or email address to be used for search.
	 * @return Person record for the provided id.
	 */
	public Person findPersonById(long personId)
	{
		phase2em.clear();
		
		Query query = phase2em.createNativeQuery("select * from PHASE2.PERSON P where P.PESEQNO = ?", Person.class);
		query.setParameter(1, personId);
		Person result = (Person) query.getSingleResult();

		return result;
	}
}

package com.silkroute.epi.contentextract.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.contentextract.dao.ProductIdXEditionDao;
import com.silkroute.epi.contentextract.entity.ProductIdXEdition;

@Repository
@Transactional
public class ProductIdXEditionDaoImpl extends ContentExtractDaoImpl<ProductIdXEdition> implements ProductIdXEditionDao
{

	public static int RESULTS_PER_PAGE = 15;
	private static String SEARCH_TYPE_PRODUCTID = "productId";
	private static String SEARCH_TYPE_PRODUCTNAME = "productName";
	private static String SEARCH_TYPE_XEDITION = "xEdition";
	
    public List<ProductIdXEdition> findByProductName(String productName)
    {
        return findByProductNamePage(productName, 1);
    }

    @SuppressWarnings("unchecked")
    public List<ProductIdXEdition> findByProductId(String productId)
    {
        return findByProductIdPage(productId, 1);
    }

    @SuppressWarnings("unchecked")
    public List<ProductIdXEdition> findByXEdition(String xEdition)
    {
        return findByXEditionPage(xEdition, 1);
    }
   
    @SuppressWarnings("unchecked")
    public List<Object> joinOnProductId(String id) {
    	em.clear();
    	
    	Query query = em.createNativeQuery("select P.ProductName, P.ProductId, M.xedition " +
    			"from MAP_PRODUCTID_XEDITION M " +
    			"inner join PRODUCT P " +
    			"on UPPER(p.productid) = UPPER(m.productid) " +
    			"where UPPER(M.PRODUCTID) = ?");
    	query.setParameter(1, id.toUpperCase());
    	
    	List<Object> results = query.getResultList();
    	
    	return results.isEmpty() ? new ArrayList<Object>() : results;
    }
    
	public Integer deleteMapping(ProductIdXEdition deleteMap) {
		em.clear();
		
		Query query = em.createNativeQuery("delete from content_extraction.MAP_PRODUCTID_XEDITION M where M.PRODUCTID = ? and M.XEDITION = ?");
		query.setParameter(1, deleteMap.getProductId());
		query.setParameter(2, deleteMap.getXEdition());

		int updatedRows = query.executeUpdate();
		
		return updatedRows;
	}

	public Integer updateMapping(ProductIdXEdition prevMap, ProductIdXEdition newMap) {
		em.clear();
		
		Query query = em.createNativeQuery("update content_extraction.MAP_PRODUCTID_XEDITION M set M.PRODUCTID = ?, M.XEDITION = ? " +
				"where M.PRODUCTID = ? and M.XEDITION = ?");
		query.setParameter(1, newMap.getProductId());
		query.setParameter(2, newMap.getXEdition());
		query.setParameter(3, prevMap.getProductId());
		query.setParameter(4, prevMap.getXEdition());

		int updatedRows = query.executeUpdate();
		
		return updatedRows;
	}

	@SuppressWarnings("unchecked")
	public List<ProductIdXEdition> findByProductNamePage(String productName, int page) {
        em.clear();

        Query query = em.createNativeQuery("select * from content_extraction.MAP_PRODUCTID_XEDITION where UPPER(PRODUCTID) in (select UPPER(PRODUCTID) from content_extraction.PRODUCT where UPPER(PRODUCTNAME) like ?)", ProductIdXEdition.class);
        
        query.setParameter(1, "%" + productName.toUpperCase() + "%");
        query.setMaxResults(RESULTS_PER_PAGE);
        query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

        List<ProductIdXEdition> results = query.getResultList();

        return results.isEmpty() ? new ArrayList<ProductIdXEdition>() : results;	}

	 @SuppressWarnings("unchecked")
	 public List<ProductIdXEdition> findByProductIdPage(String productId, int page) {
        em.clear();

        Query query = em.createNativeQuery("select * from content_extraction.map_productid_xedition where upper(productid) = ?", ProductIdXEdition.class);
        query.setParameter(1, productId.toUpperCase());
        query.setMaxResults(RESULTS_PER_PAGE);
        query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

        List<ProductIdXEdition> results = query.getResultList();        
        
        return results.isEmpty() ? new ArrayList<ProductIdXEdition>() : results;
	}

	 @SuppressWarnings("unchecked")
	 public List<ProductIdXEdition> findByXEditionPage(String xEdition, int page) {
        em.clear();

        Query query = em.createNativeQuery("select * from content_extraction.map_productid_xedition where upper(xedition) = ?", ProductIdXEdition.class);
        query.setParameter(1, xEdition.toUpperCase());
        query.setMaxResults(RESULTS_PER_PAGE);
        query.setFirstResult((page - 1) * RESULTS_PER_PAGE);

        List<ProductIdXEdition> results = query.getResultList();

        return results.isEmpty() ? new ArrayList<ProductIdXEdition>() : results;
	}

	 public Integer resultCountAsPage(String searchType, String searchParam) {
		Integer returnCount = 1;
		
		String sql = "";
		if ( SEARCH_TYPE_PRODUCTNAME.equals(searchType) ) {
			sql = "select count(productid) from content_extraction.MAP_PRODUCTID_XEDITION where UPPER(PRODUCTID) in (select UPPER(PRODUCTID) from content_extraction.PRODUCT where UPPER(PRODUCTNAME) like ?)";
			searchParam = "%" + searchParam.toUpperCase() + "%";
		}
		else if ( SEARCH_TYPE_PRODUCTID.equals(searchType)){
			sql = "select count(productid) from content_extraction.map_productid_xedition where upper(productid) = ?";
		} else if (SEARCH_TYPE_XEDITION.equals(searchType)){
			sql = "select count(productid) from content_extraction.map_productid_xedition where upper(xedition) = ?";
		}
		
		if ( !"".equals(sql)) {
			Query query = em.createNativeQuery(sql);
			query.setParameter(1, searchParam.toUpperCase());
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;
	}
}

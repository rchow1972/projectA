package com.silkroute.epi.phase2.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.dao.GenericDao;



public abstract class Phase2DaoImpl<T> implements GenericDao<T> {

	//Getting error on lazy load without the EXTENDED
	@PersistenceContext(type=PersistenceContextType.EXTENDED, unitName = "phase2Emf")
	public EntityManager phase2em;

	private Class<T> type;

	public Phase2DaoImpl() {
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType) t;
		type = (Class) pt.getActualTypeArguments()[0];
	}

	@Transactional
	public T persist(final T t) {
		this.phase2em.persist(t);
		return t;
	}

	public void delete(final Object id) {
		this.phase2em.remove(this.phase2em.getReference(type, id));
	}

	public T find(final Object id) {
		return (T) this.phase2em.find(type, id);
	}

	public T update(final T t) {
		return this.phase2em.merge(t);
	}
	
	public EntityManager getEntityManager(){
	    return phase2em;
	}
}

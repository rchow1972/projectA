package com.silkroute.epi.boss.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema="BOSS", name="CUSTOMER_BILL_PROFILE")
public class CustomerBillProfile {
//	CUSTOMER_ID	NUMBER
//	FIRST_NAME  VARCHAR2(25)
//	LAST_NAME   VARCHAR2(25)
//	ADDRESS_1   VARCHAR2(30)
//	ADDRESS_2   VARCHAR2(30)
//	CITY        VARCHAR2(30)
//	STATE       VARCHAR2(2)
//	ZIP_CODE    VARCHAR2(20)
	
	Long customerId;
	String firstName;
	String lastName;
	String address1;
	String address2;
	String city;
	String state;
	String zipcode;
	
    @Id
    @Column(name = "CUSTOMER_ID", unique = true, nullable = false)
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	@Column(name = "FIRST_NAME")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	@Column(name = "LAST_NAME")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Column(name = "ADDRESS_1")
	public String getAddress1() {
		return address1;
	}
	public void setAddress1(String address1) {
		this.address1 = address1;
	}
	
	@Column(name = "ADDRESS_2")
	public String getAddress2() {
		return address2;
	}
	public void setAddress2(String address2) {
		this.address2 = address2;
	}
	
	@Column(name = "CITY")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Column(name = "STATE")
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	@Column(name = "ZIP_CODE")
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
}

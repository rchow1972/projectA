package com.silkroute.epi.ocpcontrol.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;

import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.dao.GenericDao;

public abstract class OcpControlDaoImpl<T> implements GenericDao<T> {
	//Getting error on lazy load without the EXTENDED
	@PersistenceContext(type=PersistenceContextType.EXTENDED, unitName = "ocpControlEmf")
	public EntityManager ocpControlEm;

	private Class<T> type;

	public OcpControlDaoImpl() {
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType) t;
		type = (Class) pt.getActualTypeArguments()[0];
	}

	@Transactional
	public T persist(final T t) {
		this.ocpControlEm.persist(t);
		return t;
	}

	public void delete(final Object id) {
		this.ocpControlEm.remove(this.ocpControlEm.getReference(type, id));
	}

	public T find(final Object id) {
		return (T) this.ocpControlEm.find(type, id);
	}

	public T update(final T t) {
		return this.ocpControlEm.merge(t);
	}
	
	public EntityManager getEntityManager(){
	    return ocpControlEm;
	}
}

package com.silkroute.epi.boss.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.boss.dao.CustomerBillProfileDao;
import com.silkroute.epi.boss.entity.CustomerBillProfile;
import com.silkroute.epi.boss.entity.CustomerBillProfile_;

@Repository
@Transactional
public class CustomerBillProfileDaoImpl extends BossDaoImpl<CustomerBillProfile> implements CustomerBillProfileDao {

	public CustomerBillProfile findBillProfileByCustomerId(Long customerId){
		bossem.clear();
		
		CriteriaBuilder cb = bossem.getCriteriaBuilder();
		CriteriaQuery cq = cb.createQuery(CustomerBillProfile.class);
		Root<CustomerBillProfile> cbprofile = cq.from(CustomerBillProfile.class);
		cq.where(cb.equal(cbprofile.get(CustomerBillProfile_.customerId), customerId));
		cq.select(cbprofile);
		
		TypedQuery<CustomerBillProfile> tq = bossem.createQuery(cq);
		CustomerBillProfile customerBillProfile = tq.getSingleResult();
	
		return customerBillProfile;
	}
	
	public List<CustomerBillProfile> findAllBillProfile(){
		bossem.clear();
		
		CriteriaBuilder cb = bossem.getCriteriaBuilder();
		CriteriaQuery cq = cb.createQuery(CustomerBillProfile.class);
		Root<CustomerBillProfile> cbprofile = cq.from(CustomerBillProfile.class);
		cq.select(cbprofile);
		
		TypedQuery<CustomerBillProfile> tq = bossem.createQuery(cq);
		List<CustomerBillProfile> allCust = tq.getResultList();
	
		return allCust;
	}

}

package com.silkroute.epi.contentextract.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Defines the results from the join statement for offer index generation Also
 * contains the names of the database columns of offersectionrelation_book table
 * for generating sql statements
 * 
 * @author Marika Wegiel (marika.wegiel@silkrouteglobal.com)
 * 
 */
@Entity
@Table(schema = "CONTENT_EXTRACTION", name = "OFFERSECTIONRELATION_TEMP")
public class ContentExtractOfferSectionRelationTemp implements Serializable {
	String folioNumber;
	String offerId;
	BigDecimal offerPk;
	String redemptionLocationId;
	BigDecimal version;
	public static final String createdByNm = "CREATEDBY";
	public static final String createdDtNm = "CREATEDDATE";
	public static final String folioNumberNm = "FOLIONUMBER";
	public static final String modifiedByNm = "MODIFIEDBYNM";
	public static final String modifiedDtNm = "MODIFIEDDATE";
	public static final String offerIdNm = "OFFERID";
	public static final String offerPkNm = "OFFERPK";
	public static final String productIdNm = "PRODUCTID";
	public static final String redemptionLocationIdNm = "REDEMPTIONLOCATIONID";
	public static final String versionNm = "VERSION";
	private static final long serialVersionUID = 1L;

	@Column(name = folioNumberNm)
	public String getFolioNumber() {
		return folioNumber;
	}

	@Column(name = offerIdNm)
	public String getOfferId() {
		return offerId;
	}

	@Id
	@Column(name = offerPkNm)
	public BigDecimal getOfferPk() {
		return offerPk;
	}

	@Id
	@Column(name = redemptionLocationIdNm)
	public String getRedemptionLocationId() {
		return redemptionLocationId;
	}

	@Column(name = versionNm)
	public BigDecimal getVersion() {
		return version;
	}

	public void setFolioNumber(String folioNumber) {
		this.folioNumber = folioNumber;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

	public void setOfferPk(BigDecimal offerPk) {
		this.offerPk = offerPk;
	}

	public void setRedemptionLocationId(String redemptionLocationId) {
		this.redemptionLocationId = redemptionLocationId;
	}

	public void setVersion(BigDecimal version) {
		this.version = version;
	}
}

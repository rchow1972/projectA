package com.silkroute.epi.contentextract.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema = "content_extraction", name = "product")
public class ContentExtractProduct
{

    public String productId;

    public String productName;
    public String productDescription;
    public String productFamilyId;
    public String expirationYear;
    public String isStatic;
    public Date createdDate;
    public String createdBy;
    public Date modifiedDate;
    public String modifiedBy;

    @Id
    @Column(name = "productid", unique = true, nullable = false)
    public String getProductId()
    {
        return productId;
    }

    public void setProductId(String productId)
    {
        this.productId = productId;
    }


    @Column(name = "productname")
    public String getProductName()
    {
        return productName;
    }

    public void setProductName(String productName)
    {
        this.productName = productName;
    }

    @Column(name = "productdescription")
    public String getProductDescription()
    {
        return productDescription;
    }

    public void setProductDescription(String productDescription)
    {
        this.productDescription = productDescription;
    }

    @Column(name = "productfamilyid")
    public String getProductFamilyId()
    {
        return productFamilyId;
    }

    public void setProductFamilyId(String productFamilyId)
    {
        this.productFamilyId = productFamilyId;
    }

    @Column(name = "expirationyear")
    public String getExpirationYear()
    {
        return expirationYear;
    }

    public void setExpirationYear(String expirationYear)
    {
        this.expirationYear = expirationYear;
    }

    @Column(name = "isstatic")
    public String getIsStatic()
    {
        return isStatic;
    }

    public void setIsStatic(String isStatic)
    {
        this.isStatic = isStatic;
    }

    @Column(name = "createddate")
    public Date getCreatedDate()
    {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate)
    {
        this.createdDate = createdDate;
    }

    @Column(name = "createdby")
    public String getCreatedBy()
    {
        return createdBy;
    }

    public void setCreatedBy(String createdBy)
    {
        this.createdBy = createdBy;
    }

    @Column(name = "modifieddate")
    public Date getModifiedDate()
    {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate)
    {
        this.modifiedDate = modifiedDate;
    }

    @Column(name = "modifiedby")
    public String getModifiedBy()
    {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy)
    {
        this.modifiedBy = modifiedBy;
    }

    @Override
    public String toString()
    {
        return "ContentExtractProduct [productId=" + productId + ", productName=" + productName + ", productDescription=" + productDescription + ", productFamilyId=" + productFamilyId
                + ", expirationYear=" + expirationYear + ", isStatic=" + isStatic + ", createdDate=" + createdDate + ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate + ", modifiedBy="
                + modifiedBy + "]";
    }
    
    

}

package com.silkroute.epi.phase2.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "CLIP_HISTORY", schema = "PHASE2")
public class ClipHistory
{
    // Fields
    private Long id;
    private Long personId;
    private String endecaKey;
    @Transient
    private String printDate; // Used to display printDate
    private Date printDateAsDate; // Used to save printDate to Database as Date type
    private String locationName;
    private String offerTextShort; // discount;
    private double dollarValue = 0.0; // estSavingsAmt;
    @Transient
    private String actualSavingsAmt = "$"; // Used to display actualSavingsAmt
    private double actualSavingsAmtAsDouble; // Used to save actualSavingsAmt to Database as number
    private Date modifiedDate;

    @Id
    @Column(name = "CHSEQNO", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "PRNTHIST_SEQ")
    @SequenceGenerator(name = "PRNTHIST_SEQ", sequenceName = "SEQ_CLIP_HISTORY")
    public Long getId()
    {
        return id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    @Column(name = "CHPESEQNO")
    public Long getPersonId()
    {
        return personId;
    }

    public void setPersonId(Long personId)
    {
        this.personId = personId;
    }

    @Column(name = "CHENDECAKEY")
    public String getEndecaKey()
    {
        return endecaKey;
    }

    public void setEndecaKey(String endecaKey)
    {
        this.endecaKey = endecaKey;
    }

    @Column(name = "CHLOCATIONNAME")
    public String getLocationName()
    {
        return locationName;
    }

    public void setLocationName(String locationName)
    {
        this.locationName = locationName;
    }

    @Column(name = "CHOFFERTEXTSHORT")
    public String getOfferTextShort()
    {
        return offerTextShort;
    }

    public void setOfferTextShort(String offerTextShort)
    {
        this.offerTextShort = offerTextShort;
    }

    @Column(name = "CHMODIFIEDDATE")
    @Temporal(TemporalType.DATE)
    public Date getModifiedDate()
    {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate)
    {
        this.modifiedDate = modifiedDate;
    }

    @Column(name = "CHDOLLARVALUE")
    public double getDollarValue()
    {
        return dollarValue;
    }

    public void setDollarValue(double dollarValue)
    {
        this.dollarValue = dollarValue;
    }

    public String getPrintDate()
    {
        return printDate;
    }

    public void setPrintDate(String printDate)
    {
        this.printDate = printDate;
    }

    @Column(name = "CHPRINTDATE")
    @Temporal(TemporalType.DATE)
    public Date getPrintDateAsDate()
    {
        return printDateAsDate;
    }

    public void setPrintDateAsDate(Date printDateAsDate)
    {
        this.printDateAsDate = printDateAsDate;
    }

    public String getActualSavingsAmt()
    {
        if (!actualSavingsAmt.startsWith("$"))
            return '$' + actualSavingsAmt;
        else
            return actualSavingsAmt;
    }

    public void setActualSavingsAmt(String actualSavingsAmt)
    {
        this.actualSavingsAmt = actualSavingsAmt;
    }

    @Column(name = "CHACTUALSAVINGAMT")
    public double getActualSavingsAmtAsDouble()
    {
        return actualSavingsAmtAsDouble;
    }

    public void setActualSavingsAmtAsDouble(double actualSavingsAmtAsDouble)
    {
        this.actualSavingsAmtAsDouble = actualSavingsAmtAsDouble;
    }

}

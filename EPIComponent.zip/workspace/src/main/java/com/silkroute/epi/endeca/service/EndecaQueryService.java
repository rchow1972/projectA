package com.silkroute.epi.endeca.service;

import java.io.Serializable;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import com.endeca.navigation.ENEQuery;
import com.endeca.navigation.ENEQueryException;
import com.endeca.navigation.ENEQueryResults;
import com.endeca.navigation.HttpENEConnection;

@Service("eneQueryService")
public class EndecaQueryService implements Serializable {
	
	Logger LOGGER = Logger.getLogger(EndecaQueryService.class);
	
	public static String PMAP_KEY_ADDRESS = "ADDRESS";
	public static String PMAP_KEY_CITY = "CITY";
	public static String PMAP_KEY_STATE = "STATE";
	public static String PMAP_KEY_ZIPCODE = "ZIPCODE";
	public static String PMAP_KEY_SHORTOFFERTEXT = "OFFER_TEXT_SHORT";
	public static String PMAP_KEY_MERCHANT = "LOCATIONNAME";
	
	private enum RedemptionMethod {
		PRINT(3,"RV3"),
		MOBILE(7,"RV7"),
		CLICK(2,"RV2"),
		TEAR(1,"RV1"),
		SHOW(5,"RV5");
		
		private long redemptionId;
		private String forEndecaKey;
		
		RedemptionMethod(long redemptionId, String forEndecaKey) {
			this.redemptionId = redemptionId;
			this.forEndecaKey = forEndecaKey;
		}
		
		private long getRedemptionId() {
			return this.redemptionId;
		}
		
		private String getForEndecaKey() {
			return this.forEndecaKey;
		}
	}
	   
    @Value("${endeca.host}")
    String hostname;

    @Value("${endeca.port}")
    String port;
	
	private transient HttpENEConnection connection;

	public EndecaQueryService(){}
	
	public HttpENEConnection getConnection() {
	    if ( null == connection ) {
	        this.setConnection(hostname, Integer.parseInt(port));
	    }
		return connection;
	}

	public void setConnection(HttpENEConnection connection) {
		this.connection = connection;
	}
	
	public void setConnection(String hostname, Integer port) {
		this.connection = new HttpENEConnection(hostname, port);
	}
	
	public ENEQuery createSimpleQuery(String endecaKey) {
		ENEQuery query = new ENEQuery();
		query.setERecSpec(endecaKey);
		return query;
	}
	
	public ENEQueryResults executeQuery(ENEQuery query) {
		LOGGER.debug("Querying Endeca Host=" + connection.getHostname() + ":" + connection.getPort());
		ENEQueryResults results = null;
		try {
			results = connection.query(query);
		} catch (ENEQueryException e) {
			e.printStackTrace();
		}
		return results;
	}
	
	public String generateEndecaKeyByFields(String offer, String location, String howRedeemed) throws Exception {
		String endecaKey = "";
		String offerForKey = "";
		String locForKey = "";
		String methForKey = "";
		
		if ( null == offer || offer.trim().equals("") ) {
			throw new Exception("Offer Id Not Provided: Cannot create Endeca Key.");
		}

		if ( null == location || location.trim().equals("") ) {
			throw new Exception("Location Id Not Provided: Cannot create Endeca Key.");
		}

		if ( null == howRedeemed || howRedeemed.trim().equals("") ) {
			throw new Exception("Redemption Method Not Provided: Cannot create Endeca Key.");
		}

		if (offer.toUpperCase().contains("OF") && offer.contains("RL") && offer.contains("RV") ) {
			offerForKey = offer.substring(offer.indexOf("OF"),offer.indexOf("RL"));
			locForKey = offer.substring(offer.indexOf("RL"),offer.indexOf("RV"));
			methForKey = offer.substring(offer.indexOf("RV"));
		} else if (offer.contains("OF") && offer.contains("RL") ){
			offerForKey = offer.substring(offer.indexOf("OF"),offer.indexOf("RL"));
			locForKey = offer.substring(offer.indexOf("RL"));
			methForKey = getMethodForKey(howRedeemed);
		} else {
			offerForKey = getOfferForKey(offer);
			locForKey = getLocForKey(location);
			methForKey = getMethodForKey(howRedeemed);
		}
		
		endecaKey = offerForKey + locForKey + methForKey;
		return endecaKey;
	}
	
	private String getOfferForKey(String offer){
		String offerForKey = "";
		
		if (offer.contains("OF")) {
			offerForKey = offer;
		} else {
			offerForKey = "OF" + offer;
		}
		return offerForKey;
	}

	private String getLocForKey(String location){
		String locForKey = "";
		
		if(location.contains("RL")) {
			locForKey = location;
		} else {
			locForKey = "RL" + location;
		}
		return locForKey;
	}
	
	private String getMethodForKey(String howRedeemed) {
		String methForKey = "";
		
		if (howRedeemed.contains("RV")) {
			methForKey = howRedeemed;
		} else if(howRedeemed.length() == 1) {
			methForKey = "RV" + howRedeemed;
		} else {
			for(RedemptionMethod method: RedemptionMethod.values()) {
				if ( method.name().equalsIgnoreCase(howRedeemed) ){
					methForKey = method.getForEndecaKey();
					break;
				}
			}
		}
		return methForKey;
		
	}
	
}

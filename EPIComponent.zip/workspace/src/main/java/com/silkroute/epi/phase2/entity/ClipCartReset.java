package com.silkroute.epi.phase2.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "CLIP_CART_RESET", schema = "PHASE2")
public class ClipCartReset
{
	
	// Fields
	Long id;
	Long CPOFSEQNO;
	Long personId;
	String CPPRINTED;
	Date clipDate;
	Date printDate;
	Date expireDate;
	Long CPQTY;
	Long CPLOSEQNO;
	Long CPOFOFFERIDNO;
	Long CPLOLOCIDNO;
	Long personProductId;
	Date resetDate;
	String offerId;
	String locationId;
	String edition;
	Long membershipInstanceId;
	String couponType;
	String category;
	String redemption;
	
    // Default Constructor
    public ClipCartReset()
    {
    }

    @Id
    @Column(name = "CPSEQNO", unique = true, nullable = false)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

    @Column(name = "CPOFSEQNO")
	public Long getCPOFSEQNO() {
		return CPOFSEQNO;
	}

	public void setCPOFSEQNO(Long cPOFSEQNO) {
		CPOFSEQNO = cPOFSEQNO;
	}

    @Column(name = "CPPESEQNO")
	public Long getPersonId() {
		return personId;
	}

	public void setPersonId(Long personId) {
		this.personId = personId;
	}

    @Column(name = "CPPRINTED")
	public String getCPPRINTED() {
		return CPPRINTED;
	}

	public void setCPPRINTED(String cPPRINTED) {
		CPPRINTED = cPPRINTED;
	}

    @Column(name = "CPCLIPDATE")
	public Date getClipDate() {
		return clipDate;
	}

	public void setClipDate(Date clipDate) {
		this.clipDate = clipDate;
	}

    @Column(name = "CPPRINTDATE")
	public Date getPrintDate() {
		return printDate;
	}

	public void setPrintDate(Date printDate) {
		this.printDate = printDate;
	}

    @Column(name = "CPEXPIREDATE")
	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

    @Column(name = "CPQTY")
	public Long getCPQTY() {
		return CPQTY;
	}

	public void setCPQTY(Long cPQTY) {
		CPQTY = cPQTY;
	}

    @Column(name = "CPLOSEQNO")
	public Long getCPLOSEQNO() {
		return CPLOSEQNO;
	}

	public void setCPLOSEQNO(Long cPLOSEQNO) {
		CPLOSEQNO = cPLOSEQNO;
	}

    @Column(name = "CPOFOFFERIDNO")
	public Long getCPOFOFFERIDNO() {
		return CPOFOFFERIDNO;
	}

	public void setCPOFOFFERIDNO(Long cPOFOFFERIDNO) {
		CPOFOFFERIDNO = cPOFOFFERIDNO;
	}

    @Column(name = "CPLOLOCIDNO")
	public Long getCPLOLOCIDNO() {
		return CPLOLOCIDNO;
	}

	public void setCPLOLOCIDNO(Long cPLOLOCIDNO) {
		CPLOLOCIDNO = cPLOLOCIDNO;
	}

    @Column(name = "CPPBSEQNO")
	public Long getPersonProductId() {
		return personProductId;
	}

	public void setPersonProductId(Long personProductId) {
		this.personProductId = personProductId;
	}

    @Column(name = "CPRESETDATE")
	public Date getResetDate() {
		return resetDate;
	}

	public void setResetDate(Date resetDate) {
		this.resetDate = resetDate;
	}

    @Column(name = "CPOFFER")
	public String getOfferId() {
		return offerId;
	}

	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}

    @Column(name = "CPREDEMPTION_LOCATION")
	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

    @Column(name = "CPEDITION")
	public String getEdition() {
		return edition;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

    @Column(name = "MEMBERSHIP_INSTANCE_ID")
	public Long getMembershipInstanceId() {
		return membershipInstanceId;
	}

	public void setMembershipInstanceId(Long membershipInstanceId) {
		this.membershipInstanceId = membershipInstanceId;
	}

    @Column(name = "COUPON_TYPE")
	public String getCouponType() {
		return couponType;
	}

	public void setCouponType(String couponType) {
		this.couponType = couponType;
	}

    @Column(name = "CATEGORY")
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	
    @Column(name = "CPREDEMPTION")
    public String getRedemption()
    {
        return redemption;
    }

    public void setRedemption(String redemption)
    {
        this.redemption = redemption;
    }
}

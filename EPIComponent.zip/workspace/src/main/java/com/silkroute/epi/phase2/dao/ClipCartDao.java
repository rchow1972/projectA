/**
 * 
 */
package com.silkroute.epi.phase2.dao;

import java.util.List;

import com.silkroute.epi.dao.GenericDao;
import com.silkroute.epi.phase2.entity.ClipCart;

/**
 * @author rajesh
 *
 */
public interface ClipCartDao extends GenericDao<ClipCart> {
//    ClipCart createClipCart(ClipCart clipCart, PrintHistory printHistory);
    
    ClipCart updateClipCart(ClipCart clipCart);
    
    Integer deleteClipCart(ClipCart ClipCart);
    
    ClipCart findClipCartById(long validationId);
    
    ClipCart findClipCartByOffer(String offerId, long personId);
    
    List<ClipCart> findClipCartsByPerson(long personId);
 
    List<ClipCart> findClipCartsByPersonPage(long personId, int page);
    
    Integer resultCountClipCartByPerson(long personId);
    
    List<ClipCart> findClipCartsByPersonOfferEdition(long personId, String offerId, String edition);
}

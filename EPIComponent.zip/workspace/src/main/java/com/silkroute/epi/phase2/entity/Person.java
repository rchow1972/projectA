package com.silkroute.epi.phase2.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PERSON", schema = "PHASE2")
public class Person {

	public static final long serialVersionUID = 1;

	private long personKey;
	private String userName;
	private String email;
	private String firstName;
	private String lastName;
	private long siteId;

	// private Date dob;
	private String password;

	private Date addDate;
	
	// private Set addresses = new HashSet(0);
	// private Set<RegistrationCode> registrationCodes = new
	// HashSet<RegistrationCode>(0);
	// private Date termsAccept;
	 
	// private Date expirationDate;
	// private Date lastLogin;
	// private String noThanksFlag; // stores "Y" if user selects No thanks on
	// screen else (null)
	/**
	 * Counts number of times user is given a chance to provide full
	 * registration information.
	 */
	// private Integer collectInfoCount;

	// Constructors

	/** default constructor */
	public Person() {
		final Date NOW = new Date();
		// setAddDate(NOW);
		// setLastLogin(NOW);
	}

	/** minimal constructor */
	public Person(final String userName) {
		this();
		setUserName(userName);
	}

	public Person(final String userName, final String email,
			final String firstName, final String lastName, final long siteId) {
		this(userName);

		setEmail(email);
		setFirstName(firstName);
		setLastName(lastName);
		setSiteId(siteId);
	}

	// Property accessors

	@Id
	@Column(name = "PESEQNO", unique = true, nullable = false)
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "seqgenperson")
	@SequenceGenerator(name = "seqgenperson", sequenceName = "PHASE2.SEQ_PERSON")
	public long getPersonKey() {
		return this.personKey;
	}

	public void setPersonKey(final long personKey) {
		this.personKey = personKey;
	}

	@Column(name = "PEUSERNAME")
	public String getUserName() {
		return this.userName;
	}

	public void setUserName(final String userName) {
		this.userName = userName;
	}

	@Column(name = "PEEMAIL")
	public String getEmail() {
		return this.email;
	}

	public void setEmail(final String email) {
		this.email = (email == null ? null : email.toUpperCase());
	}

	@Column(name = "PEFIRSTNAME")
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}

	@Column(name = "PELASTNAME")
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}

	@Column(name = "PEPASSWORD")
	public String getPassword() {
		return this.password;
	}

	public void setPassword(final String password) {
		this.password = password;
	}

	/*
	 * Not Needed For this Application
	 */
	// public Set getAddresses() {
	// return this.addresses;
	// }
	//
	// public void setAddresses(final Set addresses) {
	// this.addresses = addresses;
	// }

	// public Set<RegistrationCode> getRegistrationCodes() {
	// return this.registrationCodes;
	// }
	//
	// public void setRegistrationCodes(final Set<RegistrationCode> regCodes) {
	// this.registrationCodes = regCodes;
	// }

	// @Column(name="TERMS_ACCEPT");
	// public Date getTermsAccept() {
	// return this.termsAccept;
	// }
	//
	// public void setTermsAccept(final Date termsAccept) {
	// this.termsAccept = termsAccept;
	// }

	@Column(name = "PESITEID")
	public long getSiteId() {
		return this.siteId;
	}

	public void setSiteId(final long siteId) {
		this.siteId = siteId;
	}

	@Column(name = "PEADDDT")
	public Date getAddDate() {
		return addDate;
	}

	public void setAddDate(final Date addDate) {
		this.addDate = addDate;
	}
	
	// @Column(name="PEDOB")
	// public Date getDob() {
	// return dob;
	// }
	//
	// public void setDob(final Date dob) {
	// this.dob = dob;
	// }
	//
	// @Column(name="PEEXPIREDT")
	// public Date getExpirationDate() {
	// return expirationDate;
	// }
	//
	// public void setExpirationDate(final Date expirationDate) {
	// this.expirationDate = expirationDate;
	// }
	//
	// @Column(name="PEINFO_PROMPT_COUNT")
	// public Integer getCollectInfoCount() {
	// if (this.collectInfoCount == null) {
	// this.collectInfoCount = new Integer(0);
	// }
	//
	// return this.collectInfoCount;
	// }
	//
	// public void setCollectInfoCount(final Integer collectInfoCount) {
	// this.collectInfoCount = collectInfoCount;
	// }
	//
	// public void incrementCollectInfoCount() {
	// this.collectInfoCount = new Integer(getCollectInfoCount().intValue() +
	// 1);
	// }
	//
	// public boolean isCollectInfoCountZero() {
	// return getCollectInfoCount().intValue() == 0;
	// }
	//
	// @Column(name="PELASTLOGIN")
	// public Date getLastLogin() {
	// return lastLogin;
	// }
	//
	// public void setLastLogin(final Date lastLogin) {
	// this.lastLogin = lastLogin;
	// }
	//
	// @Column(name="PEFLAG");
	// public String getNoThanksFlag() {
	// return noThanksFlag;
	// }
	//
	// public void setNoThanksFlag(String noThanksFlag) {
	// this.noThanksFlag = noThanksFlag;
	// }

	@Override
	public boolean equals(final Object other) {
		if (this == other)
			return true;
		if (other == null || !(other instanceof Person))
			return false;

		Person castOther = (Person) other;

		return ((this.getUserName() == castOther.getUserName()) || (this
				.getUserName() != null && castOther.getUserName() != null && this
				.getUserName().equals(castOther.getUserName())));
	}

	/**
	 * Returns a hash code value for the object. This method is supported for
	 * the benefit of hashtables such as those provided by
	 * <code>java.util.Hashtable</code>.
	 * 
	 * @return a hash code value for this object.
	 * @see java.lang.Object#equals(java.lang.Object)
	 * @see java.util.Hashtable
	 */
	@Override
	public int hashCode() {
		int hash = 1;

		hash = hash * 31
				+ (getUserName() == null ? 0 : getUserName().hashCode());
		hash = hash * 31 + (getEmail() == null ? 0 : getEmail().hashCode());
		// hash = hash * 31 + (getPassword() == null ? 0 :
		// getPassword().hashCode());

		return hash;
	}

	/**
	 * Returns a string representation of the object. In general, the
	 * <code>toDebugString</code> method returns a string that
	 * "textually represents" this object. The result should be a concise but
	 * informative representation that is easy for a person to read.
	 * 
	 * @return String A string representation of the object.
	 */
	public String toDebugString() {
		final String NL = System.getProperty("line.separator");

		StringBuilder result = new StringBuilder();

		result.append("Person : {").append(NL)
				.append("   personKey         : ").append(getPersonKey())
				.append(NL)
				.append("   userName          : ")
				.append(getUserName())
				.append(NL)
				.append("   email             : ")
				.append(getEmail())
				.append(NL)
				// .append("   password          : ").append(getPassword()).append(NL)
				.append("   firstName         : ")
				.append(getFirstName())
				.append(NL)
				.append("   lastName          : ")
				.append(getLastName())
				.append(NL)
				// .append("   dob               : ").append(getDob() != null ?
				// getDob().toString() : "null").append(NL)
				// .append("   termsAccept       : ").append(getTermsAccept() !=
				// null ? getTermsAccept().toString() : "null").append(NL)
				// .append("   addDate           : ").append(getAddDate() !=
				// null ? getAddDate().toString() : "null").append(NL)
				// .append("   expirationDate    : ").append(getExpirationDate()
				// != null ? getExpirationDate().toString() : "null").append(NL)
				// .append("   lastLoginDate     : ").append(getLastLogin() !=
				// null ? getLastLogin().toString() : "null").append(NL)
				.append("   siteId            : ").append(getSiteId())
				.append(NL);

		// result.append("   addresses         : [").append(NL);
		// if (getAddresses() != null)
		// {
		// for (Object addr : getAddresses())
		// {
		// result.append("      ").append(addr).append(NL);
		// }
		// }
		// result.append("   ]").append(NL);

		// result.append("   registrationCodes : [").append(NL);
		// if (getRegistrationCodes() != null)
		// {
		// for (RegistrationCode rc : getRegistrationCodes())
		// {
		// result.append("      ").append(rc).append(NL);
		// }
		// }
		// result.append("   ]").append(NL);

		return result.append("}").append(NL).toString();
	}

}
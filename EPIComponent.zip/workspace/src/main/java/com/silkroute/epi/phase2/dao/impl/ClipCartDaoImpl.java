/**
 * 
 */
package com.silkroute.epi.phase2.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.phase2.dao.ClipCartDao;
import com.silkroute.epi.phase2.entity.ClipCart;


/**
 * @author rajesh
 *
 */
@Repository
@Transactional
public class ClipCartDaoImpl extends Phase2DaoImpl<ClipCart> implements ClipCartDao
{
    private static Logger log = Logger.getLogger(ClipCartDaoImpl.class);
  
    public static int RESULTS_PER_PAGE = 15;
    
    private ClipCartDaoImpl()
    {
    }
    
    public synchronized ClipCart updateClipCart(ClipCart clipCart)
    {

        return null;
        
    }
    
    public synchronized Integer deleteClipCart(ClipCart clipCart)
    {
        phase2em.clear();

        boolean returnValue = false;
        
        Query query = phase2em.createNativeQuery("delete from PHASE2.CLIP_CART C where C.CPSEQNO = ?", ClipCart.class);
        query.setParameter(1, clipCart.getId());
        int updatedRows = (Integer) query.executeUpdate();
        
        return updatedRows;
    }
    
    public ClipCart findClipCartById(long id)
    {
    	phase2em.clear();
    	
    	Query query = phase2em.createNativeQuery("select * from PHASE2.CLIP_CART C where C.CPSEQNO = ?", ClipCart.class);
		query.setParameter(1, id);
		ClipCart result = (ClipCart) query.getSingleResult();
		return result;	
    }
    
    public ClipCart findClipCartByOffer(String offerId)
    {

        return null;
        
    }
    
	@SuppressWarnings("unchecked")
    public List<ClipCart> findClipCartsByPerson(long personId)
    {
		phase2em.clear();
		
		Query query = phase2em.createNativeQuery("select * from PHASE2.CLIP_CART C where C.CPPESEQNO = ? ORDER BY C.CPEXPIREDATE desc", ClipCart.class);
		query.setParameter(1, personId);
		List<ClipCart> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<ClipCart>() : results;
    }

	@SuppressWarnings("unchecked")
    public List<ClipCart> findClipCartsByPersonPage(long personId, int page)
    {
		phase2em.clear();
		
		Query query = phase2em.createNativeQuery("select * from PHASE2.CLIP_CART C where C.CPPESEQNO = ? ORDER BY C.CPEXPIREDATE desc", ClipCart.class);
		query.setParameter(1, personId);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);
		
		List<ClipCart> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<ClipCart>() : results;
    }
	
	public Integer resultCountClipCartByPerson(long personId) {
		phase2em.clear();
		
		Integer returnCount = 1;
		
		String sql = "select count(CPPESEQNO) from PHASE2.CLIP_CART C where C.CPPESEQNO = ?";
		if ( !"".equals(sql)) {
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, personId);
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;	
	}
	
    public List<ClipCart> findClipCartsByPersonOfferEdition(long personId, String offerId, String edition)
    {

        return null;
        
    }

	public ClipCart findClipCartByOffer(String offerId, long personId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer resultCountByPerson(long personId, int page) {
		// TODO Auto-generated method stub
		return null;
	}
}

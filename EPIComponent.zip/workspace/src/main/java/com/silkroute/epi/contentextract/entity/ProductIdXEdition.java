package com.silkroute.epi.contentextract.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(ProductIdXEditionPK.class)
@Table(schema = "CONTENT_EXTRACTION", name = "MAP_PRODUCTID_XEDITION")
public class ProductIdXEdition
{
	// Class has no PK, creating composite PK class and using it on productId/xEdition
	@Id
	public String productId;

	@Id
    private String xEdition;

	public ProductIdXEdition() {}
	
	public ProductIdXEdition(String productId, String xEdition) {
		this.productId = productId;
		this.xEdition = xEdition;
	}

	@Column(name = "PRODUCTID")
    public String getProductId()
    {
        return productId;
    }

    public void setProductId(String productId)
    {
        this.productId = productId;
    }

    @Column(name = "XEDITION")
    public String getXEdition()
    {
        return xEdition;
    }

    public void setXEdition(String xEdition)
    {
        this.xEdition = xEdition;
    }
}



package com.silkroute.epi.phase2.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "CLIP_CART", schema = "PHASE2")
public class ClipCart
{

    // Fields

    private Long id;
    private Long personId;
    private Date clipDate;
    private Date printDate;
    private Date expireDate;
    private Long personProductId;
    private String locationId;
    private String offerId;
    private String edition;
    private String couponType;
    private Long membershipInstanceId;
    private String category;
    private Long siteId;
    private Double distFromSearchLoc;
    private Double distFromPersonAddr;
    private String linkName;
    private String redemption;
    private String url;
    private String redemdedThrough;
    private Integer validationChecked = new Integer(0);

    // Constructors
    /** default constructor */
    public ClipCart()
    {
    }

    /** minimal constructor */
    public ClipCart(Long personId, Date clipDate)
    {
        this.personId = personId;
        this.clipDate = clipDate;
    }

    /** full constructor */
    public ClipCart(Long personId, Date clipDate, Date printDate, Date expireDate, Long personProductId, String locationId, String offerId, String edition, String couponType,
            Long membershipInstanceId, String category, Long siteId, Double distFromSearchLoc, Double distFromPersonAddr, String linkName)
    {
        this.personId = personId;
        this.clipDate = clipDate;
        this.printDate = printDate;
        this.expireDate = expireDate;
        this.personProductId = personProductId;
        this.locationId = locationId;
        this.offerId = offerId;
        this.edition = edition;
        this.couponType = couponType;
        this.membershipInstanceId = membershipInstanceId;
        this.category = category;
        this.siteId = siteId;
        this.distFromSearchLoc = distFromSearchLoc;
        this.distFromPersonAddr = distFromPersonAddr;
        this.linkName = linkName;
    }

    // Property accessors

    @Id
    @Column(name = "CPSEQNO", unique = true, nullable = false)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "CLIPCART_SEQ")
    @SequenceGenerator(name = "CLIPCART_SEQ", sequenceName = "SEQ_CLIP_CART")
    public Long getId()
    {
        return this.id;
    }

    public void setId(Long id)
    {
        this.id = id;
    }

    @Column(name = "CPPESEQNO")
    public Long getPersonId()
    {
        return this.personId;
    }

    public void setPersonId(Long personId)
    {
        this.personId = personId;
    }

    @Column(name = "CPCLIPDATE")
    @Temporal(TemporalType.DATE)
    public Date getClipDate()
    {
        return this.clipDate;
    }

    public void setClipDate(Date clipDate)
    {
        this.clipDate = clipDate;
    }

    @Column(name = "CPPRINTDATE")
    @Temporal(TemporalType.DATE)
    public Date getPrintDate()
    {
        return this.printDate;
    }

    public void setPrintDate(Date printDate)
    {
        this.printDate = printDate;
    }

    @Column(name = "CPEXPIREDATE")
    @Temporal(TemporalType.DATE)
    public Date getExpireDate()
    {
        return this.expireDate;
    }

    public void setExpireDate(Date expireDate)
    {
        this.expireDate = expireDate;
    }

    @Column(name = "CPPBSEQNO")
    public Long getPersonProductId()
    {
        return this.personProductId;
    }

    public void setPersonProductId(Long personProductId)
    {
        this.personProductId = personProductId;
    }

    @Column(name = "CPREDEMPTION_LOCATION")
    public String getLocationId()
    {
        return this.locationId;
    }

    public void setLocationId(String locationId)
    {
        this.locationId = locationId;
    }

    @Column(name = "CPOFFER")
    public String getOfferId()
    {
        return this.offerId;
    }

    public void setOfferId(String offerId)
    {
        this.offerId = offerId;
    }

    @Column(name = "CPEDITION")
    public String getEdition()
    {
        return this.edition;
    }

    public void setEdition(String edition)
    {
        this.edition = edition;
    }

    @Column(name = "COUPON_TYPE")
    public String getCouponType()
    {
        return this.couponType;
    }

    public void setCouponType(String couponType)
    {
        this.couponType = couponType;
    }

    @Column(name = "MEMBERSHIP_INSTANCE_ID")
    public Long getMembershipInstanceId()
    {
        return this.membershipInstanceId;
    }

    public void setMembershipInstanceId(Long membershipInstanceId)
    {
        this.membershipInstanceId = membershipInstanceId;
    }

    @Column(name = "CATEGORY")
    public String getCategory()
    {
        return this.category;
    }

    public void setCategory(String category)
    {
        this.category = category;
    }

    @Column(name = "CPSITEID")
    public Long getSiteId()
    {
        return siteId;
    }

    public void setSiteId(Long siteId)
    {
        this.siteId = siteId;
    }

    @Column(name = "CPDISTANCEFROMSEARCHLOC")
    public Double getDistFromSearchLoc()
    {
        return distFromSearchLoc;
    }

    public void setDistFromSearchLoc(Double distFromSearchLoc)
    {
        this.distFromSearchLoc = distFromSearchLoc;
    }

    @Column(name = "CPDISTANCEFROMPERSONADDR")
    public Double getDistFromPersonAddr()
    {
        return distFromPersonAddr;
    }

    public void setDistFromPersonAddr(Double distFromPersonAddr)
    {
        this.distFromPersonAddr = distFromPersonAddr;
    }

    @Column(name = "CPLINKNAME")
    public String getLinkName()
    {
        return linkName;
    }

    public void setLinkName(String linkName)
    {
        this.linkName = linkName;
    }

    @Column(name = "CPREDEMPTION")
    public String getRedemption()
    {
        return redemption;
    }

    public void setRedemption(String redemption)
    {
        this.redemption = redemption;
    }

    @Column(name = "CPURL")
    public String getUrl()
    {
        return url;
    }

    public void setUrl(String url)
    {
        this.url = url;
    }

    @Column(name = "REDEMED_THROUGH")
    public String getRedemdedThrough()
    {
        return redemdedThrough;
    }

    public void setRedemdedThrough(String redemdedThrough)
    {
        this.redemdedThrough = redemdedThrough;
    }

    @Column(name = "VALIDATION_CHECKED")
    public Integer getValidationChecked()
    {
        return validationChecked;
    }

    public void setValidationChecked(Integer validationChecked)
    {
        this.validationChecked = validationChecked;
    }

    /*
     * public String getMerchantName() { return merchantName; } public void setMerchantName(String merchantName) {
     * this.merchantName = merchantName; }
     */

    public boolean equals(Object other)
    {
        if ((this == other)) return true;
        if ((other == null)) return false;
        if (!(other instanceof ClipCart)) return false;
        ClipCart castOther = (ClipCart) other;

        return ((this.getPersonId() == castOther.getPersonId()) || (this.getPersonId() != null && castOther.getPersonId() != null && this.getPersonId().equals(castOther.getPersonId())))
                && ((this.getClipDate() == castOther.getClipDate()) || (this.getClipDate() != null && castOther.getClipDate() != null && this.getClipDate().equals(castOther.getClipDate())));
    }
}

package com.silkroute.epi.ocpcontrol.dao.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.contentextract.entity.ContentExtractProduct;
import com.silkroute.epi.ocpcontrol.dao.OmsOrderSessionDao;
import com.silkroute.epi.ocpcontrol.entity.OmsOrderSession;

@Transactional(readOnly=true)
@Repository
public class OmsOrderSessionDaoImpl extends OcpControlDaoImpl<OmsOrderSession> implements OmsOrderSessionDao {

	public List<OmsOrderSession> getOrdersByGroupId(String fundraisingGroupId) {
		ocpControlEm.clear();

		String statement = 
//				"select * " +  
				"select OSS.GROUP_ID, OSS.SELLER_ID, OSS.OMS_ORDER_SESSION_ID, OSS.AFFILIATE_ID, OSS.CREATED_DATE, OSS.OMS_ORDER_SESSION_STATUS_ID, OSS.FIRST_NAME, OSS.LAST_NAME, OSS.ITEM_TOTAL, OSS.GRAND_TOTAL "+
				"from OCP_CONTROL.OMS_ORDER_SESSION OSS " +
				"where OSS.GROUP_ID = ? " +
				"order by OSS.CREATED_DATE desc ";
        Query query = ocpControlEm.createNativeQuery(statement, OmsOrderSession.class);
        query.setParameter(1, fundraisingGroupId.toUpperCase());
        
        List<OmsOrderSession> results = query.getResultList();

        return results.isEmpty() ? new ArrayList<OmsOrderSession>() : results;
	}
	
	public List<Object[]> getOrdersByGroupIdAndStartDate(String fundraisingGroupId, String startDate) {
		ocpControlEm.clear();

		String statement = 
//				"select * " +  
				"select OSS.GROUP_ID, OSS.SELLER_ID, OSS.OMS_ORDER_SESSION_ID, OSS.AFFILIATE_ID, OSS.CREATED_DATE, OSS.OMS_ORDER_SESSION_STATUS_ID, OSS.FIRST_NAME, OSS.LAST_NAME, OSS.ITEM_TOTAL, OSS.GRAND_TOTAL "+
				"from OCP_CONTROL.OMS_ORDER_SESSION OSS " +
				"where OSS.GROUP_ID = ? " +
				"and OSS.CREATED_DATE >= ? " +
				"order by OSS.CREATED_DATE desc ";
        Query query = ocpControlEm.createNativeQuery(statement);//, OmsOrderSession.class);
        query.setParameter(1, fundraisingGroupId.toUpperCase());
        query.setParameter(2, startDate.toUpperCase());
        
//        List<OmsOrderSession> results = query.getResultList();
        List<Object[]> results = query.getResultList();

        return results.isEmpty() ? new ArrayList<Object[]>() : results;
	}
	
	public List<OmsOrderSession> getOrdersByGroupIdWithDateRange(String fundraisingGroupId, String startDate, String endDate) {
		ocpControlEm.clear();

		String statement = 
//				"select * " +  
				"select OSS.GROUP_ID, OSS.SELLER_ID, OSS.OMS_ORDER_SESSION_ID, OSS.AFFILIATE_ID, OSS.CREATED_DATE, OSS.OMS_ORDER_SESSION_STATUS_ID, OSS.FIRST_NAME, OSS.LAST_NAME, OSS.ITEM_TOTAL, OSS.GRAND_TOTAL "+
				"from OCP_CONTROL.OMS_ORDER_SESSION OSS " +
				"where OSS.GROUP_ID = ? " +
				"and OSS.CREATED_DATE >= ? " +
				"and OSS.CREATED_DATE <= ? " +
				"order by OSS.CREATED_DATE desc ";
        Query query = ocpControlEm.createNativeQuery(statement, OmsOrderSession.class);
        query.setParameter(1, fundraisingGroupId.toUpperCase());
        query.setParameter(2, startDate.toUpperCase());
        query.setParameter(3, endDate.toUpperCase());
        
        
        List<OmsOrderSession> results = query.getResultList();

        return results.isEmpty() ? new ArrayList<OmsOrderSession>() : results;
	}
}

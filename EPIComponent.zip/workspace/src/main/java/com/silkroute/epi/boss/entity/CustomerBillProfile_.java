package com.silkroute.epi.boss.entity;

import javax.persistence.metamodel.SingularAttribute;

public class CustomerBillProfile_{
	public static volatile SingularAttribute<CustomerBillProfile, Long> customerId;
	public static volatile SingularAttribute<CustomerBillProfile, String> firstName;
	public static volatile SingularAttribute<CustomerBillProfile,String> lastName;
	public static volatile SingularAttribute<CustomerBillProfile,String> address1;
	public static volatile SingularAttribute<CustomerBillProfile,String> address2;
	public static volatile SingularAttribute<CustomerBillProfile,String> city;
	public static volatile SingularAttribute<CustomerBillProfile,String> state;
	public static volatile SingularAttribute<CustomerBillProfile,String> zipcode;
}

package com.silkroute.epi.phase2.dao.impl;

import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.phase2.dao.SiteDao;
import com.silkroute.epi.phase2.entity.Site;

@Repository
@Transactional
public class SiteDaoImpl extends Phase2DaoImpl<Site> implements SiteDao {

	public String findSiteNameBySiteId(Long siteId) {
		phase2em.clear();
		
		String siteName;
		
		String sqlString = "select S.NAME from PHASE2.SITES S where S.SITEID = ?";
		Query query = phase2em.createNativeQuery(sqlString);
		query.setParameter(1, siteId);
		siteName = (String) query.getSingleResult();
		return siteName;
	}
	
	public Site findSiteBySiteId(Long siteId) {
		phase2em.clear();
		
		Site site;
		
		String sqlString = "select * from PHASE2.SITES S where S.SITEID = ?";
		Query query = phase2em.createNativeQuery(sqlString, Site.class);
		query.setParameter(1, siteId);
		site = (Site) query.getSingleResult();
		return site;	
	}

}

package com.silkroute.epi.contentextract.entity;

import java.io.Serializable;

@SuppressWarnings("serial")
public class ProductIdXEditionPK implements Serializable {

	// NO PK On this Table - Creating an ID that is composite key for product id/xedition	

	protected String productId;
	protected String xEdition;
	
	public ProductIdXEditionPK() {}
	
	public ProductIdXEditionPK(String productId, String xEdition) {
		this.productId = productId;
		this.xEdition = xEdition;
	}
}
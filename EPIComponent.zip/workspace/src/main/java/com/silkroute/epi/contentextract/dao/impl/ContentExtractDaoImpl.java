package com.silkroute.epi.contentextract.dao.impl;

import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.dao.GenericDao;



public abstract class ContentExtractDaoImpl<T> implements GenericDao<T> {

	//Getting error on lazy load without the EXTENDED
	@PersistenceContext(type=PersistenceContextType.EXTENDED, unitName = "contentExtractionEmf")
	public EntityManager em;

	private Class<T> type;

	public ContentExtractDaoImpl() {
		Type t = getClass().getGenericSuperclass();
		ParameterizedType pt = (ParameterizedType) t;
		type = (Class) pt.getActualTypeArguments()[0];
	}

	@Transactional
	public T persist(final T t) {
		this.em.persist(t);
		return t;
	}

	public void delete(final Object id) {
		this.em.remove(this.em.getReference(type, id));
	}

	public T find(final Object id) {
		return (T) this.em.find(type, id);
	}

	public T update(final T t) {
		return this.em.merge(t);
	}
	
	public EntityManager getEntityManager(){
	    return em;
	}
}

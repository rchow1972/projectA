package com.silkroute.epi.ocpcontrol.entity;

import java.sql.Blob;
import java.sql.Clob;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(schema="OCP_CONTROL", name="OMS_ORDER_SESSION")
public class OmsOrderSession {
//	OMS_ORDER_SESSION_ID	NUMBER(19,0)
//	ORDER_SESSION_UUID	VARCHAR2(50 CHAR)
//	ORDER_SESSION_DATA	BLOB
//	USER_ID	NUMBER(19,0)
//	ADMIN_USER_ID	NUMBER(10,0)
//	PARENT_OMS_ORDER_ID	NUMBER(19,0)
//	FIRST_NAME	VARCHAR2(50 CHAR)
//	LAST_NAME	VARCHAR2(50 CHAR)
//	ZIP_CODE	VARCHAR2(10 CHAR)
//	PHONE	VARCHAR2(20 CHAR)
//	EMAIL_ADDRESS	VARCHAR2(100 CHAR)
//	GRAND_TOTAL	NUMBER(10,0)
//	CREATED_DATE	DATE
//	OPENED_DATE	DATE
//	PICKED_DATE	DATE
//	SHIPPED_DATE	DATE
//	HELD_DATE	DATE
//	UPDATED_DATE	DATE
//	OMS_ORDER_SESSION_STATUS_ID	NUMBER(10,0)
//	OMS_ORDER_SESSION_TYPE_ID	NUMBER(10,0)
//	CMS_SITE_ID	NUMBER(10,0)
//	ADDRESS_LINE_2	VARCHAR2(255 CHAR)
//	ADDRESS_LINE_1	VARCHAR2(255 CHAR)
//	CITY	VARCHAR2(50 CHAR)
//	STATE	VARCHAR2(50 CHAR)
//	CANCEL_REASON_ID	NUMBER(10,0)
//	APARTMENT	VARCHAR2(20 CHAR)
//	PO_NUMBER	VARCHAR2(50 CHAR)
//	COST_CENTER	VARCHAR2(20 CHAR)
//	DEPARTMENT	VARCHAR2(20 CHAR)
//	PROJECT_NUMBER	VARCHAR2(50 CHAR)
//	ITEM_NUMBER	CLOB
//	EARLIEST_DELIVERY_DATE	DATE
//	LATEST_DELIVERY_DATE	DATE
	
//	public static String selectFields = "OMS_ORDER_SESSION_ID, CREATED_DATE, OMS_ORDER_SESSION_STATUS_ID, FIRST_NAME, LAST_NAME, GRAND_TOTAL";
	
	Long omsOrderSessionId;
	String orderSessionUUID; //	VARCHAR2(50 CHAR)
	Blob orderSessionData; //	BLOB
	Long userId; //	NUMBER(19,0)
	Long adminUserId; //	NUMBER(10,0)
	Long parentOmsOrderId; //	NUMBER(19,0)
	String firstName; //	VARCHAR2(50 CHAR)
	String lastName; //	VARCHAR2(50 CHAR)
	String zipCode; //	VARCHAR2(10 CHAR)
	String phone; //	VARCHAR2(20 CHAR)
	String emailAddress; //	VARCHAR2(100 CHAR)
	Long grandTotal; //	NUMBER(10,0)
	Date createdDate; //	DATE
	Date openedDate; //	DATE
	Date pickedDate; //	DATE
	Date shippedDate; //	DATE
	Date heldDate; //	DATE
	Date updatedDate; //	DATE
	Long omsOrderSessionStatusId; //	NUMBER(10,0)
	Long omsOrderSessionTypeId; //	NUMBER(10,0)
	Long cmsSiteId; //	NUMBER(10,0)
	String addressLine2; //	VARCHAR2(255 CHAR)
	String addressLine1; //	VARCHAR2(255 CHAR)
	String city; //	VARCHAR2(50 CHAR)
	String state; //	VARCHAR2(50 CHAR)
	String cancelReasonId; //	NUMBER(10,0)
	String apartment; //	VARCHAR2(20 CHAR)
	String poNumber; //	VARCHAR2(50 CHAR)
	String costCenter; //)	VARCHAR2(20 CHAR)
	String department; //	VARCHAR2(20 CHAR)
	String projectNumber; //	VARCHAR2(50 CHAR)
	Clob itemNumber; //	CLOB
	Date earliestDeliveryDate; //	DATE
	Date latestDeliveryDate; //	DATE
	
	String groupId;
	String sellerId;
	String affiliateId;
	Long itemTotal;
	
	@Id
	@Column(name="OMS_ORDER_SESSION_ID", unique=true, nullable=false)
	public Long getOmsOrderSessionId() {
		return omsOrderSessionId;
	}
	public void setOmsOrderSessionId(Long omsOrderSessionId) {
		this.omsOrderSessionId = omsOrderSessionId;
	}
	
	@Column(name="ORDER_SESSION_UUID")
	public String getOrderSessionUUID() {
		return orderSessionUUID;
	}
	public void setOrderSessionUUID(String orderSessionUUID) {
		this.orderSessionUUID = orderSessionUUID;
	}
	
	@Column(name="ORDER_SESSION_DATA")
	public Blob getOrderSessionData() {
		return orderSessionData;
	}
	public void setOrderSessionData(Blob orderSessionData) {
		this.orderSessionData = orderSessionData;
	}
	
	@Column(name="USER_ID")
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	
	@Column(name="ADMIN_USER_ID")
	public Long getAdminUserId() {
		return adminUserId;
	}
	public void setAdminUserId(Long adminUserId) {
		this.adminUserId = adminUserId;
	}
	
	@Column(name="PARENT_OMS_ORDER_ID")
	public Long getParentOmsOrderId() {
		return parentOmsOrderId;
	}
	public void setParentOmsOrderId(Long parentOmsOrderId) {
		this.parentOmsOrderId = parentOmsOrderId;
	}
	
	@Column(name="FIRST_NAME")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	
	@Column(name="LAST_NAME")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	@Column(name="ZIP_CODE")
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
	
	@Column(name="PHONE")
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@Column(name="EMAIL_ADDRESS")
	public String getEmailAddress() {
		return emailAddress;
	}
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	@Column(name="GRAND_TOTAL")
	public Long getGrandTotal() {
		return grandTotal;
	}
	public void setGrandTotal(Long grandTotal) {
		this.grandTotal = grandTotal;
	}
	
	@Column(name="CREATED_DATE")
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	@Column(name="OPENED_DATE")
	public Date getOpenedDate() {
		return openedDate;
	}
	public void setOpenedDate(Date openedDate) {
		this.openedDate = openedDate;
	}
	
	@Column(name="PICKED_DATE")
	public Date getPickedDate() {
		return pickedDate;
	}
	public void setPickedDate(Date pickedDate) {
		this.pickedDate = pickedDate;
	}
	
	@Column(name="SHIPPED_DATE")
	public Date getShippedDate() {
		return shippedDate;
	}
	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}
	
	@Column(name="HELD_DATE")
	public Date getHeldDate() {
		return heldDate;
	}
	public void setHeldDate(Date heldDate) {
		this.heldDate = heldDate;
	}
	
	@Column(name="UPDATED_DATE")
	public Date getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}
	
	@Column(name="OMS_ORDER_SESSION_STATUS_ID")
	public Long getOmsOrderSessionStatusId() {
		return omsOrderSessionStatusId;
	}
	public void setOmsOrderSessionStatusId(Long omsOrderSessionStatusId) {
		this.omsOrderSessionStatusId = omsOrderSessionStatusId;
	}
	
	@Column(name="OMS_ORDER_SESSION_TYPE_ID")
	public Long getOmsOrderSessionTypeId() {
		return omsOrderSessionTypeId;
	}
	public void setOmsOrderSessionTypeId(Long omsOrderSessionTypeId) {
		this.omsOrderSessionTypeId = omsOrderSessionTypeId;
	}
	
	@Column(name="CMS_SITE_ID")
	public Long getCmsSiteId() {
		return cmsSiteId;
	}
	public void setCmsSiteId(Long cmsSiteId) {
		this.cmsSiteId = cmsSiteId;
	}
	
	@Column(name="ADDRESS_LINE_2")
	public String getAddressLine2() {
		return addressLine2;
	}
	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}
	
	@Column(name="ADDRESS_LINE_1")
	public String getAddressLine1() {
		return addressLine1;
	}
	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}
	
	@Column(name="CITY")
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	
	@Column(name="STATE")
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	@Column(name="CANCEL_REASON_ID")
	public String getCancelReasonId() {
		return cancelReasonId;
	}
	public void setCancelReasonId(String cancelReasonId) {
		this.cancelReasonId = cancelReasonId;
	}
	
	@Column(name="APARTMENT")
	public String getApartment() {
		return apartment;
	}
	public void setApartment(String apartment) {
		this.apartment = apartment;
	}
	
	@Column(name="PO_NUMBER")
	public String getPoNumber() {
		return poNumber;
	}
	public void setPoNumber(String poNumber) {
		this.poNumber = poNumber;
	}
	
	@Column(name="COST_CENTER")
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	
	@Column(name="DEPARTMENT")
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	
	@Column(name="PROJECT_NUMBER")
	public String getProjectNumber() {
		return projectNumber;
	}
	public void setProjectNumber(String projectNumber) {
		this.projectNumber = projectNumber;
	}
	
	@Column(name="ITEM_NUMBER")
	public Clob getItemNumber() {
		return itemNumber;
	}
	public void setItemNumber(Clob itemNumber) {
		this.itemNumber = itemNumber;
	}
	
	@Column(name="EARLIEST_DELIVERY_DATE")
	public Date getEarliestDeliveryDate() {
		return earliestDeliveryDate;
	}
	public void setEarliestDeliveryDate(Date earliestDeliveryDate) {
		this.earliestDeliveryDate = earliestDeliveryDate;
	}
	
	@Column(name="LATEST_DELIVERY_DATE")
	public Date getLatestDeliveryDate() {
		return latestDeliveryDate;
	}
	public void setLatestDeliveryDate(Date latestDeliveryDate) {
		this.latestDeliveryDate = latestDeliveryDate;
	}
	
	@Column(name="GROUP_ID")
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	
	@Column(name="SELLER_ID")
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	
	@Column(name="AFFILIATE_ID")
	public String getAffiliateId() {
		return affiliateId;
	}
	public void setAffiliateId(String affiliateId) {
		this.affiliateId = affiliateId;
	}
	
	@Column(name="ITEM_TOTAL")
	public Long getItemTotal() {
		return itemTotal;
	}
	public void setItemTotal(Long itemTotal) {
		this.itemTotal = itemTotal;
	}
}

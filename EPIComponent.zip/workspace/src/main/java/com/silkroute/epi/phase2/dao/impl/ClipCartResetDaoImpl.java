/**
 * 
 */
package com.silkroute.epi.phase2.dao.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.silkroute.epi.phase2.dao.ClipCartResetDao;
import com.silkroute.epi.phase2.entity.ClipCartReset;

@Repository
@Transactional
public class ClipCartResetDaoImpl extends Phase2DaoImpl<ClipCartReset> implements ClipCartResetDao
{
    private static Logger log = Logger.getLogger(ClipCartResetDaoImpl.class);
  
    public static int RESULTS_PER_PAGE = 15;
    
    private ClipCartResetDaoImpl()
    {
    }
    
    public synchronized ClipCartReset updateClipCart(ClipCartReset clipCart)
    {
        return null;
    }
    
    public synchronized boolean deleteClipCart(ClipCartReset ClipCart)
    {
        return false;
    }
    
    public ClipCartReset findClipCartById(long id)
    {
        return null;
    }
    
    public ClipCartReset findClipCartByOffer(String offerId)
    {
        return null;
    }
    
    public List<ClipCartReset> findClipCartsByPersonOfferEdition(long personId, String offerId, String edition)
    {

        return null;
        
    }

	public ClipCartReset findClipCartByOffer(String offerId, long personId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Integer resultCountByPerson(long personId, int page) {
		// TODO Auto-generated method stub
		return null;
	}

	public ClipCartReset updateClipReset(ClipCartReset clipCartReset) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean deleteClipReset(ClipCartReset ClipCartReset) {
		// TODO Auto-generated method stub
		return false;
	}

	public ClipCartReset findClipResetById(long validationId) {
		// TODO Auto-generated method stub
		return null;
	}

	public ClipCartReset findClipResetByOffer(String offerId, long personId) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<ClipCartReset> findClipResetsByPerson(long personId) {
	    phase2em.clear();
	    
		Query query = phase2em.createNativeQuery("select * from PHASE2.CLIP_CART_RESET C where C.CPPESEQNO = ? ORDER BY C.CPRESETDATE desc", ClipCartReset.class);
		query.setParameter(1, personId);
		List<ClipCartReset> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<ClipCartReset>() : results;
    }

	public Integer resultCountClipCartByPerson(long personId) {
	    phase2em.clear();
	    
		Integer returnCount = 1;
		
		String sql = "select count(CPPESEQNO) from PHASE2.CLIP_CART_RESET C where C.CPPESEQNO = ?";
		if ( !"".equals(sql)) {
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, personId);
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;	
	}

	public List<ClipCartReset> findClipResetsByPersonPage(long personId, int page) {
	    phase2em.clear();
	    
		Query query = phase2em.createNativeQuery("select * from PHASE2.CLIP_CART_RESET C where C.CPPESEQNO = ? ORDER BY C.CPRESETDATE desc", ClipCartReset.class);
		query.setParameter(1, personId);
		query.setMaxResults(RESULTS_PER_PAGE);
		query.setFirstResult((page - 1) * RESULTS_PER_PAGE);
		
		List<ClipCartReset> results = query.getResultList();

		return results.isEmpty() ? new ArrayList<ClipCartReset>() : results;
	}

	public Integer resultCountClipResetByPerson(long personId) {
	    phase2em.clear();
	    
		Integer returnCount = 1;
		
		String sql = "select count(CPPESEQNO) from PHASE2.CLIP_CART_RESET C where C.CPPESEQNO = ?";
		if ( !"".equals(sql)) {
			Query query = phase2em.createNativeQuery(sql);
			query.setParameter(1, personId);
			BigDecimal res = (BigDecimal) query.getSingleResult();
			
			int result = res.divide(new BigDecimal(RESULTS_PER_PAGE), BigDecimal.ROUND_UP).intValue();
			
			returnCount = result;
		}
		return returnCount == 0 ? 1 : returnCount;	
	}

	public List<ClipCartReset> findClipResetsByPersonOfferEdition(
			long personId, String offerId, String edition) {
		// TODO Auto-generated method stub
		return null;
	}
}

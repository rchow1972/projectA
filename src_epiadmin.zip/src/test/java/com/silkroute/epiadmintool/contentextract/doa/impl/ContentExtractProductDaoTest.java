//package com.silkroute.epiadmintool.contentextract.doa.impl;
////
//import java.util.ArrayList;
//
//import javax.sql.DataSource;
////
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
//import org.springframework.test.context.transaction.TransactionConfiguration;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.silkroute.epi.contentextract.dao.ContentExtractProductDao;
//import com.silkroute.epi.contentextract.entity.ContentExtractProduct;
//
////
//@ContextConfiguration(locations = { "classpath:/appContext-test-epiadmintool.xml" })
//@TransactionConfiguration(transactionManager = "contentExtractionTransactionManager", defaultRollback = false)
//@Transactional
//public class ContentExtractProductDaoTest extends AbstractTransactionalJUnit4SpringContextTests
//{
//    @Autowired
//    ContentExtractProductDao productDao;
//    
//    
//    @Override
//    public void setDataSource(DataSource dataSource)
//    {
//        // TODO Auto-generated method stub
//        super.setDataSource(dataSource);
//    }
//
////
////    @Test
////    public void findByProductIdTest()
////    {
////
////        System.out.println("findByProductId");
////        ContentExtractProduct product = (ContentExtractProduct) productDao.findByProductId("MP0000000032");
////        
////        
////        System.out.println("findByProductId Found: " + product.getProductId());	
//////        for (ProductIdXEdition map: mappings) {
//////        	System.out.println("userId: " + map.getProductId());	
//////        }
////    }
////
//    @Test
//    public void findByProductNameTest()
//    {
//
//        System.out.println("findByProductId");
//       ArrayList<ContentExtractProduct> mappings = (ArrayList<ContentExtractProduct>) productDao.findByProductName("Detroit");
//      
//        
//        System.out.println("findByProductId Found: " + mappings.size());	
//        for (ContentExtractProduct map: mappings) {
//        	System.out.println("userId: " + map.getProductId());	
//      }
//    }
//   
//}

//package com.silkroute.epiadmintool.contentextract.doa.impl;
//
//import static org.junit.Assert.*;
//
//import java.util.ArrayList;
//
//import org.junit.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.junit4.AbstractTransactionalJUnit4SpringContextTests;
//import org.springframework.test.context.transaction.TransactionConfiguration;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.silkroute.epiadmintool.contentextract.dao.ProductIdXEditionDao;
//import com.silkroute.epiadmintool.contentextract.dao.impl.ProductIdXEditionDaoImpl;
//import com.silkroute.epiadmintool.contentextract.entity.ProductIdXEdition;
//
//
//@ContextConfiguration(locations = { "classpath:/appContext-test-epiadmintool.xml" })
//@TransactionConfiguration(transactionManager = "transactionManager", defaultRollback = false)
//@Transactional
//public class ProductIdXEditionDaoTest extends AbstractTransactionalJUnit4SpringContextTests
//{
//    @Autowired @Qualifier("emf")
//    ProductIdXEditionDao mappingDao;
//
//    @Test
//    public void findByProductIdTest()
//    {
//
//        System.out.println("findByProductId ---------------------------------------------------------------------------");
//        ArrayList<ProductIdXEdition> mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByProductId("MP0000001275");
//        
//        
//        System.out.println("findByProductId Found: " + mappings.size());	
//        for (ProductIdXEdition map: mappings) {
//        	System.out.println("productMapping: " + map.getProductId() + "," + map.getXEdition());	
//        }
//        System.out.println("findByProductId ---------------------------------------------------------------------------");
//        
//        assertTrue(mappings.size() > 0);
//    }
//    
//    @Test
//    public void findByXEditionTest()
//    {
//
//        System.out.println("findByXEdition -----------------------------------------------------------------------------");
//        ArrayList<ProductIdXEdition> mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByXEdition("999EDI00012622");
//        
//        System.out.println("findByXEdition Found: " + mappings.size());
//        for (ProductIdXEdition map: mappings) {
//        	System.out.println("productMapping: " + map.getProductId() + "," + map.getXEdition());	
//        }
//        System.out.println("findByXEdition -----------------------------------------------------------------------------");
//        
//        assertTrue(mappings.size() > 0);
//    }
//    
//    @Test
//    public void findByProductNameTest()
//    {
//
//        System.out.println("findByProductName --------------------------------------------------------------------------");
//        ArrayList<ProductIdXEdition> mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByProductName("Detroit");
//
//        
//        System.out.println("findByProductName Found: " + mappings.size());	
////        for (ProductIdXEdition map: mappings) {
////        	System.out.println("userId: " + map.getProductId());	
////        }
//        System.out.println("findByProductName --------------------------------------------------------------------------");
//        
//        assertTrue(mappings.size() > 0);
//    }
//  
////    //@Test
//    public void joinOnProductIdTest()
//    {
//
//        System.out.println("joinOnProductId");
//        ArrayList<Object> mappings = (ArrayList<Object>) mappingDao.joinOnProductId("MP0000001275");
//
//        
//        System.out.println("joinOnProductId Found: " + mappings.size());	
//        for (Object map: mappings) {
//        	System.out.println("Join On Id: " + map.toString());
//        	if (map instanceof String[]) {
//        		for ( String s: (String[]) map) {
//        			System.out.println(s);
//        		}
//        	}
//        }
//    }
//    
//    @Test
//    public void findByProductIdPageTest()
//    {
//
//        System.out.println("findByProductIdPage ---------------------------------------------------------------------------");
//        ArrayList<ProductIdXEdition> mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByProductIdPage("MP0000001275", 1);
//        
//        
//        System.out.println("findByProductId Found: " + mappings.size());	
//        for (ProductIdXEdition map: mappings) {
//        	System.out.println("productMapping: " + map.getProductId() + "," + map.getXEdition());	
//        }
//        System.out.println("findByProductIdPage ---------------------------------------------------------------------------");
//        
//        assertTrue(mappings.size() > 0);
//        
//        assertFalse(mappings.size() > ProductIdXEditionDaoImpl.RESULTS_PER_PAGE);
//    }
//    
//    @Test
//    public void findByXEditionPageTest()
//    {
//
//        System.out.println("findByXEditionPage -----------------------------------------------------------------------------");
//        ArrayList<ProductIdXEdition> mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByXEditionPage("999EDI00012622", 1);
//        
//        System.out.println("findByXEdition Found: " + mappings.size());
//        for (ProductIdXEdition map: mappings) {
//        	System.out.println("productMapping: " + map.getProductId() + "," + map.getXEdition());	
//        }
//        System.out.println("findByXEditionPage -----------------------------------------------------------------------------");
//        
//        assertTrue(mappings.size() > 0);
//        
//        assertFalse(mappings.size() > ProductIdXEditionDaoImpl.RESULTS_PER_PAGE);
//    }
//    
//    @Test
//    public void findByProductNamePageTest()
//    {
//
//        System.out.println("findByProductNamePage --------------------------------------------------------------------------");
//        ArrayList<ProductIdXEdition> mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByProductNamePage("Delete", 1);
//
//        
//        System.out.println("findByProductNamePage 1 Found: " + mappings.size());	
//        for (ProductIdXEdition map: mappings) {
//        	System.out.println("productMapping: " + map.getProductId() + "," + map.getXEdition());	
//        }
//        
//        assertTrue(mappings.size() > 0);
//        assertFalse(mappings.size() > ProductIdXEditionDaoImpl.RESULTS_PER_PAGE);
//        
//        System.out.println("findByProductNamePage --------------------------------------------------------------------------");
//        
//        mappings = (ArrayList<ProductIdXEdition>) mappingDao.findByProductNamePage("Delete", 2);
//        
//        System.out.println("findByProductNamePage 2 Found: " + mappings.size());	
//        for (ProductIdXEdition map: mappings) {
//        	System.out.println("productMapping: " + map.getProductId() + "," + map.getXEdition());	
//        }
//        
//        assertTrue(mappings.size() > 0);
//        
//        assertFalse(mappings.size() > ProductIdXEditionDaoImpl.RESULTS_PER_PAGE);
//        
//        System.out.println("findByProductNamePage --------------------------------------------------------------------------");
//
//    }
//    
//    @Test
//    public void resultCountAsPageTest()
//    {
//
//        System.out.println("resultCountAsPage  --------------------------------------------------------------------------");
//        Integer count = mappingDao.resultCountAsPage("productName", "Detroit");
//        
//        System.out.println("resultCountAsPage.productName Found: " + count);	
//        assertTrue(count > 0);
//        
//        System.out.println("resultCountAsPage --------------------------------------------------------------------------");
//
//        count = mappingDao.resultCountAsPage("productName", "delete");
//        
//        System.out.println("resultCountAsPage.productName Found: " + count);	
//        assertTrue(count > 0);
//        
//        System.out.println("resultCountAsPage --------------------------------------------------------------------------");
//        
//        count = mappingDao.resultCountAsPage("productId", "MP0000001275");
//        
//        System.out.println("resultCountAsPage.productName Found: " + count);	
//        assertTrue(count > 0);
//        
//        System.out.println("resultCountAsPage --------------------------------------------------------------------------");
//        
//        count = mappingDao.resultCountAsPage("xEdition", "999EDI00012622");
//        
//        System.out.println("resultCountAsPage.productName Found: " + count);	
//        assertTrue(count > 0);
//        
//        System.out.println("resultCountAsPage --------------------------------------------------------------------------");
//    }    
//    
//}

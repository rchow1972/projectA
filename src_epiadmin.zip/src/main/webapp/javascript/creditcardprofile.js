/*
 * File: creditcardprofile.js
 * Purpose: Provide interaction to webservices for Credit Card Profile Tool
 * Created By: Daniel Buckley email: daniel.buckley@silkrouteglobal.com
 * And: Christian Vespa email: christian.vespa@silkrouteglobal.com
 */
$(document).ready(function() {
	// SET THE CURRENT YEAR + 10 YEARS AS POSSIBLE CC EXPIRY YR DATES.
	var year = new Date();
	var selectYearList = document.getElementById("ccYear");
	
	for( var i = 0; i <= 10; i++) {
		var option = document.createElement("option");
		option.value = year.getFullYear() + i;
		option.text = year.getFullYear() + i;
		selectYearList.appendChild(option);
	}

    // loading items
    var docHeight = $(document).height(); // gets doc size

    var opts = { // options for the loading spinner
        lines : 13, // The number of lines to draw
        length : 20, // The length of each line
        width : 10, // The line thickness
        radius : 30, // The radius of the inner circle
        corners : 1, // Corner roundness (0..1)
        rotate : 0, // The rotation offset
        direction : 1, // 1: clockwise, -1: counterclockwise
        color : '#000', // #rgb or #rrggbb or array of colors
        speed : 1, // Rounds per second
        trail : 100, // Afterglow percentage
        shadow : true, // Whether to render a shadow
        hwaccel : false, // Whether to use hardware acceleration
        className : 'spinner', // The CSS class to assign to the spinner
        zIndex : 2e9, // The z-index (defaults to 2000000000)
        top : 'auto', // Top position relative to parent in px
        left : 'auto' // Left position relative to parent in px
    };
    var spinner = new Spinner(opts); // the initial creation of the spinner

    var loading = function(value) { // the function to have a overlay and spinner well the database is being pulled for
                                    // information

        if (value === "start") {
            $("body").append("<div id='loading'></div><div id='overlay'></div>"); // adds the two divs just after the
                                                                                    // <body>

            var target = document.getElementById('loading');

            $("#overlay").height(docHeight);
            spinner.spin(target);
            return;
        }
        if (value === "stop") {
            spinner.stop();
            $("div[id=overlay]").remove(); // removes the two divs
            $("div[id=loading]").remove();
            return;
        }
    };

    // jQuery Listener: Results Clear
    $('input[id=searchCustomerId]').click(function(event) {
        bossSearchAndResults();
    });
    var bossSearchAndResults = function() {
        console.log("Submit For Profile()");
        loading("start"); // makes overlay and starts loading spinner

    	var url = "customerProfileById.cmd";
    	var formData = {
    		'customerId': $('input[id=customerId]').val()
    	};
    	
        $.ajax({ // this is the actual ajax request call
            url : url, // the url where we want to POST
            type : "POST", // define the type of HTTP verb we want to use (POST for our form)
            dataType : "json", // what type of data do we expect back from the server
            data : formData, // our row of data sent as a data object
            error : function() { // this is ran if ajax returns is a fail, front-end failure
            	console.log("Fail - Submit Profile");
                frontendFail("search");
                return;
            },
            success : function(json) { // this is ran if the ajax returns a success, front-end success
                console.log("Pass - Submit Profile");
                setCustomerFields(json);
            }
        });
    };
    
    // jQuery Listener: Results Clear
    $('input[id=clearResults]').click(function(event) {
        resetFields();
    });
    var resetFields = function() {
    	// Clear Search Fields
    	$('input[id=customerId]').val("");
    	
        // Clear Customer Fields
		$('input[id=bill_to_forename]').val("");
		$('input[id=bill_to_surname]').val("");
		$('input[id=bill_to_address_line1]').val("");
		$('input[id=bill_to_address_line2]').val("");
		$('input[id=bill_to_address_city]').val("");
		//$('input[id=bill_to_address_country]').val("");
		$('input[id=bill_to_address_state]').val("");
		$('input[id=bill_to_address_postal_code]').val("");
		
		// Clear CC Profile Fields
		$('input[id=ccName]').val("");
		$('input[id=ccNumber]').val("");
		// NOT SURE HOW TO CLEAR
		$('#ccMonth').val("00");
		$('#ccYear').val("0000");
//		$('input[id=card_cvn]').val("");
		
		$("#HiddenPaymentForm").children().remove();
		$("#HiddenPaymentForm").attr("action","");
    };


    // jQuery Listener: Submit For Profile
    $('input[id=submitForProfile]').click(function(event) {
    	var readyToSubmit = validateForProfile();
    	if (readyToSubmit == 'true'){
        	submitForProfile();
    	} else {
        	alert('Request Failed\n' + readyToSubmit );
            console.log('[error] Request Failed: ' + readyToSubmit );
            return; // return so nothing else is ran
    	}
    });   
    // Submit For Profile
    var submitForProfile = function() {
        console.log("Submit For Profile()");
//        loading("start"); // makes overlay and starts loading spinner

        $("#HiddenPaymentForm").prepend('<input type="hidden" name="card_type" value="' + getCreditCardType("ccNumber") + '" />');
        $("#HiddenPaymentForm").prepend('<input type="hidden" name="card_number" value="' + $("#ccNumber").val() + '" />');
        $("#HiddenPaymentForm").prepend('<input type="hidden" name="card_expiry_date" value="' + $('#ccMonth').val() + '-' + $('#ccYear').val() + '" />');
        $("#HiddenPaymentForm").submit();
    };

    // Validate For Profile
    var validateForProfile = function() {
        console.log("Validate For Profile()");
        var message = "Confirm all fields are correctly filled.";

        var notEmptyCust = $('input[id=bill_to_forename]').val() != "" &&
		$('input[id=bill_to_forename]').val() != "" &&
		$('input[id=bill_to_surname]').val() != "" &&
		$('input[id=bill_to_address_line1]').val() != "" &&
		$('input[id=bill_to_address_city]').val() != "" && 
		$('input[id=bill_to_address_state]').val() != "" && 
		$('input[id=bill_to_address_postal_code]').val() != "";
		
        var notEmptyCC = getCreditCardType("ccNumber") != "";
        var mo = $('#ccMonth').val();
        var notEmptyMo = mo != "00";
        var yr = $('#ccYear').val();
        var notEmptyYr = yr != "0000";

        var notBefore = false;
        var today = new Date();
        if( yr > today.getFullYear() ){
        	notBefore = true;
        } else if( yr == today.getFullYear() ){
        	if ( mo >= (today.getMonth() + 1)){
        		notBefore = true;
        	} else {
        		notBefore = false;
        	}
        } else {
        	notBefore = false;
        }
        
        if (notEmptyCust && notEmptyCC && notEmptyMo && notEmptyYr && notBefore) {
        	return 'true';
        } else {
        	message = '';
        	if(!notEmptyCust){
        		message += 'Missing Required Customer Fields\n';
        	}
        	if(!notEmptyCC){
        		message += 'Invalid or Missing Credit Card Number\n';
        	}
        	if(!notEmptyMo || !notEmptyYr){
        		message += 'Credit Card Expiration Date Not Set\n';
        	} else if(!notBefore){
        		message += 'Invalid or Expired Credit Card Expiration Date\n';
        	}
        	
        	return message;
        }
    };

    
    // Helper Method to set the display table
    var setCustomerFields = function(response) {
		$("#HiddenPaymentForm").children().remove();
		$("#HiddenPaymentForm").attr("action","");
		
        loading("stop"); // stops overlay

        console.log(response.responseMessage);
        if (response.responseStatus == 'success') { // to check to see if our back-end failed but still sent an response
			// Set Customer Fields
			$('input[id=bill_to_forename]').val(response.data.firstName);
			$('input[id=bill_to_surname]').val(response.data.lastName);
			$('input[id=bill_to_address_line1]').val(response.data.address1);
			$('input[id=bill_to_address_line2]').val(response.data.address2);
			$('input[id=bill_to_address_city]').val(response.data.city);
			$('input[id=bill_to_address_state]').val(response.data.state);
			$('input[id=bill_to_address_postal_code]').val(response.data.zipcode);

//			var countryVal = 'US';
//			var isZipcodeNumeric = !isNaN(response.data.zipcode);
//			
//			if(isZipcodeNumeric) {
//				countryVal = 'US';
//			} else {
//				countryVal = 'CA';
//			}
			$('input[id=bill_to_address_country]').val(response.data.country);
			
	        var signedParams = response.data.signedParameters;
	        var signedKeys = Object.keys(signedParams);
	        for (var pc = 0; pc < signedKeys.length; pc++) {
	        	var key = signedKeys[pc];
	        	var val = signedParams[key];
	        	$("#HiddenPaymentForm").prepend('<input type="hidden" name="' + key + '" value="' + val + '" />');
	        }
	        $("#HiddenPaymentForm").prepend('<input type="hidden" name="signature" value=' + response.data.signature + ' />');
	        $("#HiddenPaymentForm").attr("action",response.data.action);
        } else {
        	alert('Request Failed\n' + response.data.responseMessage);
            console.log('[error] Request Failed: ' + response.data.responseMessage);
            return; // return so nothing else is ran
        }
    };
    
    // Helper Method to display Front-end Failure
    var frontendFail = function(value) {
        loading("stop");
        alert('Request failed.');
        console.log('[error] Request failed.');
        return;
    };
});

// Credit Card Type By FieldName
function getCreditCardType(fieldname) {

    var ccNumber = $('input[id=' + fieldname + ']').val();

    var prefixLength1 = ccNumber.substring(0,1);
    var prefixLength2 = ccNumber.substring(0,2);
    var prefixLength4 = ccNumber.substring(0,4);

    if (typeof ccNumber === 'undefined')
        return "";

    if (ccNumber.length === 16 && prefixLength1 === "4") return "001";
    if (ccNumber.length === 16 && (Number(prefixLength2) > 50 && Number(prefixLength2) < 56 )) return "002";
    if (ccNumber.length === 15 &&  (prefixLength2 === "34" || prefixLength2 === "37"))  return "003";
    if (ccNumber.length === 16 &&  prefixLength4 === "6011")  return "004";

    return "";
};
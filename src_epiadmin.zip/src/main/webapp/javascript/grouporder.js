/*
 * File: grouporder.js
 * Purpose: Provide interaction to webservices for Group Order Attribute Report
 * Created By: Daniel Buckley 
 * And: Christian Vespa email: christian.vespa@silkrouteglobal.com
 */
$(document).ready(function() {
    // Fields
    // Saved Parameters for User Pages
    var userPage = 1;
    var maxUserPage = 1;

    // Saved Parameters for Pagination Search
    var searchType = null;
    var searchParam = null;

    // Saved Parameters for Current Row Selection
    var selectProductId = null;
    var selectXEdition = null;

    // loading items
    var docHeight = $(document).height(); // gets doc size

    var opts = { // options for the loading spinner
        lines : 13, // The number of lines to draw
        length : 20, // The length of each line
        width : 10, // The line thickness
        radius : 30, // The radius of the inner circle
        corners : 1, // Corner roundness (0..1)
        rotate : 0, // The rotation offset
        direction : 1, // 1: clockwise, -1: counterclockwise
        color : '#000', // #rgb or #rrggbb or array of colors
        speed : 1, // Rounds per second
        trail : 100, // Afterglow percentage
        shadow : true, // Whether to render a shadow
        hwaccel : false, // Whether to use hardware acceleration
        className : 'spinner', // The CSS class to assign to the spinner
        zIndex : 2e9, // The z-index (defaults to 2000000000)
        top : 'auto', // Top position relative to parent in px
        left : 'auto' // Left position relative to parent in px
    };
    var spinner = new Spinner(opts); // the initial creation of the spinner

    var loading = function(value) { // the function to have a overlay and spinner well the database is being pulled for
                                    // information

        if (value === "start") {
            $("body").append("<div id='loading'></div><div id='overlay'></div>"); // adds the two divs just after the
                                                                                    // <body>

            var target = document.getElementById('loading');

            $("#overlay").height(docHeight);
            spinner.spin(target);
            return;
        }
        if (value === "stop") {
            spinner.stop();
            $("div[id=overlay]").remove(); // removes the two divs
            $("div[id=loading]").remove();
            return;
        }
    };

    // Web Service Calls
    // Search By Group Order Id (by Page)
    var searchByGroupOrderId = function(groupOrderId, page) {
        console.log("Search By Group Order Id: " + groupOrderId + " " + page);

        loading("start"); // makes overlay and starts loading spinner

        searchType = "groupOrderId";
        searchParam = groupOrderId;

        var url = "searchByGroupOrderId.cmd";
        var formData = { // the data to send back to the server
        	groupOrderId : groupOrderId,
            page : page
        };

        $.ajax({ // this is the actual ajax request call
            url : url, // the url where we want to POST
            type : "POST", // define the type of HTTP verb we want to use (POST for our form)
            dataType : "json", // what type of data do we expect back from the server
            data : formData, // our row of data sent as a data object
            error : function() { // this is ran if ajax returns is a fail, front-end failure
                frontendFail("search");
                return;
            },
            success : function(json) { // this is ran if the ajax returns a success, front-end success
                console.log("Pass - Parse Data");
                setContent(json);
            }
        });
    };

    // Results By Page
    var resultsByPage = function(searchType, searchParam, page) {
        console.log("Pagination Search (" + searchType + "): " + searchParam + " " + page);

        loading("start");

        var url = "resultsByPage.cmd";
        var formData = {
            searchType : searchType,
            searchParam : searchParam,
            page : page
        };

        $.ajax({
            url : url,
            type : "POST",
            dataType : "json",
            data : formData,
            error : function() {
                frontendFail("page");
                return;
            },
            success : function(json) {
                console.log("Pass - Parse Data");
                setContent(json);
            }
        });
    };

    // Pagination
    var pagination = function(page) {
        console.log("Paging");

        if (searchType == "productName" || searchType == "productId" || searchType == "xEdition") {
            resultsByPage(searchType, searchParam, page);
        } else {
            console.log("Fail");
        }
    };

    // jQuery Listener to Web Service call

    // Search By Product Name
    $('input[id=searchGroupOrderId]').click(function(event) {
    	searchByGroupOrderId($('input[id=groupOrderId]').val(), 1);
    });

    // Results Clear
    $('input[id=clearResults]').click(function(event) {
        clearResults();
        resetFields();
    });

     // Pagination First Page
    $('input[id=foundFirst]').click(function(event) {
        pagination(1);
    });
    // Pagination Previous Page
    $('input[id=foundPrev]').click(function(event) {
        var gotoPage = parseInt(userPage) - 1;
        if (gotoPage > 0) {
            pagination(gotoPage);
        } else {
            pagination(1);
        }
    });

    // Pagination Next Page
    $('input[id=foundNext]').click(function(event) {
        var gotoPage = parseInt(userPage) + 1;
        if (gotoPage <= maxUserPage) {
            pagination(gotoPage);
        } else {
            pagination(maxUserPage);
        }
    });

    // Pagination Last Page
    $('input[id=foundLast]').click(function(event) {
        pagination(maxUserPage);
    });

    // Pagination Go To Page
    $('input[id=foundGo]').click(function(event) {
        var gotoPage = parseInt($('input[id=foundGoto]').val());
        pagination(gotoPage);
    });

    // Helper Methods
    // Helper Methods to Clear Results
    var clearResults = function() {
        // Clear Table
        $('tbody[id=product-list-tbody]').empty();

        // Clear Search Fields
        $('input[id=groupOrderId]').val("");
        searchType = null;
        searchParam = null;

        selectProductId = null;
        selectXEdition = null;

        // Clear Pagination
        setPagination(1, 1);
    };

    // Helper Method to set Pagination display and var
    var setPagination = function(currentPage, maxPage) {
        userPage = currentPage;
        maxUserPage = maxPage;

        $('span[id=foundPage]').text("Page " + userPage + " of " + maxUserPage);
    };

    // Helper Method to clear edit fields
    var resetFields = function() {
        // Clear Search Field
    };

    // Helper Method to set the display table
    var setContent = function(response) {
        setPagination(response.page, response.numberOfPages);

        loading("stop"); // stops overlay

        console.log(response.responseMessage);
        if (response.responseStatus == 'success') { // to check to see if our back-end failed but still sent an response

            $("tbody[id=product-list-tbody]").empty(); // Make sure table is cleared
            // Populate Data
            for (var r = 0; r < response.data.length; r++) {
                var addRow = " <tr id='row" + r + "' >" +
                		"<td align='left'>" + response.data[r].groupId + "</td>" +
                		"<td align='left'>" + response.data[r].sellerId + "</td>" +
                		"<td align='left'>" + response.data[r].orderNumber + "</td>" +
                		"<td align='left'>" + response.data[r].orderSource + "</td>" +
                		"<td align='left'>" + response.data[r].orderDate + "</td>" +
                		"<td align='left'>" + response.data[r].orderStatus + "</td>" +
                		"<td align='left'>" + response.data[r].purchaserName + "</td>" +
                		"<td align='left'>" + response.data[r].orderQuantity + "</td>" +
                		"<td align='right'>" + response.data[r].orderAmount + "</td>" +
                		"</tr> "
                $("tbody[id=product-list-tbody]").append(addRow);
//                $("tr[id=row" + r + "]").click(function() { // add event listener to each row created
//                    var rowIndex = $(this);
//                });
            }
        } else {
            alert('Request Failed\n' + response.responseMessage);
            console.log('[error] Request Failed: ' + response.responseMessage);
            return; // return so nothing else is ran
        }
    };

    // Helper Method to display Front-end Failure
    var frontendFail = function(value) {
        loading("stop");
        if (value == "search") {
            alert('Request failed please retry search.');
            console.log('[error] Request failed please retry search.');
            return;
        } else if (value == "add") {
            alert('Request to Add Row: ' + $("input[id=addProductId]").val() + '|' + $("input[id=addXEdition]").val()
                    + 'failed.');
            console.log('[error] Request to Add Row: ' + $("input[id=addProductId]").val() + '|'
                    + $("input[id=addXEdition]").val() + 'failed.');
            return;
        } else if (value == "edit") {
            alert('Request to Edit Row: ' + $("input[id=editProductId]").val() + '|'
                    + $("input[id=editXEdition]").val() + 'failed.');
            console.log('[error] Request to Edit Row: ' + $("input[id=editProductId]").val() + '|'
                    + $("input[id=editXEdition]").val() + 'failed.');
            return;
        } else if (value == "delete") {
            alert('Request to Delete Row: ' + $("input[id=editProductId]").val() + '|'
                    + $("input[id=editXEdition]").val() + 'failed.');
            console.log('[error] Request to Delete Row: ' + $("input[id=editProductId]").val() + '|'
                    + $("input[id=editXEdition]").val() + 'failed.');
            return;
        } else if (value == "page") {
            alert('Request for Page failed.');
            console.log('[error] Request for Page failed.');
            return;
        } else {
            alert('Request failed.');
            console.log('[error] Request failed.');
            return;
        }
    };
});
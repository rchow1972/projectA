/*
 * File: redemptionreset.js
 * Purpose: Provide interaction to webservices for Redemption Reset Tool
 * Created By: Daniel Buckley 
 * And: Christian Vespa email: christian.vespa@silkrouteglobal.com
 */
$(document).ready(function() { // when document is fully rendered
    var userPage = 1;
    var maxUserPage = 1;
    var redempPage = 1;
    var maxRedempPage = 1;
    var resetPage = 1;
    var maxResetPage = 1;
    var storedUserId = null;
    var storedRedemptionId = null;
    var docHeight = $(document).height();

    var opts = { // options for the loading spinner
        lines : 13, // The number of lines to draw
        length : 20, // The length of each line
        width : 10, // The line thickness
        radius : 30, // The radius of the inner circle
        corners : 1, // Corner roundness (0..1)
        rotate : 0, // The rotation offset
        direction : 1, // 1: clockwise, -1: counterclockwise
        color : '#000', // #rgb or #rrggbb or array of colors
        speed : 1, // Rounds per second
        trail : 100, // Afterglow percentage
        shadow : true, // Whether to render a shadow
        hwaccel : false, // Whether to use hardware acceleration
        className : 'spinner', // The CSS class to assign to the spinner
        zIndex : 2e9, // The z-index (defaults to 2000000000)
        top : 'auto', // Top position relative to parent in px
        left : 'auto' // Left position relative to parent in px
    };
    var spinner = new Spinner(opts); // the initial creation of the spinner
    // the function to have a overlay and spinner well the database is being pulled for information
    var loading = function(value) { 

        if (value === "start") {
            // adds the two divs just after the <body>
            $("body").append("<div id='loading'></div><div id='overlay'></div>"); 

            var target = document.getElementById('loading');

            $("#overlay").height(docHeight);
            spinner.spin(target);
            return;
        }
        if (value === "stop") {
            spinner.stop();
            $("div[id=overlay]").remove(); // removes the two divs
            $("div[id=loading]").remove();
            return;
        }
    };

    var resetPrintAjax = function() { // function to call to reset a print
        console.log('[log] resetPrintAjax function started');

        loading("start"); // makes overlay and starts loading spinner

        var rowData = { // the row data to send back to the server
            'redemptionId' : storedRedemptionId,
            'page' : redempPage
        };

        $.ajax({ // this is the actual ajax request call
            type : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url : 'resetPrint.cmd', // the url where we want to POST
            data : rowData, // our row of data sent as a data object
            dataType : 'json' // what type of data do we expect back from the server
        }).success(function(data) { // this is ran if the ajax returns a success, front-end success
            if (data.responseStatus == "fail") { // to check to see if our back-end failed but still sent an response
                loading("stop"); // stops overlay
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return; // return so nothing else is ran
            }

            $("div[id=container-people-list]").css("display", "none"); // hides list
            $("div[id=container-people-details]").css("display", "none"); // hides detail
            $("div[id=container-people-redemptions]").css("display", "block"); // shows redemption
            $("div[id=container-people-resets]").css("display", "none"); // hide resets

            for (var i = 0; i < data.data.length; i++) { // for loops over each data row
                $('tbody[id=people-redemptions-list-tbody]').append('<tr><td align="left">' + data.data[i].merchant
                        + '</td><td align="left">' + data.data[i].address + '</td><td align="left">'
                        + data.data[i].offerDetail + '</td><td align="left">' + data.data[i].redeemMethod
                        + '</td><td align="left">' + data.data[i].redeemDate
                        + '</td><td style="width:35px;"><input type="button" name="reset" id="redemption'
                        + data.data[i].redemptionId + '" value="Reset"></td></tr>');
                // stores the redemption id with in the reset button for that row
                $('input[id=redemption' + data.data[i].redemptionId + ']').data('redempId', data.data[i].redemptionId); 
                // sets an event to each of the reset buttons that are made from the response
                $('input[id=redemption' + data.data[i].redemptionId + ']').bind('click', function(event) { 
                    console.log('[log] click event of Redemption Reset');
                    // pulls the stored redemption id that is hidden with in the reset button
                    storedRedemptionId = $('input[id=' + event.target.id + ']').data('redempId'); 
                    console.log('[log] redemptionId: ' + storedRedemptionId);
                    // to clear the redemption list
                    if ($('tbody[id=people-redemptions-list-tbody]').children().length > 0) { 
                        $('tbody[id=people-redemptions-list-tbody]').empty();
                        console.log("[log] Cleared Redemption Table");
                    }
                    resetPrintAjax(); // have new button do it over again
                });
            }
            redempPage = data.page;
            maxRedempPage = data.numberOfPages;
            $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
            loading("stop");
        }).error(function(data) { // this is ran if ajax returns is a fail, front-end failure
            loading("stop");
            alert('Request failed please retry search.');
            console.log('[error] Request failed please retry search.');
            return;
        });
        console.log('[log] resetPrintAjax function ended');
    };

    var findPrintByPersonAjax = function() { // function to list all prints of a given user that can be reset
        console.log('[log] findPrintByPerson function started');

        loading("start");

        var rowData = { // the row data to send back to the server
            'userId' : storedUserId,
            'page' : redempPage
        };

        $.ajax({ // this is the actual ajax request call
            type : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url : 'findPrintByPerson.cmd', // the url where we want to POST
            data : rowData, // our row of data sent as a data object
            dataType : 'json' // what type of data do we expect back from the server
        }).success(function(data) { // this is ran if the ajax returns a success, front-end success
            if (data.responseStatus == "fail") { // to check to see if our back-end failed but still sent an response
                loading("stop");
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return; // return so nothing else is ran
            }

            $("div[id=container-people-list]").css("display", "none");
            $("div[id=container-people-details]").css("display", "none");
            $("div[id=container-people-redemptions]").css("display", "block");
            $("div[id=container-people-resets]").css("display", "none");

            for (var i = 0; i < data.data.length; i++) { // for loops over each data row
                $('tbody[id=people-redemptions-list-tbody]').append('<tr><td align="left">' + data.data[i].merchant
                        + '</td><td align="left">' + data.data[i].address + '</td><td align="left">'
                        + data.data[i].offerDetail + '</td><td align="left">' + data.data[i].redeemMethod
                        + '</td><td align="left">' + data.data[i].redeemDate
                        + '</td><td style="width:98px;"><input type="button" name="reset" id="redemption'
                        + data.data[i].redemptionId + '" style="width: 100%;" value="Reset"></td></tr>');
                // stores the redemption id with in the reset button for that row
                $('input[id=redemption' + data.data[i].redemptionId + ']').data('redempId', data.data[i].redemptionId); 
                // sets an event to each of the reset buttons that are made from the response
                $('input[id=redemption' + data.data[i].redemptionId + ']').bind('click', function(event) { 
                    console.log('[log] click event of Redemption Reset');
                    storedRedemptionId = $('input[id=' + event.target.id + ']').data('redempId');
                    console.log('[log] redemptionId: ' + storedRedemptionId);
                    if ($('tbody[id=people-redemptions-list-tbody]').children().length > 0) {
                        $('tbody[id=people-redemptions-list-tbody]').empty();
                        console.log("[log] Cleared Redemption Table");
                    }
                    resetPrintAjax();
                });
            }
            redempPage = data.page;
            maxRedempPage = data.numberOfPages;
            $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
            loading("stop");
        }).error(function(data) { // this is ran if ajax returns is a fail, front-end failure
            loading("stop");
            alert('Request failed please retry search.');
            console.log('[error] Request failed please retry search.');
            return;
        });
        console.log('[log] findPrintByPerson function ended');
    };

    var findResetByPersonAjax = function() { // function to list all prints of a given user that can be reset
        console.log('[log] findResetByPerson function started');

        loading("start");

        var rowData = { // the row data to send back to the server
            'userId' : storedUserId,
            'page' : redempPage
        };

        $.ajax({ // this is the actual ajax request call
            type : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url : 'findResetByPerson.cmd', // the url where we want to POST
            data : rowData, // our row of data sent as a data object
            dataType : 'json' // what type of data do we expect back from the server
        }).success(function(data) { // this is ran if the ajax returns a success, front-end success
            if (data.responseStatus == "fail") { // to check to see if our back-end failed but still sent an response
                loading("stop");
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return; // return so nothing else is ran
            }

            $("div[id=container-people-list]").css("display", "none");
            $("div[id=container-people-details]").css("display", "none");
            $("div[id=container-people-redemptions]").css("display", "none");
            $("div[id=container-people-resets]").css("display", "block");

            for (var i = 0; i < data.data.length; i++) { // for loops over each data row
                $('tbody[id=people-resets-list-tbody]').append('<tr><td align="left">' + data.data[i].merchant
                        + '</td><td align="left">' + data.data[i].address + '</td><td align="left">'
                        + data.data[i].offerDetail + '</td><td align="left">' + data.data[i].redeemMethod
                        + '</td><td align="left">' + data.data[i].redeemDate + '</td><td align="left">'
                        + data.data[i].resetDate + '</td></tr>');
            }
            resetPage = data.page;
            maxResetPage = data.numberOfPages;
            $('span[id=resetsListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
            loading("stop");
        }).error(function(data) { // this is ran if ajax returns is a fail, front-end failure
            loading("stop");
            alert('Request failed please retry search.');
            console.log('[error] Request failed please retry search.');
            return;
        });
        console.log('[log] findResetByPerson function ended');
    };

    var emailReminderAjax = function() { // function to call to send a email reminder of users password
        console.log('[log] emailReminderAjax function started');

        loading("start");

        var rowData = { // the row data to send back to the server
            'userId' : storedUserId
        };

        $.ajax({ // this is the actual ajax request call
            type : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url : 'emailReminder.cmd', // the url where we want to POST
            data : rowData, // our row of data sent as a data object
            dataType : 'json' // what type of data do we expect back from the server
        }).success(function(data) { // this is ran if the ajax returns a success, front-end success
            if (data.responseStatus == "fail") { // to check to see if our back-end failed but still sent an response
                loading("stop");
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return; // return so nothing else is ran
            }

            loading("stop");

            alert('Request Success\n' + data.responseMessage);
            console.log('[log] Request Success: ' + data.responseMessage);
        }).error(function(data) { // this is ran if ajax returns is a fail, front-end failure
            loading("stop");
            alert('Request failed please retry send.');
            console.log('[error] Request failed please retry send.');
            return;
        });
        console.log('[log] emailReminderAjax function ended');
    };

    var findDetailsPersonAjax = function() { // function to list all prints of a given user that can be reset
        console.log('[log] findDetailsPerson function started');

        loading("start");

        var rowData = { // the row data to send back to the server
            'userId' : storedUserId,
            'page' : redempPage
        };

        $.ajax({ // this is the actual ajax request call
            type : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url : 'findPerson.cmd', // the url where we want to POST
            data : rowData, // our row of data sent as a data object
            dataType : 'json' // what type of data do we expect back from the server
        }).success(function(data) { // this is ran if the ajax returns a success, front-end success
            if (data.responseStatus == "fail") { // to check to see if our back-end failed but still sent an response
                loading("stop");
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return; // return so nothing else is ran
            }

            $("div[id=container-people-list]").css("display", "none");
            $("div[id=container-people-details]").css("display", "block");
            $("div[id=container-people-redemptions]").css("display", "none");
            $("div[id=container-people-resets]").css("display", "none");

            $('tbody[id=people-details-list-tbody]').append('<tr> <td align="left" class="blue" style="width:1%;height:27px;">Firstname:</td>'
                    + '<td align="left" colspan="2" class="gray">'
                    + data.data[0].firstName
                    + '</td> </tr>'
                    + '<tr> <td align="left" class="blue" style="width:1%;height:27px;">Lastname:</td>'
                    + '<td align="left" colspan="2" class="gray">'
                    + data.data[0].lastName
                    + '</td> </tr>'
                    + '<tr> <td align="left" class="blue" style="width:1%;height:27px;">Email</td>'
                    + '<td align="left" colspan="2" class="gray">'
                    + data.data[0].email
                    + '</td> </tr>'
                    + '<tr> <td align="left" class="blue" style="width:1%;height:27px;">Username:</td>'
                    + '<td align="left" colspan="2" class="gray">'
                    + data.data[0].userName
                    + '</td> </tr>'
                    + '<tr> <td align="left" class="blue" style="width:1%;height:27px;">UserId:</td>'
                    + '<td align="left" colspan="2" class="gray">'
                    + data.data[0].userId
                    + '</td> </tr>'
                    + '<tr> <td align="left" class="blue" style="width:1%;height:27px;">Membership Date:</td>'
                    + '<td align="left" colspan="2" class="gray">'
                    + data.data[0].addDate
                    + '</td> </tr>'
                    + '<tr> <td align="left" class="blue" style="width:1%;height:27px;">SiteName:</td>'
                    + '<td align="left" colspan="2" class="gray">('
                    + data.data[0].siteId
                    + ') '
                    + data.data[0].siteName
                    + '</td> </tr>'
                    + '<tr> <th align="left" class="blue" style="width:1%;height:27px;">Password:</th>'
                    + '<td align="left" class="gray" style="width:100%;">'
                    + data.data[0].password
            		+ '</td><td class="gray"> <input type="button" id="emailReminder" value="Email Reminder"/></td> </tr>');

            $('input[id=emailReminder]').bind('click', function(event) { // sets an event to the redemption button
                console.log('[log] click event of User\'s Email Reminder button');
                console.log('[log] userId: ' + storedUserId);

                emailReminderAjax(); // emailReminder.cmd
            });

            loading("stop");
        }).error(function(data) { // this is ran if ajax returns is a fail, front-end failure
            loading("stop");
            alert('Request failed please retry search.');
            console.log('[error] Request failed please retry search.');
            return;
        });
        console.log('[log] findDetailsPerson function ended');
    };

    var findPersonAjax = function(page) { // function to search the list of all user
        console.log('[log] findPerson function started');

        loading("start");

        var formData = { // the form data to send back to the server
            'firstName' : $('input[name=firstName]').val(),
            'lastName' : $('input[name=lastName]').val(),
            'userName' : $('input[name=userName]').val(),
            'userId' : $('input[name=userId]').val(),
            'orderConfirmationNumber' : $('input[name=orderConfirmationNumber]').val(),
            'cancelConfirmationNumber' : $('input[name=cancelConfirmationNumber]').val(),
            'page' : page,
            'likeSearch' : $('input[id=likeSearch]').prop('checked')
        };

        $.ajax({ // this is the actual ajax request call
            type : 'POST', // define the type of HTTP verb we want to use (POST for our form)
            url : 'findPerson.cmd', // the url where we want to POST
            headers : {
                Accept : "application/json",
                produces : "application/json"
            },
            data : formData, // our form data to sent as a data object
            dataType : 'json' // what type of data do we expect back from the server
        }).success(function(data) { // this is ran if the ajax returns a success, front-end success
            if (data.responseStatus == "fail") { // to check to see if our back-end failed but still sent an response
                loading("stop");
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return; // return so nothing else is ran
            }

            $("div[id=container-people-list]").css("display", "block");
            $("div[id=container-people-details]").css("display", "none");
            $("div[id=container-people-redemptions]").css("display", "none");
            $("div[id=container-people-resets]").css("display", "none");

            for (var i = 0; i < data.data.length; i++) { // for loops over each data row
                $('tbody[id=people-list-tbody]').append('<tr> <td align="left">' + data.data[i].firstName
                        + '</td><td align="left">' + data.data[i].lastName + '</td><td align="left">'
                        + data.data[i].userName + '</td><td align="left">' + data.data[i].email
                        + '</td><td align="left">' + data.data[i].userId + '</td><td align="left">('
                        + data.data[i].siteId + ') ' + data.data[i].siteName
                        + '</td><td style="width:85px;"><input type="button" id="user' + data.data[i].userId
                        + '" value="Select User"></td></tr>');
                // stores the user id with in the redemption button for that row
                $('input[id=user' + data.data[i].userId + ']').data('userId', data.data[i].userId);
                // sets an event to each of the select user buttons that are made from the response
                $('input[id=user' + data.data[i].userId + ']').bind('click', function(event) { 
                    console.log('[log] click event of Select User button');
                    storedUserId = $('input[id=' + event.target.id + ']').data('userId');
                    console.log('[log] userId: ' + storedUserId);
                    if ($('tbody[id=people-detail-list-tbody]').children().length > 0) {
                        $('tbody[id=people-detail-list-tbody]').empty();
                        console.log("[log] Cleared User Detail Table");
                    }
                    findDetailsPersonAjax(redempPage);
                });
            }
            $('span[id=foundx]').text(data.data.length + ' Users');
            userPage = data.page;
            maxUserPage = data.numberOfPages;
            $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
            loading("stop");
        }).error(function(data) { // this is ran if ajax returns is a fail, front-end failure
            loading("stop");
            alert('Request failed please retry search.');
            console.log('[error] Request failed please retry search.');
            return;
        });
        console.log('[log] findPerson function ended');
    };

    $('input[id=redemptionButton]').bind('click', function(event) { // sets an event to the redemption button
        console.log('[log] click event of User\'s Redemption button');
        console.log('[log] userId: ' + storedUserId);
        if ($('tbody[id=people-redemptions-list-tbody]').children().length > 0) {
            $('tbody[id=people-redemptions-list-tbody]').empty();
            console.log("[log] Cleared Redemption Table");
        }
        findPrintByPersonAjax();
        $('span[id=redempUser]').text('Redemptions of userId: ' + storedUserId);
    });

    $('input[id=resetButton]').bind('click', function(event) { // sets an event to each of the redemption buttons that
                                                                // are made from the response
        console.log('[log] click event of User\'s Reset button');
        console.log('[log] userId: ' + storedUserId);
        if ($('tbody[id=people-redemptions-list-tbody]').children().length > 0) {
            $('tbody[id=people-redemptions-list-tbody]').empty();
            console.log("[log] Cleared Redemption Table");
        }
        findResetByPersonAjax();
        $('span[id=resetUser]').text('Resets of userId: ' + storedUserId);
    });

    $('input[id=search]').click(function(event) { // the click event for the finduser button
        $('tbody[id=people-list-tbody]').empty();
        $('span[id=foundx]').text('X number of Users');
        userPage = 1;
        maxUserPage = 1;
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        $('th[id=resetDate]').text('');
        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        $('tbody[id=people-details-list-tbody]').empty();
        findPersonAjax(userPage);
    });

    $('input[id=foundFirst]').click(function(event) { // the click event for the back to first page button
        $('th[id=resetDate]').text('');

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        userPage = 1;
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");
        findPersonAjax(userPage);
    });

    $('input[id=foundPrev]').click(function(event) { // the click event for the back to previous page button
        $('th[id=resetDate]').text('');

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        userPage = (parseInt(userPage) - 1);
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");
        findPersonAjax(userPage);
    });

    $('input[id=foundNext]').click(function(event) { // the click event for the go to next page button
        $('th[id=resetDate]').text('');

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        userPage = (parseInt(userPage) + 1);
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");
        findPersonAjax(userPage);
    });

    $('input[id=foundLast]').click(function(event) { // the click event for the go to last page button
        $('th[id=resetDate]').text('');

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        userPage = maxUserPage;
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");
        findPersonAjax(userPage);
    });

    $('input[id=foundGo]').click(function(event) { // the click event for the goto # page button
        $('th[id=resetDate]').text('');

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        userPage = parseInt($('input[id=foundGoto]').val());
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");
        findPersonAjax(userPage);
    });
    
    $('input[id=searchClear]').click(function(event) { // the click event to clear the form feilds and clear lists
        $("div[id=container-people-list]").css("display", "none");
        $("div[id=container-people-details]").css("display", "none");
        $("div[id=container-people-redemptions]").css("display", "none");
        $("div[id=container-people-resets]").css("display", "none");
        $('input[name=firstName]').val('');
        $('input[name=lastName]').val('');
        $('input[name=userName]').val('');
        $('input[name=userId]').val('');
        $('input[name=orderConfirmationNumber]').val('');
        $('input[name=cancelConfirmationNumber]').val('');
        console.log('[log] Cleared Find User fields');

        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");

        $('tbody[id=people-details-list-tbody]').empty();
        console.log("[log] Cleared Detail Table");

        $('tbody[id=people-list-tbody]').empty();
        $('span[id=foundx]').text('X number of Users');
        userPage = 1;
        maxUserPage = 1;
        $('span[id=foundPage]').text('Page ' + userPage + ' of ' + maxUserPage);
        console.log("[log] Cleared User Table");

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        $('tbody[id=people-resets-list-tbody]').empty();
        $('span[id=resetUser]').text('Resets');
        resetPage = 1;
        maxResetPage = 1;
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Resets Table");
    });

    $('input[id=redempFirst]').click(function(event) { // the click event for the back to first page button of the
                                                        // redemption list
        $('tbody[id=people-redemptions-list-tbody]').empty();
        redempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");
        findPrintByPersonAjax(redempPage);
    });

    $('input[id=redempPrev]').click(function(event) { // the click event for the back to previous page button of the
                                                        // redemption list
        $('tbody[id=people-redemptions-list-tbody]').empty();
        redempPage = (parseInt(redempPage) - 1);
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");
        findPrintByPersonAjax(redempPage);
    });

    $('input[id=redempNext]').click(function(event) { // the click event for the go to the first page button of the
                                                        // redemption list
        $('tbody[id=people-redemptions-list-tbody]').empty();
        redempPage = (parseInt(redempPage) + 1);
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");
        findPrintByPersonAjax(redempPage);
    });

    $('input[id=redempLast]').click(function(event) { // the click event for the go to the last page button of the
                                                        // redemption list
        $('tbody[id=people-redemptions-list-tbody]').empty();
        redempPage = maxRedempPage;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");
        findPrintByPersonAjax(redempPage);
    });

    $('input[id=redempGo]').click(function(event) { // the click event for the goto # page button of the redemption list
        $('tbody[id=people-redemptions-list-tbody]').empty();
        redempPage = parseInt($('input[id=redempGoto]').val());
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");
        findPrintByPersonAjax(redempPage);
    });

    $('input[id=redemptionsBackList]').click(function(event) { // the click event to clear the list of redemptions
        $("div[id=container-people-list]").css("display", "none");
        $("div[id=container-people-details]").css("display", "block");
        $("div[id=container-people-redemptions]").css("display", "none");
        $("div[id=container-people-resets]").css("display", "none");
        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");
    });

    $('input[id=resetFirst]').click(function(event) { // the click event for the back to first page button of the
                                                        // redemption list
        $('tbody[id=people-resets-list-tbody]').empty();
        resetPage = 1;
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Reset Table");
        findResetByPersonAjax(redempPage);
    });

    $('input[id=resetPrev]').click(function(event) { // the click event for the back to previous page button of the
                                                        // redemption list
        $('tbody[id=people-resets-list-tbody]').empty();
        resetPage = (parseInt(resetPage) - 1);
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Reset Table");
        findResetByPersonAjax(redempPage);
    });

    $('input[id=resetNext]').click(function(event) { // the click event for the go to the first page button of the
                                                        // redemption list
        $('tbody[id=people-resets-list-tbody]').empty();
        resetPage = (parseInt(resetPage) + 1);
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Reset Table");
        findResetByPersonAjax(redempPage);
    });

    $('input[id=resetLast]').click(function(event) { // the click event for the go to the last page button of the
                                                        // redemption list
        $('tbody[id=people-resets-list-tbody]').empty();
        resetPage = maxResetPage;
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Reset Table");
        findResetByPersonAjax(redempPage);
    });

    $('input[id=resetGo]').click(function(event) { // the click event for the goto # page button of the redemption list
        $('tbody[id=people-resets-list-tbody]').empty();
        resetPage = parseInt($('input[id=resetGoto]').val());
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Reset Table");
        findResetByPersonAjax(redempPage);
    });

    $('input[id=resetsBackList]').click(function(event) { // the click event to clear the list of redemptions
        $("div[id=container-people-list]").css("display", "none");
        $("div[id=container-people-details]").css("display", "block");
        $("div[id=container-people-redemptions]").css("display", "none");
        $("div[id=container-people-resets]").css("display", "none");
        $('tbody[id=people-resets-list-tbody]').empty();
        $('span[id=resetUser]').text('Resets');
        resetPage = 1;
        maxResetPage = 1;
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Resets Table");
    });

    $('input[id=userBackList]').click(function(event) { // the click event to clear the list of redemptions
        $("div[id=container-people-list]").css("display", "block");
        $("div[id=container-people-details]").css("display", "none");
        $("div[id=container-people-redemptions]").css("display", "none");
        $("div[id=container-people-resets]").css("display", "none");

        $('tbody[id=people-details-list-tbody]').empty();
        console.log("[log] Cleared Detail Table");

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        $('tbody[id=people-resets-list-tbody]').empty();
        $('span[id=resetUser]').text('Resets');
        resetPage = 1;
        maxResetPage = 1;
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Resets Table");
    });

    $('input[id=peopleBackList]').click(function(event) { // the click event to clear the list of redemptions
        $("div[id=container-people-list]").css("display", "none");
        $("div[id=container-people-details]").css("display", "none");
        $("div[id=container-people-redemptions]").css("display", "none");
        $("div[id=container-people-resets]").css("display", "none");

        $('tbody[id=people-list-tbody]').empty();
        console.log("[log] Cleared User Table");

        $('tbody[id=people-details-list-tbody]').empty();
        console.log("[log] Cleared Detail Table");

        $('tbody[id=people-redemptions-list-tbody]').empty();
        $('span[id=redempUser]').text('Redemptions');
        redempPage = 1;
        maxRedempPage = 1;
        $('span[id=redempListPage]').text('Page ' + redempPage + ' of ' + maxRedempPage);
        console.log("[log] Cleared Redemption Table");

        $('tbody[id=people-resets-list-tbody]').empty();
        $('span[id=resetUser]').text('Resets');
        resetPage = 1;
        maxResetPage = 1;
        $('span[id=resetListPage]').text('Page ' + resetPage + ' of ' + maxResetPage);
        console.log("[log] Cleared Resets Table");
    });
});

/*
 * File: menu.js
 * Purpose: Provide Auto User Authentication for EPI Admin tool 
 * Created By: Daniel Buckley 
 * And: Christian Vespa email: christian.vespa@silkrouteglobal.com
 */
var waitTime = 840000; // 14 minutes

var autoLogin = function(event) { // function to call to authenticate a users session on the back-end

    var username = $.cookie('username'); // pulls username from the cookies
    var password = $.cookie('password'); // pulls password from the cookies

    var url = "/epiadmintool/login.cmd";
    var formData = {
        username : username,
        password : password
    };

    $.ajax({ // this is the actual ajax request call
        url : url, // the url where we want to POST
        type : "POST", // define the type of HTTP verb we want to use (POST for our form)
        dataType : "json", // what type of data do we expect back from the server
        data : formData, // our user data sent as a data object
        error : function() { // this is ran if ajax returns is a fail, front-end failure
            console.log("Failed AutoLogin - Parse Data");
            return;
        },
        success : function(json) { // this is ran if the ajax returns a success, front-end success
            if (json.responseStatus == "success") { // to check to see if our back-end failed but still sent an response
                console.log("Pass - AutoLogin - Parse Data");
                $("span[id=user]").text("" + username);
                if(json.permissionMap.CE_Mapping == "true"){
                    gotoContent();
                }
                if(json.permissionMap.RED_Reset == "true"){
                    gotoRedemption();
                }
                if(json.permissionMap.Offerldx_Generation == "true"){
                    gotoOfferIndex();
                }
                //if(json.permissionMap.RED_Reset == "true"){
                if (true){
                    gotoCCProfile();
                }
                
                if (true){
                    gotoGroupOrder();
                }
                setTimeout(autoLogin, waitTime); // set it to run again after fourteen minutes
                return;
            } else {
                console.log("Fail - AutoLogin - Parse Data");
                return;
            }
        }
    });
};

var gotoContent = function(){
    $("input[id=gotoContent]").prop('disabled', false); // enables the use of button
};

var gotoRedemption = function(){
    $("input[id=gotoRedemption]").prop('disabled', false); // enables the use of button
};

var gotoOfferIndex = function(){
    $("input[id=gotoOfferIndex]").prop('disabled', false); // enables the use of button
};

var gotoCCProfile = function(){
    $("input[id=gotoCCProfile]").prop('disabled', false); // enables the use of button
};

var gotoGroupOrder = function(){
    $("input[id=gotoGroupOrder]").prop('disabled', false); // enables the use of button
};

window.onload = function() { // Make sure the function fires as soon as the page is loaded
    autoLogin();
    setTimeout(autoLogin, waitTime); // Then set it to run again after ten minutes
};

$(document).ready(function() {
    $('input[id=logout]').click(function(event) { // on click function for logout
        var url = "/epiadmintool/logout.cmd";

        $.ajax({
            url : url,
            type : "POST",
            dataType : "json",
            error : function() {
                console.log("Failed Logout - Parse Data");
                alert("Failed Logout could not connect to database.");
                return;
            },
            success : function(json) {
                if (json.responseStatus == "success") {
                    console.log("Pass - Logout - Parse Data");
                    $.removeCookie('username', {
                        path : '/'
                    }); // remove username from cookie list
                    $.removeCookie('password', {
                        path : '/'
                    }); // remove password from cookie list
                    window.location.href = '/epiadmintool/';
                    return;
                } else {
                    console.log("Fail - Logout - Parse Data");
                    alert(json.responseMessage);
                    return;
                }
            }
        });
    });
});
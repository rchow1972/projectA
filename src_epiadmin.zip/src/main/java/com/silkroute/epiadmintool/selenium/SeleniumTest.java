package com.silkroute.epiadmintool.selenium;

import java.util.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;



public class SeleniumTest
{

    
    public String testSearchByProduct(){
        //test commit
        StringBuilder sb = new StringBuilder();
      //WebDriver driver = new HtmlUnitDriver();
        WebDriver driver = new FirefoxDriver();

        // And now use this to visit Google
        driver.get("http://localhost:8080/epiadmintool/contentextract/index.jsp");

        // Find the text input element by its name
        WebElement element = driver.findElement(By.id("productName"));
        element.sendKeys("2014");
        element = driver.findElement(By.id("searchProductName"));
        element.click();


        // fetch rows
        WebElement table = driver.findElement(By.id("product-list-table"));

        // Now get all the TR elements from the table
        List<WebElement> allRows = table.findElements(By.tagName("tr"));
        sb.append("allRows size: " + allRows.size() + "<br/>");

        // And iterate over them, getting the cells
        for (WebElement row : allRows)
        {
           List<WebElement> cells = row.findElements(By.tagName("td"));
           for (WebElement cell : cells)
           {
               // And so on
               sb.append("found a cell " + cell.getText() + "<br/>");
           }
        }
        


      //element = driver.findElement(By.id("search_productId-inputEl"));
      //element.sendKeys("PR000000001K");
      //element = driver.findElement(By.id("button-1011-btnIconEl"));
      //element.click();





      // Now submit the form. WebDriver will find the form for us from the element
      // element.submit();

      System.out.println("asdfasdf2");
      // Check the title of the page
      System.out.println("Page title isit: " + driver.getCurrentUrl());
      System.out.println("Page title is: " + driver.getTitle());
      System.out.println("asdfasdf3");
      // driver.quit();
      System.out.println("asdfasdf4");
        
        return sb.toString();
    }
    
    
    
}

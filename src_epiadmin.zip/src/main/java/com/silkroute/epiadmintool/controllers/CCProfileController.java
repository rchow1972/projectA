package com.silkroute.epiadmintool.controllers;

import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.silkroute.epiadmintool.creditcardprofile.model.CustomerProfileModel;
import com.silkroute.epi.boss.dao.CustomerBillProfileDao;
import com.silkroute.epi.boss.entity.CustomerBillProfile;
import com.silkroute.epiadmintool.model.EPIAdminToolResponse;
import com.silkroute.epiadmintool.util.CybersourceCreditCardUtil;

@Controller
public class CCProfileController extends BaseController {

    Logger LOGGER = Logger.getLogger(CCProfileController.class);

    // Autowire DAOs
    @Autowired
    CustomerBillProfileDao ccBillProfileDao;

    @Autowired
    private Properties cybersourceProperties;
    
    // Fields
    SimpleDateFormat sdf = new SimpleDateFormat("MMMMMMMMM dd, yyyy");

    // Mappings
    @RequestMapping(value = "creditcardprofile/customerProfileById.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse getCustomerProfileById(HttpServletRequest request, HttpServletResponse response) {
        EPIAdminToolResponse epiResponse = new EPIAdminToolResponse();

        // Get Parameter - User Id
        try {
            long userId = -1;
            try {
                userId = Long.parseLong(request.getParameter("customerId"));
            } catch (NumberFormatException nfe) {
                throw new Exception("Could not retrieve user, id not provided.");
            }

            // get user information by id
            CustomerBillProfile profile = ccBillProfileDao.findBillProfileByCustomerId(userId);
            
            CustomerProfileModel profileModel = new CustomerProfileModel();
            profileModel.setFirstName(profile.getFirstName());
            profileModel.setLastName(profile.getLastName());
            profileModel.setAddress1(profile.getAddress1());
            if (profile.getAddress2() != null && !"".equals(profile.getAddress2())){
            	profileModel.setAddress2(profile.getAddress2());	
            }
            profileModel.setCity(profile.getCity());
            profileModel.setState(profile.getState());
            profileModel.setZipcode(profile.getZipcode());

            String countryVal = "US";
            boolean allNumericZip = StringUtils.isNumeric(profile.getZipcode().replaceAll(" ", "").replaceAll("-", ""));
            if (!allNumericZip) {
            	countryVal = "CA";
            }
            profileModel.setCountry(countryVal);
            
            CybersourceCreditCardUtil.initialized(cybersourceProperties);
            
            // Create Param List for Signed Values, Return Signature
            HashMap<String, String> params = new HashMap<String,String>();

            params.put(CybersourceCreditCardUtil.CYBERSOURCE_ACCESS_KEY_KEY, CybersourceCreditCardUtil.CYBERSOURCE_ACCESS_KEY_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_PROFILE_ID_KEY, CybersourceCreditCardUtil.CYBERSOURCE_PROFILE_ID_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_TRANSACTION_UUID_KEY, CybersourceCreditCardUtil.getRandomUUID().toString());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_SIGNED_FIELD_NAMES_KEY, CybersourceCreditCardUtil.CYBERSOURCE_SIGNED_FIELD_NAMES_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_UNSINGED_FIELD_NAMES_KEY, CybersourceCreditCardUtil.CYBERSOURCE_UNSINGED_FIELD_NAMES_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_SIGNED_DATE_TIME_KEY, CybersourceCreditCardUtil.getUTCDateTime());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_LOCALE_KEY, CybersourceCreditCardUtil.CYBERSOURCE_LOCALE_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_TRANSACTION_TYPE_KEY, CybersourceCreditCardUtil.CYBERSOURCE_TRANSACTION_TYPE_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_REFERENCE_NUMBER_KEY, String.valueOf(System.currentTimeMillis()));
//            params.put(CybersourceCreditCardUtil.CYBERSOURCE_AMOUNT_KEY, CybersourceCreditCardUtil.CYBERSOURCE_AMOUNT_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_CURRENCY_KEY, CybersourceCreditCardUtil.CYBERSOURCE_CURRENCY_VALUE);
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_PAYMENT_METHOD_KEY, CybersourceCreditCardUtil.CYBERSOURCE_PAYMENT_METHOD_VALUE);

            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_FORENAME_KEY, profile.getFirstName());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_SURNAME_KEY, profile.getLastName());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_ADDRESS_LINE1_KEY, profile.getAddress1());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_ADDRESS_CITY_KEY, profile.getCity());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_ADDRESS_STATE_KEY, profile.getState());
//            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_ADDRESS_COUNTRY_KEY, "US");
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_ADDRESS_COUNTRY_KEY, countryVal);
            
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_ADDRESS_POSTAL_CODE_KEY, profile.getZipcode());
            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_EMAIL_KEY, "noreply@entertainment.com");
//            params.put(CybersourceCreditCardUtil.CYBERSOURCE_BILL_TO_PHONE_KEY, "1231231234");
            
            String signature = CybersourceCreditCardUtil.sign(params, CybersourceCreditCardUtil.CYBERSOURCE_SECRET_KEY_VALUE);
            profileModel.setSignature(signature);
            profileModel.setSignedParameters(params);
            profileModel.setAction(CybersourceCreditCardUtil.CYBERSOURCE_URL_VALUE);
            
            epiResponse.setData(profileModel);
            epiResponse.setResponseStatus("success");
            epiResponse.setResponseMessage("Customer Profile Found");
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");
        } catch (Exception ex) {
            epiResponse.setData(new CustomerProfileModel());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Customer Profile Not Found");
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(ex.getMessage(), ex);
        }
        return epiResponse;
    }
}

package com.silkroute.epiadmintool.controllers;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.endeca.navigation.ENEQuery;
import com.endeca.navigation.ENEQueryResults;
import com.endeca.navigation.ERec;
import com.endeca.navigation.ERecList;
import com.endeca.navigation.HttpENEConnection;
import com.endeca.navigation.PropertyMap;
import com.silkroute.epi.phase2.dao.ClipCartDao;
import com.silkroute.epi.phase2.dao.ClipCartResetDao;
import com.silkroute.epi.phase2.dao.PersonDao;
import com.silkroute.epi.phase2.dao.SiteDao;
import com.silkroute.epi.phase2.entity.ClipCart;
import com.silkroute.epi.phase2.entity.ClipCartReset;
import com.silkroute.epi.phase2.entity.Person;
import com.silkroute.epiadmintool.email.Email;
import com.silkroute.epi.endeca.service.EndecaQueryService;
import com.silkroute.epiadmintool.exception.FormException;
import com.silkroute.epiadmintool.model.EPIAdminToolResponse;
import com.silkroute.epiadmintool.redemptionreset.model.PersonModel;
import com.silkroute.epiadmintool.redemptionreset.model.RedemptionModel;

@Controller
public class SVGPrintResetController extends BaseController {

    Logger LOGGER = Logger.getLogger(SVGPrintResetController.class);

    // Autowire DAOs
    @Autowired
    PersonDao personDao;

    @Autowired
    ClipCartDao redemptionDao;

    @Autowired
    ClipCartResetDao resetDao;

    @Autowired
    SiteDao siteDao;

    @Autowired
    EndecaQueryService eneQueryService;

    // Fields
    SimpleDateFormat sdf = new SimpleDateFormat("MMMMMMMMM dd, yyyy");

    // Mappings
    /**
     * Triggers email send for provided user id.
     * 
     * Email reminder is sent by collection necessary information from Person entity. Search is done
     * on User Id for person, then used to create a reminder email.
     * 
     * @param request
     *            HttpServletRequest
     * @param response
     *            HttpServletResponse
     * @return EPIAdminToolResponse with messaging.
     */
    @RequestMapping(value = "redemptionreset/emailReminder.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse sendEmailReminder(HttpServletRequest request, HttpServletResponse response) {
        EPIAdminToolResponse epiResponse = new EPIAdminToolResponse();

        // Get Parameter - User Id
        try {

            long userId = -1;
            try {
                userId = Long.parseLong(request.getParameter("userId"));
            } catch (NumberFormatException nfe) {
                throw new Exception("Could not send email to user, id not provided.");
            }

            // get user information by id
            Person recipient = personDao.findPersonById(userId);

            String reminderTo = recipient.getEmail();
            if (null == reminderTo || reminderTo.length() <= 0) {
                throw new Exception("Could not send email to user, email address not provided.");
            }

            String message = "Password Reminder: " + recipient.getFirstName() + " "
                    + recipient.getLastName() + ",\n"
                    + "Your username/password reminder is included: " + recipient.getUserName()
                    + "/" + recipient.getPassword();

            String subject = recipient.getFirstName() + " " + recipient.getLastName()
                    + ", Your Password Reminder";

            sendEmail(reminderTo, subject, message);

            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("success");
            epiResponse.setResponseMessage("Send Email: Email triggered with subject '" + subject
                    + "'.");
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");
        } catch (Exception ex) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Send Email: " + ex.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(ex.getMessage(), ex);

        }
        return epiResponse;
    }

    // Send Email
    private void sendEmail(String reminderTo, String subject, String message) {
        Email email = new Email(reminderTo, subject, message);
        Thread t = new Thread(email);
        t.start();
    }

    /**
     * Return matching person list based on provided search parameters.
     * 
     * Determines best method for person search with the provided parameters. The search will use
     * the following order to find persons:<br>
     * User Id<br>
     * Email Address or User Name<br>
     * First Name and Last Name<br>
     * Even if additional search parameters are available, the search will use the 'best' parameters
     * to complete the search.
     * 
     * @param request
     *            HttpServletRequest
     * @param response
     *            HttpServletResponse
     * @return EPIAdminToolResponse with table data, messaging, and pagination.
     * @throws Exception
     */
    @RequestMapping(value = "redemptionreset/findPerson.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse findPersonSearch(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        EPIAdminToolResponse epiResponse = new EPIAdminToolResponse();

        List<PersonModel> personModelList = new ArrayList<PersonModel>();

        String fName = request.getParameter("firstName");
        String lName = request.getParameter("lastName");
        String userOrEmailName = request.getParameter("userName");
        String orderConf = request.getParameter("orderConfirmationNumber");
        String cancelConf = request.getParameter("cancelConfirmationNumber");

        boolean searchWithLike = false;
        try {
            searchWithLike = Boolean.parseBoolean(request.getParameter("likeSearch"));
        } catch (Exception ex) {
        }

        long userId = -1;
        try {
            userId = Long.parseLong(request.getParameter("userId"));
        } catch (NumberFormatException nfe) {
        }

        int currentPage = 1;
        try {
            currentPage = Integer.parseInt(request.getParameter("page"));
            currentPage = currentPage <= 0 ? 1 : currentPage;
        } catch (NumberFormatException nfe) {
        }

        try {
            // Validate input
            FormException formException = new FormException();
            if (formException.hasError()) {
                throw formException;
            }

            String errorMessage = "";

            boolean searchByName = false;
            if (null != fName && null != lName) {
                if (fName.trim().length() > 0 && lName.trim().length() > 0) {
                    searchByName = true;
                } else {
                    errorMessage = "First Name and Last Name not provided.";
                }
            }

            boolean searchById = false;
            if (userId != -1) {
                searchById = true;
            } else {
                errorMessage = "User Id not provided.";
            }

            boolean searchByUserName = false;
            if (null != userOrEmailName && userOrEmailName.trim().length() > 0) {
                searchByUserName = true;
            } else {
                errorMessage = "User Name not provided.";
            }

            if (!searchById && !searchByUserName && !searchByName) {
                if ((null != orderConf && orderConf.trim().length() > 0)
                        || (null != cancelConf && cancelConf.trim().length() > 0)) {
                    throw new Exception("Search By Confirmation Number not Implemented.");
                } else {
                    throw new Exception("Search Parameters Not Provided.");
                }
            }

            /**
             * Search Strategy - ID, Email, First/Last Name
             */
            int numberOfPages = 1;
            String searchBy = "";
            List<Person> personList = new ArrayList<Person>();
            if (searchById) {
                Person person = personDao.findPersonById(userId);
                personList.add(person);
                searchBy = "Exact User Id: " + userId;
                epiResponse.setNumberOfPages("1");
            } else if (searchByUserName) {
                // Refresh Data to send to page
                if (searchWithLike) {
                    numberOfPages = personDao
                            .resultCountLikeUserNameOrEmailAddress(userOrEmailName);
                    currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

                    personList = personDao.findPersonLikeUserNameOrEmailAddressPage(
                            userOrEmailName, currentPage);
                    searchBy = "Similar to Email or User Name: " + userOrEmailName;
                } else {
                    numberOfPages = personDao.resultCountByUserNameOrEmailAddress(userOrEmailName);
                    currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

                    personList = personDao.findPersonByUserNameOrEmailAddressPage(userOrEmailName,
                            currentPage);
                    searchBy = "Exact Email or User Name: " + userOrEmailName;
                }
                epiResponse.setNumberOfPages(String.valueOf(numberOfPages));
            } else if (searchByName) {
                // Refresh Data to send to page
                if (searchWithLike) {
                    numberOfPages = personDao.resultCountLikeName(fName, lName);
                    currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

                    personList = personDao.findPersonLikeNamePage(fName, lName, currentPage);
                    searchBy = "Similar to Name: " + fName + " " + lName;
                } else {
                    numberOfPages = personDao.resultCountByName(fName, lName);
                    currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

                    personList = personDao.findPersonByNamePage(fName, lName, currentPage);
                    searchBy = "Exact Name: " + fName + " " + lName;
                }
                epiResponse.setNumberOfPages(String.valueOf(numberOfPages));
            } else {
                throw new Exception("Could Not Initialize Search.");
            }

            LOGGER.debug("findPerson personList.size: " + personList.size());
            personModelList = getPersonModelList(personList);
            epiResponse.setData(personModelList);
            epiResponse.setResponseStatus("success");
            epiResponse.setResponseMessage("Found " + personModelList.size()
                    + " Person(s) using Search By (" + searchBy + ")");
            epiResponse.setPage(String.valueOf(currentPage));

        } catch (FormException fe) {
            LOGGER.error(fe.getMessage(), fe);
            throw fe;

        } catch (Exception ex) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Find Person: " + ex.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(ex.getMessage(), ex);
        }

        return epiResponse;
    }

    /**
     * Finds the coupon print and redemptions used by a person.
     * 
     * Uses the user id to find prints and redemptions by a person. Redempetion information can then be displayed in the front-end.
     * 
     * @param request HttpServletRequest
     * @param response HttpServletResponse
     * @return EPIAdminToolResponse with data for redemptions, messaging, and pagination.
     * @throws Exception
     */
    @RequestMapping(value = "redemptionreset/findPrintByPerson.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse findRedemptionByPerson(HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        EPIAdminToolResponse epiResponse = new EPIAdminToolResponse();

        List<RedemptionModel> redemptionModelList = new ArrayList<RedemptionModel>();

        long userId = -1;
        try {
            try {
                userId = Long.parseLong(request.getParameter("userId"));
            } catch (NumberFormatException nfe) {
                throw new Exception("User Id not provided.");
            }

            int currentPage = 1;
            try {
                currentPage = Integer.parseInt(request.getParameter("page"));
                currentPage = currentPage <= 0 ? 1 : currentPage;
            } catch (NumberFormatException nfe) {
            }

            // Validate input
            FormException formException = new FormException();
            if (formException.hasError()) {
                throw formException;
            }

            String errorMessage = "";

            // Refresh Data to send to page
            int numberOfPages = redemptionDao.resultCountClipCartByPerson(userId);
            currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

            List<ClipCart> redemptionList = redemptionDao.findClipCartsByPersonPage(userId,
                    currentPage);

            LOGGER.debug("findPrintByPerson redemptionList.size: " + redemptionList.size());
            redemptionModelList = getRedemptionModelList(redemptionList);
            epiResponse.setData(redemptionModelList);
            epiResponse.setResponseStatus("success");
            epiResponse.setResponseMessage("Found " + redemptionModelList.size()
                    + " Redemption for User Id (" + userId + ")");
            epiResponse.setPage(String.valueOf(currentPage));
            epiResponse.setNumberOfPages(String.valueOf(numberOfPages));
        } catch (FormException fe) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Find Print By Person: " + fe.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(fe.getMessage(), fe);
        } catch (Exception ex) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Find Print By Person: " + ex.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(ex.getMessage(), ex);
        }

        return epiResponse;
    }

    /**
     * Finds a list of resets already processed for a user.
     * 
     *  Uses the user id to find resets that have already been processed for a user.
     * 
     * @param request
     *            HttpServletRequest
     * @param response
     *            HttpServletResponse
     * @return EPIAdminToolResponse configured for a list of resets by person, messaging, and pagination.
     * @throws Exception
     */
    @RequestMapping(value = "redemptionreset/findResetByPerson.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse findResetByPerson(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        EPIAdminToolResponse epiResponse = new EPIAdminToolResponse();

        List<RedemptionModel> redemptionModelList = new ArrayList<RedemptionModel>();

        long userId = -1;
        try {
            try {
                userId = Long.parseLong(request.getParameter("userId"));
            } catch (NumberFormatException nfe) {
                throw new Exception("User Id not provided.");
            }

            int currentPage = 1;
            try {
                currentPage = Integer.parseInt(request.getParameter("page"));
                currentPage = currentPage <= 0 ? 1 : currentPage;
            } catch (NumberFormatException nfe) {
            }

            // Validate input
            FormException formException = new FormException();
            if (formException.hasError()) {
                throw formException;
            }

            String errorMessage = "";

            // Refresh Data to send to page
            int numberOfPages = resetDao.resultCountClipResetByPerson(userId);
            currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

            List<ClipCartReset> redemptionList = null;
            try {
                redemptionList = resetDao.findClipResetsByPersonPage(userId, currentPage);
            } catch (Exception ex) {
                ex.printStackTrace();
                throw new Exception("Could Not Retrieve Resets.");
            }

            LOGGER.debug("findResetByPerson resetList.size: " + redemptionList.size());
            try {
                redemptionModelList = getResetModelList(redemptionList);
            } catch (Exception ex) {
                ex.printStackTrace();
                throw new Exception("Could Not Generate Reset Model List - " + ex.getMessage());
            }

            epiResponse.setData(redemptionModelList);
            epiResponse.setResponseStatus("success");
            epiResponse.setResponseMessage("Found " + redemptionModelList.size()
                    + " Resets for User Id (" + userId + ")");
            epiResponse.setPage(String.valueOf(currentPage));
            epiResponse.setNumberOfPages(String.valueOf(numberOfPages));
        } catch (FormException fe) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Find Reset By Person: " + fe.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(fe.getMessage(), fe);
        } catch (Exception ex) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Find Reset By Person: " + ex.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(ex.getMessage(), ex);
        }

        return epiResponse;
    }

    /**
     * Resets a redemption for reuse.
     * 
     * Using a redemption id, makes necessary changes in PHASE2 tables to remove the redemption and
     * make it available for use.
     * 
     * @param request
     *            HttpServletRequest
     * @param response
     *            HttpServletResponse
     * @return EPIAdminToolResponse configured for reset redemption.
     * @throws Exception
     */
    @RequestMapping(value = "redemptionreset/resetPrint.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse resetRedemption(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        EPIAdminToolResponse epiResponse = new EPIAdminToolResponse();

        List<RedemptionModel> redemptionModelList = new ArrayList<RedemptionModel>();

        long redemptionId = -1;
        try {
            try {
                redemptionId = Long.parseLong(request.getParameter("redemptionId"));
            } catch (NumberFormatException nfe) {
                throw new Exception("Redemption Id not provided.");
            }

            int currentPage = 1;
            try {
                currentPage = Integer.parseInt(request.getParameter("page"));
                currentPage = currentPage <= 0 ? 1 : currentPage;
            } catch (NumberFormatException nfe) {
            }

            // Validate input
            FormException formException = new FormException();
            if (formException.hasError()) {
                throw formException;
            }

            String errorMessage = "";
            long userId = -1;
            // Find Redemption By Id - Error if not present
            ClipCart clipCart = redemptionDao.findClipCartById(redemptionId);
            if (clipCart == null) {
                throw new Exception("Redemption Entry Not Found.");
            }
            userId = clipCart.getPersonId();

            ClipCartReset clipCartReset = null;
            try {
                // Copy Redemption Information into Reset Object Object
                clipCartReset = generateClipCartReset(clipCart);
            } catch (Exception ex) {
                LOGGER.error(ex.getMessage(), ex);
                throw new Exception("Did not generate Clip Cart Reset via Clip Cart.");
            }

            try {
                // Copy Object into Reset History
                clipCartReset = resetDao.persist(clipCartReset);
            } catch (Exception ex) {
                LOGGER.error(ex.getMessage(), ex);
                throw new Exception("Did not persist Clip Cart Reset.");
            }

            if (clipCartReset == null) {
                throw new Exception("Reset Entry Not Found.");
            }
            try {
                // Delete Entry from Clip Cart
                Integer deletedCount = redemptionDao.deleteClipCart(clipCart);
            } catch (Exception ex) {
                LOGGER.error(ex.getMessage(), ex);
                throw new Exception("Did not delete Clip Cart.");
            }

            // Refresh Data to send to page
            int numberOfPages = redemptionDao.resultCountClipCartByPerson(userId);
            currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

            List<ClipCart> redemptionList = redemptionDao.findClipCartsByPersonPage(userId,
                    currentPage);

            LOGGER.debug("findPrintByPerson redemptionList.size: " + redemptionList.size());
            redemptionModelList = getRedemptionModelList(redemptionList);
            epiResponse.setData(redemptionModelList);
            epiResponse.setResponseStatus("success");
            epiResponse.setResponseMessage("Found " + redemptionModelList.size()
                    + " Redemption for User Id (" + userId + ") after Reset.");
            epiResponse.setPage(String.valueOf(currentPage));
            epiResponse.setNumberOfPages(String.valueOf(numberOfPages));
        } catch (FormException fe) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Reset Process: " + fe.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(fe.getMessage(), fe);
        } catch (Exception ex) {
            epiResponse.setData(new ArrayList<PersonModel>());
            epiResponse.setResponseStatus("fail");
            epiResponse.setResponseMessage("Reset Process: " + ex.getMessage());
            epiResponse.setPage("1");
            epiResponse.setNumberOfPages("1");

            LOGGER.error(ex.getMessage(), ex);
        }

        return epiResponse;
    }

    /**
     * Creates clip cart reset with information from provided clip cart.
     * 
     * Helper method that maps the fields from the clip cart entity into a clip cart reset entity
     * before moving it in the database.
     * 
     * @param clipCart
     *            ClipCart database entity.
     * @return ClipCartReset database entity.
     */
    private ClipCartReset generateClipCartReset(ClipCart clipCart) {
        ClipCartReset clipCartReset = new ClipCartReset();
        clipCartReset.setId(clipCart.getId());
        clipCartReset.setClipDate(clipCart.getClipDate());
        clipCartReset.setCouponType(clipCart.getCouponType());
        clipCartReset.setEdition(clipCart.getEdition());
        clipCartReset.setExpireDate(clipCart.getExpireDate());
        clipCartReset.setLocationId(clipCart.getLocationId());
        clipCartReset.setMembershipInstanceId(clipCart.getMembershipInstanceId());
        clipCartReset.setOfferId(clipCart.getOfferId());
        clipCartReset.setPersonId(clipCart.getPersonId());
        clipCartReset.setPersonProductId(clipCart.getPersonProductId());
        clipCartReset.setPrintDate(clipCart.getPrintDate());
        clipCartReset.setResetDate(new Date());
        clipCartReset.setRedemption(clipCart.getRedemption());

        return clipCartReset;
    }

    /**
     * Creates a person model list for display on the front-end.
     * 
     * Populate a list in the person model format based on the person database entity.
     * 
     * @param personList
     *            a list of Person database entities.
     * @return List of Person Model provided to front-end for display.
     */
    private List<PersonModel> getPersonModelList(List<Person> personList) {
        List<PersonModel> personModelList = new ArrayList<PersonModel>();

        for (Person person : personList) {
            PersonModel personModel = new PersonModel();
            personModel.setEmail(person.getEmail());
            personModel.setUserName(person.getUserName());
            personModel.setUserId(String.valueOf(person.getPersonKey()));
            personModel.setFirstName(person.getFirstName());
            personModel.setLastName(person.getLastName());
            personModel.setSiteId(String.valueOf(person.getSiteId()));
            try {
                personModel.setSiteName(siteDao.findSiteNameBySiteId(person.getSiteId()));
            } catch (Exception ex) {
                personModel.setSiteName("Not Available");
            }
            personModel.setPassword(person.getPassword());
            try {
                personModel.setAddDate(sdf.format(person.getAddDate()));
            } catch (Exception ex) {
                personModel.setAddDate("Not Available");
            }
            personModelList.add(personModel);
        }
        return personModelList;
    }

    /**
     * Creates a redemption model list of redemptions for display on the front-end.
     * 
     * Populate a list in the redemption model format based on the clip cart database entity.
     * 
     * @param redemptionList
     * @return
     * @throws Exception
     */
    private List<RedemptionModel> getRedemptionModelList(List<ClipCart> redemptionList)
            throws Exception {
        List<RedemptionModel> redemptionModelList = new ArrayList<RedemptionModel>();
        for (ClipCart redemption : redemptionList) {
            RedemptionModel redemptionModel = new RedemptionModel();

            try {
                redemptionModel.setRedemptionId(String.valueOf(redemption.getId()));
                redemptionModel.setOfferId(redemption.getOfferId());
                redemptionModel.setRedemptionLocationId(redemption.getLocationId());
                redemptionModel.setRedeemMethod(redemption.getRedemption());
                try {
                    redemptionModel.setRedeemDate(sdf.format(redemption.getPrintDate()));
                } catch (Exception ex) {
                    redemptionModel.setRedeemDate("Not Available");
                }
            } catch (Exception ex) {
                throw new Exception("Model Setup: " + ex.getMessage());
            }

            try {
                redemptionModel = setOfferDetails(redemptionModel);
            } catch (Exception ex) {
                // throw new Exception("Error: " + ex.getMessage());
                LOGGER.error(ex.getMessage(), ex);
                redemptionModel.setMerchant(ex.getMessage());
                redemptionModel.setOfferDetail(redemptionModel.getOfferId());
                redemptionModel.setAddress("");
            }

            redemptionModelList.add(redemptionModel);
        }
        return redemptionModelList;
    }

    /**
     * Creates a redemption model list of resets for display on the front-end.
     * 
     * Populate a list in the redemption model format based on the clip cart reset database entity.
     * 
     * @param redemptionList
     * @return
     * @throws Exception
     */
    private List<RedemptionModel> getResetModelList(List<ClipCartReset> redemptionList)
            throws Exception {
        List<RedemptionModel> redemptionModelList = new ArrayList<RedemptionModel>();

        for (ClipCartReset reset : redemptionList) {
            RedemptionModel redemptionModel = new RedemptionModel();
            try {
                redemptionModel.setRedemptionId(String.valueOf(reset.getId()));
                redemptionModel.setOfferId(reset.getOfferId());
                redemptionModel.setRedemptionLocationId(reset.getLocationId());
                redemptionModel.setRedeemMethod(reset.getRedemption());
                try {
                    redemptionModel.setRedeemDate(sdf.format(reset.getPrintDate()));
                } catch (Exception ex) {
                    redemptionModel.setRedeemDate("Not Available");
                }
                try {
                    redemptionModel.setResetDate(sdf.format(reset.getResetDate()));
                } catch (Exception ex) {
                    redemptionModel.setResetDate("Not Available");
                }
            } catch (Exception ex) {
                throw new Exception("Model Setup: " + ex.getMessage());
            }
            try {
                redemptionModel = setOfferDetails(redemptionModel);
            } catch (Exception ex) {
                // throw new Exception("Error: " + ex.getMessage());
                LOGGER.error(ex.getMessage(), ex);
                redemptionModel.setMerchant(ex.getMessage());
                redemptionModel.setOfferDetail(redemptionModel.getOfferId());
                redemptionModel.setAddress("");
            }

            redemptionModelList.add(redemptionModel);
        }
        return redemptionModelList;
    }

    /**
     * Retrieve Endeca Offer details based on redemption model.
     * 
     * @param redemptionModel
     *            The Redemption Model object with offer, location and redeem method information.
     * @return RedemptionModel with additional offer information from Endeca.
     * @throws Exception
     */
    private RedemptionModel setOfferDetails(RedemptionModel redemptionModel) throws Exception {
        PropertyMap pMap = null;
        String endecaKey = "";
        try {
            endecaKey = eneQueryService.generateEndecaKeyByFields(redemptionModel.getOfferId(),
                    redemptionModel.getRedemptionLocationId(), redemptionModel.getRedeemMethod());
        } catch (Exception ex) {
            throw new Exception("Could not create Endeca Key for: " + redemptionModel.getOfferId()
                    + " " + redemptionModel.getRedemptionLocationId() + " "
                    + redemptionModel.getRedeemMethod());
        }

        ENEQuery query = null;
        try {
            query = eneQueryService.createSimpleQuery(endecaKey);
            if (query == null)
                throw new Exception();
        } catch (Exception ex) {
            throw new Exception("Could not create query for Endeca Key: " + endecaKey);
        }

        HttpENEConnection con = null;
        try {
            con = eneQueryService.getConnection();
            if (con == null)
                throw new Exception();
        } catch (Exception ex) {
            throw new Exception("Could not get Endeca connection.");
        }

        ENEQueryResults results = null;
        try {
            results = eneQueryService.executeQuery(query);
        } catch (Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
            throw new Exception("Could not run query for Endeca connection: " + con.getHostname()
                    + " " + con.getPort());
        }

        if (results != null) {
            if (results.containsERecs()) {
                // take first one
                ERecList resultList = results.getERecs();
                ERec result = (ERec) resultList.get(0);
                pMap = result.getProperties();
            } else if (results.containsERec()) {
                // only one, take that
                ERec result = results.getERec();
                pMap = result.getProperties();
            }
        } else {
            redemptionModel.setMerchant("Offer Not Found or Not Available");
            redemptionModel.setOfferDetail(redemptionModel.getOfferId());
            redemptionModel.setAddress("");
        }

        // Takes the Properties Map and returns specific fields.
        if (pMap != null) {
            redemptionModel.setMerchant((String) pMap.get(EndecaQueryService.PMAP_KEY_MERCHANT));
            redemptionModel.setOfferDetail((String) pMap
                    .get(EndecaQueryService.PMAP_KEY_SHORTOFFERTEXT));
            String address = ((String) pMap.get(EndecaQueryService.PMAP_KEY_ADDRESS)) + "</br>"
                    + ((String) pMap.get(EndecaQueryService.PMAP_KEY_CITY)) + ", "
                    + ((String) pMap.get(EndecaQueryService.PMAP_KEY_STATE)) + " "
                    + ((String) pMap.get(EndecaQueryService.PMAP_KEY_ZIPCODE));

            redemptionModel.setAddress(address);
        } else {
            redemptionModel.setMerchant("Offer Not Found or Not Available");
            redemptionModel.setOfferDetail(redemptionModel.getOfferId());
            redemptionModel.setAddress("");
        }

        return redemptionModel;
    }
}

package com.silkroute.epiadmintool.controllers;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.silkroute.epi.contentextract.dao.ContentExtractProductDao;
import com.silkroute.epi.contentextract.dao.ProductIdXEditionDao;
import com.silkroute.epi.contentextract.entity.ContentExtractProduct;
import com.silkroute.epi.contentextract.entity.ProductIdXEdition;
import com.silkroute.epi.contentextract.entity.ProductIdXEditionPK;
import com.silkroute.epi.ocpcontrol.dao.OmsOrderSessionDao;
import com.silkroute.epi.ocpcontrol.entity.OmsOrderSession;
import com.silkroute.epiadmintool.contentextract.model.ProductMapModel;
import com.silkroute.epiadmintool.exception.FormException;
import com.silkroute.epiadmintool.grouporder.model.GroupOrderModel;
import com.silkroute.epiadmintool.model.EPIAdminToolResponse;

@Controller
public class GroupOrderController extends BaseController
{

    Logger LOGGER = Logger.getLogger(GroupOrderController.class);
    
	public static String SEARCH_TYPE_GROUPORDERID = "groupOrderId";

	private static String REPORT_DATE_FORMAT = "MM/dd/yy hh:mm aa";
	private static String SQL_DATE_FORMAT = "dd-MMM-yy";
	
	@Autowired
	OmsOrderSessionDao omsOrderSession;
	
    @RequestMapping(value = "grouporder/resultsByPage.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse searchResultsByPage(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
    	List<GroupOrderModel> groupOrderModelList = new ArrayList<GroupOrderModel>(); 
    	
    	String searchType = request.getParameter("searchType");
    	String searchParam = request.getParameter("searchParam");;
        int currentPage = 1;
        try {
        	int requestPage = Integer.parseInt(request.getParameter("page"));
        	currentPage = requestPage;
        } catch (NumberFormatException nfe) {}    	
    	
        int numberOfPages = 1;
        
        String message = "Not Yet Implemented";

        ceResponse.setData(groupOrderModelList);
		ceResponse.setResponseStatus("fail");
		ceResponse.setResponseMessage(message);
		ceResponse.setPage(String.valueOf(currentPage));
		ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	       
		return ceResponse;
    }
    
    
    @RequestMapping(value = "grouporder/searchByGroupOrderId.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse searchByGroupOrderId(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
    	List<GroupOrderModel> groupOrderModelList = new ArrayList<GroupOrderModel>(); 
    	
    	String fundraisingGroupId = request.getParameter("groupOrderId");
    	
        int currentPage = 1;
        try {
        	int requestPage = Integer.parseInt(request.getParameter("page"));
        	currentPage = requestPage;
        } catch (NumberFormatException nfe) {}    	
    	
        int numberOfPages = 1;

        SimpleDateFormat sdf = new SimpleDateFormat(SQL_DATE_FORMAT);
        String today = sdf.format(new Date());
        
        List<Object[]> result = omsOrderSession.getOrdersByGroupIdAndStartDate(fundraisingGroupId, today);
        
        
        String message = "Not Yet Implemented";
        if ( result.size() > 0 ) {
            // Process Result Into Model
            groupOrderModelList = populateGroupOrderModelList(result);

            message = result.size() + " Orders Returned for Fundraising Group Id (" + fundraisingGroupId + ")";
            ceResponse.setData(groupOrderModelList);
    		ceResponse.setResponseStatus("success");
        }  else {
        	message = "No Orders Returned for Fundraising Group Id (" + fundraisingGroupId + ")";
            ceResponse.setData(null);
    		ceResponse.setResponseStatus("fail");
        }
		ceResponse.setResponseMessage(message);
		ceResponse.setPage(String.valueOf(currentPage));
		ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	       
		return ceResponse;
    }


	private List<GroupOrderModel> populateGroupOrderModelList(List<Object[]> result) {
		ArrayList<GroupOrderModel> returnList = new ArrayList<GroupOrderModel>();
		SimpleDateFormat sdf = new SimpleDateFormat(REPORT_DATE_FORMAT);
		for( Object[] os: result) {
			
			GroupOrderModel gom = new GroupOrderModel();
//			gom.setGroupId(os.getGroupId());
//			gom.setOrderAmount(formatGrandTotalAmount(os.getGrandTotal()));
//			gom.setOrderDate(sdf.format(os.getCreatedDate()));
//			gom.setOrderNumber(String.valueOf(os.getOmsOrderSessionId()));
//			gom.setOrderQuantity(String.valueOf(os.getItemTotal()));
//			gom.setOrderSource(os.getAffiliateId());
//			gom.setOrderStatus(getStatusCodeById(os.getOmsOrderSessionStatusId()));
//			gom.setPurchaserName(os.getFirstName() + " " + os.getLastName());
//			gom.setSellerId(os.getSellerId());

			gom.setGroupId((String) os[0]);
			gom.setSellerId((String)os[1]);
			gom.setOrderNumber(String.valueOf((BigDecimal) os[2]));
			gom.setOrderSource((String) os[3]);
			gom.setOrderDate(sdf.format((Date) os[4]));
			gom.setOrderStatus(getStatusCodeById(((BigDecimal) os[5]).longValue()));
			gom.setPurchaserName((String)os[6] + " " + (String)os[7]);
			gom.setOrderQuantity(String.valueOf((BigDecimal) os[8]));
			gom.setOrderAmount(formatGrandTotalAmount(((BigDecimal) os[9]).longValue()));
			
			returnList.add(gom);
		}
		return returnList;
	}


	private String formatGrandTotalAmount(Long grandTotal) {
		String returnAmount = String.valueOf(grandTotal);
		returnAmount = "$" + returnAmount.substring(0, returnAmount.length() - 2) + "." + returnAmount.substring(returnAmount.length() - 2);
				
		return returnAmount;
	}


	private String getStatusCodeById(Long omsOrderSessionStatusId) {
		String[] statusCodes = new String[]{"NEW","COMPLETE","SHIPPED","PARTIAL SHIP","CANCELLED","PENDING","PROCESSING","RETURNED"};
	    return statusCodes[omsOrderSessionStatusId.intValue() - 1];
	}
	
}

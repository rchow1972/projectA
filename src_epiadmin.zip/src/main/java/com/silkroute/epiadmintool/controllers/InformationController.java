package com.silkroute.epiadmintool.controllers;

import java.io.StringWriter;
import java.sql.Connection;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceContextType;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;
import net.sf.ehcache.Cache;
import net.sf.ehcache.Ehcache;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.silkroute.epi.contentextract.dao.ContentExtractProductDao;

@Controller
@RequestMapping(value = "/info")
public class InformationController extends BaseController
{

    Logger LOGGER = Logger.getLogger(InformationController.class);

    @Autowired(required = true)
    private net.sf.ehcache.Cache cache;

    @Autowired(required = true)
    private net.sf.ehcache.CacheManager cacheManager;

    @Autowired
    ContentExtractProductDao contentExtractProductDao;

    @Autowired
    @Qualifier("contentExtractDataSource")
    DataSource contentExtractDataSource;

    @PersistenceContext(type = PersistenceContextType.EXTENDED, unitName = "contentExtractionEmf")
    public EntityManager em_contentExtract;

    @PersistenceContext(type = PersistenceContextType.EXTENDED, unitName = "phase2Emf")
    public EntityManager em_phase2;
    
    private static int COUNT = 0;

    // Mappings
    @RequestMapping(value = "/log4j.cmd", method = RequestMethod.GET, headers = "Accept=text/html, application/json", produces = "application/json")
    public @ResponseBody
    String log4j(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        System.out.println("start log4jtest ******************************************************");

        StringBuilder sw = new StringBuilder();
        sw.append("Hello, Im the log4j Test and ");
        sw.append("LogLevel: " + LOGGER.getEffectiveLevel() + "Includes: ");

        if (LOGGER.isTraceEnabled())
        {
            sw.append("TraceEnabled, ");
        }
        if (LOGGER.isDebugEnabled())
        {
            sw.append("DebugEnabled, ");
        }
        if (LOGGER.isInfoEnabled())
        {
            sw.append("InfoEnabled");
        }

        LOGGER.trace("TRACE");
        LOGGER.debug("DEBUG");
        LOGGER.info("INFO");
        LOGGER.warn("WARN");
        LOGGER.error("ERROR");
        LOGGER.fatal("FATAL");

        System.out.println("end log4jtest ********************************************************");

        return sw.toString();
    }

    @RequestMapping(value = "/cacheStats.cmd", method = RequestMethod.GET, headers = "Accept=text/html, application/json", produces = "application/json")
    public @ResponseBody
    String cacheStats(HttpServletRequest request, HttpServletResponse response) throws Exception {
        System.out.println("start log4jtest ******************************************************");
        StringBuilder sw = new StringBuilder();
        sw.append("Hello, Im the Cache Test and ");
        if (this.cache == null) {
        	sw.append("cache is null, ");
            System.out.println("cache is null sss 22");
        } else {
        	sw.append("cache is NOT null, ");
            System.out.println("cache is NOT null 22222");
            
            sw.append("storeageSize: " + cache.getDiskStoreSize() + ", ");
            System.out.println("storeageSize: " + cache.getDiskStoreSize());
            
            sw.append("getName: " + cache.getName() + ", ");
            System.out.println("getName: " + cache.getName());
            
            sw.append("mem size: " + cache.getMemoryStoreSize() + ", ");
            System.out.println("mem size: " + cache.getMemoryStoreSize());
        }

        if (this.cacheManager == null) {
        	sw.append("cacheManager is null.");
            System.out.println("cacheManager is null sss 22");
        } else {
        	sw.append("cacheManager is NOT null.");
            System.out.println("cacheManager is NOT null 22222");
            for (String name : cacheManager.getCacheNames()) {
                System.out.println("name: " + name);
                Cache cache = cacheManager.getCache(name);
                System.out.println("chache: " + cache);
                System.out.println(cache.calculateInMemorySize());
                System.out.println(cache.getAverageGetTime());
                System.out.println(cache.getDiskStoreSize());
                System.out.println(cache.getMemoryStoreSize());
                System.out.println(cache.getSize());

                if (COUNT > 3) {
                    cache.flush();
                    COUNT = 0;
                }
                COUNT++;

                // To clear
                Ehcache ecache = cacheManager.getEhcache(name);
                System.out.println("echache: " + ecache);
                System.out.println(ecache.calculateInMemorySize());
                System.out.println(ecache.getAverageGetTime());
                System.out.println(ecache.getDiskStoreSize());
                System.out.println(ecache.getMemoryStoreSize());
                System.out.println(ecache.getSize());

            }
        }

        contentExtractProductDao.findByProductName("2014");

        System.out.println("end log4jtest ********************************************************");

        return sw.toString();
    }

    @RequestMapping(value = "/testDb.cmd", method = RequestMethod.GET, headers = "Accept=text/html, application/json", produces = "application/json")
    public @ResponseBody
    String testDb(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        System.out.println("start testdb ******************************************************");
        StringBuilder sw = new StringBuilder();
        sw.append("Hello, Im the Database Test and ");

        // contentExtractProductDao.getEntityManager().

        // EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("pu1");
        // EntityManager entityManager = entityManagerFactory.createEntityManager();

        Connection conn = contentExtractDataSource.getConnection();
        if (conn == null)
        {
        	sw.append("conn is null, ");
            System.out.println("conn is null");
        }
        else
        {
        	sw.append("conn is NOT null, ");
            System.out.println("conn is NOT null");
        }

        if (em_contentExtract == null)
        {
        	sw.append("Content Extract: em is null, ");
            System.out.println("Content Extract: em is null");
        }
        else
        {
        	sw.append("Content Extract: em is NOT null, ");
            System.out.println("Content Extract: em is NOT null");
        }

        if (em_phase2 == null)
        {
        	sw.append("Phase 2: em is null, ");
            System.out.println("Phase 2: em is null");
        } 
        else
        {
        	sw.append("Phase 2: em is NOT null, ");
            System.out.println("Phase 2: em is NOT null");
        }
        
        System.out.println("end db ********************************************************");

        return sw.toString();
    }

    @RequestMapping(value = "/break.cmd", method = RequestMethod.GET, headers = "Accept=text/html, application/json", produces = "application/json")
    public @ResponseBody
    String breakIt(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        System.out.println("start breakIt ******************************************************");
        StringBuilder sw = new StringBuilder();
        sw.append("Hello, Im the Break Test and ");
        
        if (true)
        {
            try
            {
                throw new Exception("You broke it!!");
            }
            catch (Exception e)
            {
            	sw.append("You broke it bad! Hey go check the logs to see what you broke.");
            	LOGGER.error("You broke it bad!", e);
            }
        }
        
        System.out.println("end breakIt ********************************************************");

        return sw.toString();
    }

    @RequestMapping(value = "/break2.cmd", method = RequestMethod.GET, headers = "Accept=text/html, application/json", produces = "application/json")
    public @ResponseBody
    String breakIt2(HttpServletRequest request, HttpServletResponse response) throws Exception
    {
        System.out.println("start breakIt ******************************************************");

        System.out.println("end breakIt ********************************************************");

        if (true)
        {
            throw new Exception("You broke it2!!");

        }

        return "Hello, Im the Break Test 2 and ... you'll never see this ";
    }

    /*
     * public static boolean hasBsfConn() throws Exception { boolean flag = false; Connection conn = null; try { conn =
     * Init.getInstance().getConnection(); if(conn != null){ flag = true; } } catch (Exception e) {
     * DBUtil.handleSQLException(conn); LOG.error("hasBsfConn failed", e); } finally { DBUtil.closeConn(conn); } return
     * flag; }
     */

}

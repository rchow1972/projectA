package com.silkroute.epiadmintool.controllers;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.silkroute.epi.contentextract.dao.ContentExtractProductDao;
import com.silkroute.epi.contentextract.dao.ProductIdXEditionDao;
import com.silkroute.epi.contentextract.entity.ContentExtractProduct;
import com.silkroute.epi.contentextract.entity.ProductIdXEdition;
import com.silkroute.epi.contentextract.entity.ProductIdXEditionPK;
import com.silkroute.epiadmintool.contentextract.model.ProductMapModel;
import com.silkroute.epiadmintool.exception.FormException;
import com.silkroute.epiadmintool.model.EPIAdminToolResponse;

@Controller
public class ContentExtractAdminController extends BaseController
{

    Logger LOGGER = Logger.getLogger(ContentExtractAdminController.class);
    
	public static String SEARCH_TYPE_PRODUCTID = "productId";
	public static String SEARCH_TYPE_PRODUCTNAME = "productName";
	public static String SEARCH_TYPE_XEDITION = "xEdition";

    @Autowired
    ContentExtractProductDao contentExtractProductDao;
    
    @Autowired
    ProductIdXEditionDao productIdXEditionDao;

//    @RequestMapping(value = "/home.htm", method = RequestMethod.GET)
//    public String home(HttpServletRequest request, HttpServletResponse response) throws Exception
//    {
//        return "home";
//    }
    
    @RequestMapping(value = "contentextract/resultsByPage.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse searchResultsByPage(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
    	List<ProductMapModel> offerModelList = new ArrayList<ProductMapModel>();
    	
    	String searchType = request.getParameter("searchType");
    	
    	String searchParam = request.getParameter("searchParam");;
    	
        int currentPage = 1;
        try {
        	int requestPage = Integer.parseInt(request.getParameter("page"));
        	currentPage = requestPage;
//        	currentPage = requestPage > 0 ? requestPage : 1;
        } catch (NumberFormatException nfe) {}    	
    	
        int numberOfPages = 1;
        
        try
        {
           //Validate input
           FormException formException = new FormException();
           if(formException.hasError()){
               throw formException;
           } 
           
	        if (searchType == null || searchType.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Search Type was not provided.");
	        }

	        if (searchParam == null || searchParam.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Search Param was not provided.");
	        }
	        
	        numberOfPages = productIdXEditionDao.resultCountAsPage(searchType, searchParam);
//	        currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;

	        if ( currentPage > 0 && currentPage <= numberOfPages) {
		        List<ProductIdXEdition> productIdXEditionList;
		        if ( SEARCH_TYPE_PRODUCTNAME.equals(searchType) ) {
		        	productIdXEditionList = productIdXEditionDao.findByProductNamePage(searchParam, currentPage); 	
		        } else if ( SEARCH_TYPE_PRODUCTID.equals(searchType) ) {
		        	productIdXEditionList = productIdXEditionDao.findByProductIdPage(searchParam, currentPage);
		        } else if ( SEARCH_TYPE_XEDITION.equals(searchType) ) {
		        	productIdXEditionList = productIdXEditionDao.findByXEditionPage(searchParam, currentPage);
		        } else {
		        	throw new Exception("Invalid Search Type provided.");
		        }	        
	        
//           List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductNamePage(productName, currentPage);
	           LOGGER.debug("searchByProductName contentExtractProduct.size: " + productIdXEditionList.size());
	           offerModelList = getProductMapModelList(searchParam, productIdXEditionList);
	           ceResponse.setData(offerModelList);
	           ceResponse.setResponseStatus("success");
	           ceResponse.setResponseMessage("Found " + offerModelList.size() + " Product(s) using Page Search (" + searchParam + ")");
	           ceResponse.setPage(String.valueOf(currentPage));
	           ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        } else {
	           ceResponse.setData(offerModelList);
	           ceResponse.setResponseStatus("fail");
	           ceResponse.setResponseMessage("Requested Page Not Available");
	           ceResponse.setPage(String.valueOf(currentPage));
	           ceResponse.setNumberOfPages(String.valueOf(numberOfPages));	        	
	        }
        }
        catch (FormException fe)
        {
        	LOGGER.error(fe);
            throw fe;

        }
        catch (Exception ex)
        {
        	LOGGER.error(ex);
            throw ex;
        }
    	
    	return ceResponse;
    }
    
    
    @RequestMapping(value = "contentextract/searchByProductName.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse searchByProductName(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
        List<ProductMapModel> offerModelList = new ArrayList<ProductMapModel>();
        
        String productName = null;
        try {
        	productName = request.getParameter("productName");
        	LOGGER.debug("searchByProductName productName: " + productName);
        } catch (Exception ex) {}
        
        ServletInputStream sis = null;
        if (productName == null) {
        	ObjectMapper ob = new ObjectMapper();
        	
        	try {
        		sis = request.getInputStream();
        		ob.readTree(sis);
        		
        		sis.close();
        	} catch (Exception ex) {
        		LOGGER.error(ex);
        	} finally {
        		try {
        			sis.close();
        		} catch (IOException ex) {
        		}
        	}
        }
        
        int currentPage = 1;
        try {
        	currentPage = Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException nfe) {}
        
        try
        {
           //Validate input
           FormException formException = new FormException();
           if(formException.hasError()){
               throw formException;
           } 
           
	        if (productName == null || productName.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Product Name was not provided.");
	        }
           
	        int numberOfPages = productIdXEditionDao.resultCountAsPage("productName", productName);
	        currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;
	        
           List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductName(productName);
//           List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductNamePage(productName, currentPage);
           LOGGER.debug("searchByProductName contentExtractProduct.size: " + productIdXEditionList.size());
           offerModelList = getProductMapModelList(productName, productIdXEditionList);
           ceResponse.setData(offerModelList);
           ceResponse.setResponseStatus("success");
           ceResponse.setResponseMessage("Found " + offerModelList.size() + " Product(s) using Product Name (" + productName + ")");
           ceResponse.setPage(String.valueOf(currentPage));
           ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
           
        }
        catch (FormException fe)
        {
        	LOGGER.error(fe);
            throw fe;

        }
        catch (Exception ex)
        {
        	LOGGER.error(ex);
            throw ex;
        }

        return ceResponse;

    }

    @RequestMapping(value = "contentextract/searchByProductId.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse searchByProductId(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
        List<ProductMapModel> offerModelList = new ArrayList<ProductMapModel>();
        
        String productId = request.getParameter("productId");
        LOGGER.debug("searchByProductId productId: " + productId);
        
        int currentPage = 1;
        try {
        	currentPage = Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException nfe) {}
        try
        {
           //Validate input
           FormException formException = new FormException();
           if(formException.hasError()){
               throw formException;
           } 

           if (productId == null || productId.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Product Id was not provided.");
           }
	        
           List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductId(productId);
           offerModelList = getProductMapModelList(productId, productIdXEditionList);
           ceResponse.setData(offerModelList);
            ceResponse.setResponseStatus("success");
            ceResponse.setResponseMessage("Found " + offerModelList.size() + " Product(s) using Product Id (" + productId + ")");
            ceResponse.setPage(String.valueOf(currentPage));
            ceResponse.setNumberOfPages(productIdXEditionDao.resultCountAsPage("productId", productId).toString());
        }
        catch (FormException fe)
        {
        	LOGGER.error(fe);
            throw fe;

        }
        catch (Exception ex)
        {
        	LOGGER.error(ex);
            throw ex;
        }

        return ceResponse;
    }

    @RequestMapping(value = "contentextract/searchByXEdition.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse searchByXEdition(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
        List<ProductMapModel> offerModelList = new ArrayList<ProductMapModel>();
        
        String xEdition = request.getParameter("xEdition");
        LOGGER.debug("searchByXEdition productId: " + xEdition);
        
        int currentPage = 1;
        try {
        	currentPage = Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException nfe) {}
        
        try
        {
            
           //Validate input
           FormException formException = new FormException();
           if(formException.hasError()){
               throw formException;
           }
           
	        if (xEdition == null || xEdition.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("XEdition was not provided.");
	        }
           
           List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByXEdition(xEdition);
           LOGGER.debug("searchByProductName contentExtractProduct.size: " + productIdXEditionList.size());
           offerModelList = getProductMapModelList(xEdition, productIdXEditionList);
           ceResponse.setData(offerModelList);
           ceResponse.setResponseStatus("success");
           ceResponse.setResponseMessage("Found " + offerModelList.size() + " Product(s) using XEdition (" + xEdition + ")");
           ceResponse.setPage(String.valueOf(currentPage));
           ceResponse.setNumberOfPages(productIdXEditionDao.resultCountAsPage("xEdition", xEdition).toString());
        }
        catch (FormException fe)
        {
        	LOGGER.error(fe);
            throw fe;

        }
        catch (Exception ex)
        {
        	LOGGER.error(ex);
            throw ex;
        }

        return ceResponse;
    }

    private List<ProductMapModel> getProductMapModelList(String searchParam, List<ProductIdXEdition> productIdXEditionList) {
    	List<ProductMapModel> offerModelList = new ArrayList<ProductMapModel>();
//    	HashMap<String, ContentExtractProduct> productCache = new HashMap<String, ContentExtractProduct>();
    	
        for(ProductIdXEdition productIdXEdition : productIdXEditionList){
        	ContentExtractProduct product = null;
//        	if ( productCache.containsKey(productIdXEdition.getProductId())) {
//        		product = productCache.get(productIdXEdition.getProductId());
//        	} else {
        		product = contentExtractProductDao.findByProductId(productIdXEdition.getProductId());
//	        	productCache.put(productIdXEdition.getProductId(), contentExtractProductDao.findByProductId(productIdXEdition.getProductId()));
//	        }
        	
            ProductMapModel offerModel = new ProductMapModel();
            if ( product != null ) {
         	   offerModel.setProductName(product.getProductName());
            } else {
         	   offerModel.setProductName("Product Not Found - Search Param: " + searchParam);
            }
            offerModel.setProductId(productIdXEdition.getProductId());
            offerModel.setxEdition(productIdXEdition.getXEdition());
            offerModelList.add(offerModel);
        }
    	return offerModelList;
	}

	@RequestMapping(value = "contentextract/addMapping.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse addProductXEditionMapping(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	

        String xEdition = request.getParameter("xEdition");
        String productId = request.getParameter("productId");
        
        int currentPage = 1;
        try {
        	currentPage = Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException nfe) {}
        
        try {

	        if (xEdition == null || xEdition.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("XEdition was not provided.");
	        }
	        
	        if (productId == null || productId.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Product Id was not provided.");
	        }
	        
//	        if (contentExtractProductDao.findByProductId(productId) == null) {
//	        	// Fail - should not add product if product is not in system.
//	        	throw new Exception("Product with Product Id (" + productId + ") does not exist.");
//	        }
	        
	        LOGGER.debug("addMapping.cmd: (" + productId + "," + xEdition + ")");
	        
	        ProductIdXEditionPK pk = new ProductIdXEditionPK(productId, xEdition); 
	        if ( productIdXEditionDao.find(pk) == null ) {
		        // Add Data
		        ProductIdXEdition addProd = new ProductIdXEdition(productId, xEdition);
		        productIdXEditionDao.persist(addProd);

		        int numberOfPages = productIdXEditionDao.resultCountAsPage("productId", productId);
		        currentPage = currentPage <= numberOfPages ? currentPage : 1;
		        
		        List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductIdPage(productId, currentPage);
		        ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
		        ceResponse.setResponseStatus("success");
	            ceResponse.setResponseMessage("Added Mapping (" + productId + "," + xEdition + ")" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        } else {
		        int numberOfPages = productIdXEditionDao.resultCountAsPage("productId", productId);
		        currentPage = currentPage <= numberOfPages ? currentPage : 1;
		        
				List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductId(productId);
				ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
		        ceResponse.setResponseStatus("fail");
	            ceResponse.setResponseMessage("Mapping (" + productId + "," + xEdition + ") Already Present" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        }
        } catch (Exception ex) {
        	ceResponse.setData(new ArrayList<ProductMapModel>());
        	ceResponse.setResponseStatus("fail");
            ceResponse.setResponseMessage("Add Mapping: " + ex.getMessage());
            ceResponse.setPage("1");
            ceResponse.setNumberOfPages("1");
            
            LOGGER.error(ex);
        }
    	
    	return ceResponse;
    }
    
    @RequestMapping(value = "contentextract/editMapping.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse editProductXEditionMapping(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
    	
        String xEdition = request.getParameter("xEdition");
        String productId = request.getParameter("productId");
        String prevXEdition = request.getParameter("prevXEdition");
        String prevProductId = request.getParameter("prevProductId");
        
        int currentPage = 1;
        try {
        	currentPage = Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException nfe) {}
        
        try {

	        if (xEdition == null || xEdition.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("XEdition was not provided.");
	        }
	        
	        if (productId == null || productId.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Product Id was not provided.");
	        }

	        if (prevXEdition == null || prevXEdition.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Previous XEdition was not provided.");
	        }
	        
	        if (prevProductId == null || prevProductId.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Previous Product Id was not provided.");
	        }
	        
	        LOGGER.debug("editMapping.cmd: (" + productId + "," + xEdition + ")");
	        
	        int numberOfPages = productIdXEditionDao.resultCountAsPage("productId", productId);
	        currentPage = currentPage <= numberOfPages ? currentPage : 1;
	        
	        // Add Data
	        ProductIdXEdition prevMap = new ProductIdXEdition(prevProductId, prevXEdition);
	        ProductIdXEdition newMap = new ProductIdXEdition(productId, xEdition);
	    
	        ProductIdXEditionPK prevPk = new ProductIdXEditionPK(prevProductId, prevXEdition); 
	        ProductIdXEditionPK newPk = new ProductIdXEditionPK(productId, xEdition);
	        
	        boolean hasPrevMap = (productIdXEditionDao.find(prevPk) != null);
	        boolean hasNewMap = (productIdXEditionDao.find(newPk) == null);
	        
	        if (hasNewMap && hasPrevMap) {
	        	int updatedRows = productIdXEditionDao.updateMapping(prevMap, newMap);
	        	
				List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductIdPage(productId, currentPage);
				ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
		        ceResponse.setResponseStatus("success");
	            ceResponse.setResponseMessage("Edited " + updatedRows + " Mapping(s) from (" + prevProductId + "," + prevXEdition + ") to (" + productId + "," + xEdition + ")" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        } else if (!hasNewMap ) {
	        	// Updated form already exists, do not update
				List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductIdPage(productId, currentPage);
				ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
		        ceResponse.setResponseStatus("fail");
	            ceResponse.setResponseMessage("Mapping (" + productId + "," + xEdition + ") Already Present" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        } else if (!hasPrevMap) {
	        	// Updated form already exists, do not update
				List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductIdPage(productId, currentPage);
				ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
		        ceResponse.setResponseStatus("fail");
	            ceResponse.setResponseMessage("Previous Mapping (" + prevProductId + "," + prevXEdition + ") Not Found" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));	        }
        } catch (Exception ex) {
        	ceResponse.setData(new ArrayList<ProductMapModel>());
        	ceResponse.setResponseStatus("fail");
            ceResponse.setResponseMessage("Edit Mapping: " + ex.getMessage());
            ceResponse.setPage("1");
            ceResponse.setNumberOfPages("1");
            
            LOGGER.error(ex);
        }
    	
    	return ceResponse;
    }
    
    @RequestMapping(value = "contentextract/deleteMapping.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse deleteProductXEditionMapping(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception
    {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();

        String xEdition = request.getParameter("xEdition");
        String productId = request.getParameter("productId");
        
        int currentPage = 1;
        try {
        	currentPage = Integer.parseInt(request.getParameter("page"));
        } catch (NumberFormatException nfe) {}
        
        try {

	        if (xEdition == null || xEdition.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("XEdition was not provided.");
	        }
	        
	        if (productId == null || productId.trim().length() == 0) {
	        	// Fail - no data
	        	throw new Exception("Product Id was not provided.");
	        }
	        
	        LOGGER.debug("deleteMapping.cmd: (" + productId + "," + xEdition + ")");

	        ProductIdXEdition delProd = new ProductIdXEdition(productId, xEdition);
	        ProductIdXEditionPK pk = new ProductIdXEditionPK(productId, xEdition); 
	        if ( productIdXEditionDao.find(pk) != null ) {
		        int updatedRows = productIdXEditionDao.deleteMapping(delProd);
		        
		        int numberOfPages = productIdXEditionDao.resultCountAsPage("productId", productId);
		        currentPage = currentPage <= numberOfPages ? currentPage : numberOfPages;
		        
				List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductIdPage(productId, currentPage);
				ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
	            ceResponse.setResponseStatus("success");
	            ceResponse.setResponseMessage("Deleted " + updatedRows + " Mapping(s) for (" + productId + "," + xEdition + ")" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        } else {
		        int numberOfPages = productIdXEditionDao.resultCountAsPage("productId", productId);
		        currentPage = currentPage <= numberOfPages ? currentPage : 1;
		        
				List<ProductIdXEdition> productIdXEditionList = productIdXEditionDao.findByProductIdPage(productId, currentPage);
				ceResponse.setData(getProductMapModelList(productId, productIdXEditionList));
	            ceResponse.setResponseStatus("fail");
	            ceResponse.setResponseMessage("Product Not Found To Delete" );
	            ceResponse.setPage(String.valueOf(currentPage));
	            ceResponse.setNumberOfPages(String.valueOf(numberOfPages));
	        }
	        
	        
	        
        } catch (Exception ex) {
        	ceResponse.setData(new ArrayList<ProductMapModel>());
        	ceResponse.setResponseStatus("fail");
            ceResponse.setResponseMessage("Delete Mapping: " + ex.getMessage());
            ceResponse.setPage("1");
            ceResponse.setNumberOfPages("1");
            
            LOGGER.error(ex);
        }
    	
    	return ceResponse;
    }
}

package com.silkroute.epiadmintool.controllers;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.silkroute.epiadmintool.exception.FormException;
import com.silkroute.epiadmintool.model.EPIAdminToolResponse;
import com.silkroute.epiadmintool.model.LoginResponse;
import com.silkroute.epiadmintool.util.LdapUtil;

@Controller
public class LoginController extends BaseController {

    Logger LOGGER = Logger.getLogger(LoginController.class);
    private static String COMMA_SEPARATED_LIST_W_WHITESPACE = "\\W*,\\W*";

    @Autowired
    private Properties loginProperties;
    
    @Autowired
    LdapUtil ldapAuthenticator;
    
    @RequestMapping(value = "login.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    LoginResponse login(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception {
    	LoginResponse ceResponse = new LoginResponse();

        String username = request.getParameter("username");
        String lowercaseUsername = request.getParameter("username").toLowerCase();
        
        String password = request.getParameter("password");
        
        try{
        	//Validate input
	        FormException formException = new FormException();
	        
	        //test form not blank or null
	        if(username == null || "".equals(username)){
	        	ceResponse.setResponseStatus("fail");
	        	ceResponse.setResponseMessage("Username cannot be blank or null");
	        	return ceResponse;
	        }
	        
	        if(password == null || "".equals(password)){
	        	ceResponse.setResponseStatus("fail");
	        	ceResponse.setResponseMessage("Password cannot be blank or null");
	        	return ceResponse;
	        }
	        
	        //validate user
//	        if("admin".equals(username) && "nimda".equals(password)){
//	            request.getSession().setAttribute("username", username);
//	            ceResponse.setResponseStatus("success");
//	            ceResponse.setResponseMessage("Username & Password is correct");
//	        }else{
//	        	ceResponse.setResponseStatus("fail");
//	        	ceResponse.setResponseMessage("Username/Password is incorrect");
//	        }

	        // Load Properties File
	        // Get User Info
	        // Pass User Info into Model
	        // Return Model
	        
	        try {
//    	        FileInputStream fis = new FileInputStream(new File(loginPropertiesFile));
//    	        Properties loginProperties = new Properties();
//    	        loginProperties.load(fis);
    	        
	        	if(!ldapAuthenticator.authenticate(username, password)){
	        		throw new Exception();
	        	}
	        	
	        	String[] memberList = ldapAuthenticator.userMemeberOfList(username);
	        	
	        	HashMap<String, String> permissionMap = new HashMap<String, String>();
	        	
	        	String availablePermission = loginProperties.getProperty("login.permissions","CE_Mapping,RED_Reset,Offerldx_Generation");
	            String[] permissionArray = availablePermission.split(COMMA_SEPARATED_LIST_W_WHITESPACE);
	            
	            for(String permission: permissionArray) {
	            	permissionMap.put(permission, "false");
	            }
	            LOGGER.debug(permissionMap.toString());
		    	
	            for(int i=0; i < memberList.length ; i++ ) {
	            	String defaultValue = "false";
		            for(String permission: permissionArray) {
		            	if(memberList[i].contains("EPIAdmin-" + permission)) {
		            		defaultValue = "true";
		            		permissionMap.put(permission, defaultValue);
		            		continue;
		            	}
		            }   
		    	}
	            LOGGER.debug(permissionMap.toString());
	        	
//	            String checkPass = loginProperties.getProperty("user." + lowercaseUsername + ".pass");
//	            if(!checkPass.equals(password)){
//	                throw new Exception();
//	            }
//
//                HashMap<String, String> permissionMap = new HashMap<String, String>();
//
//	            String availablePermission = loginProperties.getProperty("login.permissions","fullaccess,contentextract,redemptionreset,offerindexgenerator");
//	            String[] permissionArray = availablePermission.split(COMMA_SEPARATED_LIST_W_WHITESPACE);
//
//	            String defaultValue = "false";
//                try {
//                    String fullAccess = loginProperties.getProperty("user." + lowercaseUsername + ".fullaccess");
//                    if (fullAccess.equalsIgnoreCase("true")){
//                        defaultValue = "true";
//                    }
//                } catch (Exception ex) {
//                }
//	            for(String permission: permissionArray) {
//                    permissionMap.put(permission, loginProperties.getProperty("user." + lowercaseUsername + "." + permission, defaultValue) );
//	            }
	            
	            ceResponse.setResponseStatus("success");
	            ceResponse.setResponseMessage("Username & Password is correct");
	            ceResponse.setPermissionMap(permissionMap);
	            try{
	                request.getSession().setAttribute("login", ceResponse);
	            } catch (Exception ex) {
	                LOGGER.debug("Login");
	                LOGGER.error(ex);
	            }
	            
	            try{
	                request.getSession().setAttribute("username", username);
	            } catch (Exception ex) {
	                LOGGER.debug("User");
                    LOGGER.error(ex);
                }
	        } catch (FileNotFoundException ex) {
                ceResponse.setResponseStatus("fail");
                ceResponse.setResponseMessage("Connection to credentials failed");
            } catch (IOException ex) {
                ceResponse.setResponseStatus("fail");
                ceResponse.setResponseMessage("Connection to credentials failed");  
	        } catch (Exception ex) {
                ceResponse.setResponseStatus("fail");
                ceResponse.setResponseMessage("Username/Password is incorrect");	            
	        }
	        
	        if(formException.hasError()){
	            throw formException;
	        }
        } catch (FormException fe) {
        	LOGGER.error(fe);
        	throw fe;

        } catch (Exception ex) {
        	LOGGER.error(ex);
        	throw ex;
        }
           
        return ceResponse;
    };
    
    @RequestMapping(value = "logout.cmd", method = RequestMethod.POST, headers = "Accept=application/xml, application/json", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse logout(HttpServletRequest request, HttpServletResponse response) throws FormException, Exception {
    	EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();
        
        try{
        	//Validate input
	        FormException formException = new FormException();
	        
	        if(request.getSession().getAttribute("username") == null){
	        	ceResponse.setResponseStatus("fail");
	        	ceResponse.setResponseMessage("User missing session could not logout a null user.");
	        }
	        
	        if(request.getSession().getAttribute("username") != null){
	        	request.getSession().removeAttribute("username");
	        	ceResponse.setResponseStatus("success");
	        	ceResponse.setResponseMessage("User is logged out.");
	        }
            
            if(request.getSession().getAttribute("login") != null){
                request.getSession().removeAttribute("login");
            }
	        
	        if(formException.hasError()){
	            throw formException;
	        }
        } catch (FormException fe) {
        	LOGGER.error(fe);
        	throw fe;

        } catch (Exception ex) {
        	LOGGER.error(ex);
        	throw ex;
        }
           
        return ceResponse;
    };    
}

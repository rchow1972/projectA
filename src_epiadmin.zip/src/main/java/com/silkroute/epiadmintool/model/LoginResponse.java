package com.silkroute.epiadmintool.model;

import java.io.Serializable;
import java.util.HashMap;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@SuppressWarnings("serial")
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class LoginResponse implements Serializable {
   
    private String responseMessage;
    
    private String responseStatus;

    private HashMap<String, String> permissionMap;
    
    public String getResponseMessage() {
        return responseMessage;
    }

    public void setResponseMessage(String responseMessage) {
        this.responseMessage = responseMessage;
    }

    public String getResponseStatus() {
        return responseStatus;
    }

    public void setResponseStatus(String responseStatus) {
        this.responseStatus = responseStatus;
    }

    public HashMap<String, String> getPermissionMap() {
        return permissionMap;
    }

    public void setPermissionMap(HashMap<String, String> permissionMap) {
        this.permissionMap = permissionMap;
    }
}

package com.silkroute.epiadmintool.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;


@XmlRootElement(name = "errors")
public class ErrorList
{

    private List<Error> error = new ArrayList<Error>();

    public List<Error> getError()
    {
        return error;
    }

    public void setError(List<Error> error)
    {
        this.error = error;
    }

    public void addError(String field, String message)
    {
        this.error.add(new Error(field, message));
    }

    public boolean hasError()
    {
        if (error.isEmpty())
        {
            return false;
        }
        return true;
    }
}

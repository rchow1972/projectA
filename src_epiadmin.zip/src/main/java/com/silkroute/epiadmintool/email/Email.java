package com.silkroute.epiadmintool.email;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;





public class Email implements Runnable {
	
	private static final String SMTP_SERVER = "localhost";
	
	private static final String EMAIL_FROM_ADDRESS = "bsf@entertainment.com";

	private String address;

	private String message;

	private String subject;
	

	public Email(String emailAddress, String subject, String message) {
		super();
		this.subject = subject;
		this.address = emailAddress;
		this.message = message;
	}		

	public void run() {
		try {

			Properties props = new Properties();
			// add the protocol
			props.put("mail.transport.protocol", "smtp");
			// add the mail server name			
			props.put("mail.smtp.host", SMTP_SERVER);

			javax.mail.Session session = Session
					.getDefaultInstance(props, null);

			// create a new message
			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(EMAIL_FROM_ADDRESS));
			Address[] addresses = new Address[] { new InternetAddress(
					this.address) };

			msg.setRecipients(Message.RecipientType.TO, addresses);
			msg.setSubject(this.subject);
			msg.setContent(message, "text/html");
			// msg.setText(message);

			// send message
			Transport.send(msg);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	
}
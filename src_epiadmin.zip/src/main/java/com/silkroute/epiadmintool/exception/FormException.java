package com.silkroute.epiadmintool.exception;


import com.silkroute.epiadmintool.model.ErrorList;

public class FormException extends Exception
{

    private ErrorList error = new ErrorList();

    public ErrorList getError()
    {
        return error;
    }

    public void setError(ErrorList error)
    {
        this.error = error;
    }

    public boolean hasError()
    {
        return error.hasError();

    }

    public void addError(String field, String message)
    {
        error.addError(field, message);
    }

}

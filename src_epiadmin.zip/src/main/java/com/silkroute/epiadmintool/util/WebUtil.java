package com.silkroute.epiadmintool.util;

import java.io.IOException;
import java.text.Normalizer;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class WebUtil
{

    public static void doForward(HttpServletRequest request, HttpServletResponse response, String uri) throws ServletException, IOException
    {
        RequestDispatcher rd = request.getRequestDispatcher(uri);
        rd.forward(request, response);
    }

    public static void doRedirect(HttpServletResponse response, String url) throws ServletException, IOException
    {
        response.sendRedirect(response.encodeRedirectURL(url));
    }

    public static void setCookie(String sessionId, HttpServletRequest request, HttpServletResponse response)
    {

        Cookie set_cook = new Cookie("yang", sessionId);
        set_cook.setMaxAge(-1);

        response.addCookie(set_cook);

    }

    public void setCookieTime(String sessionId, HttpServletRequest request, HttpServletResponse response) throws Exception
    {

        Cookie set_cook = new Cookie("yang", sessionId);
        set_cook.setMaxAge(60 * 60 * 24);
        response.addCookie(set_cook);

    }

    public static String getCookieValue(HttpServletRequest request, String name)
    {
        String ret = null;

        Cookie[] cooks = request.getCookies();
        if (cooks != null)
        {
            for (int i = 0; i < cooks.length; i++)
            {
                if (name.equals(cooks[i].getName()))
                {
                    ret = cooks[i].getValue();
                    break;// last is first
                }
            }
        }

        return ret;

    }

    public static String parseDate(Date date, String format)
    {
        String ret = "";
        SimpleDateFormat f = new SimpleDateFormat("MMMM dd");
        try
        {
            f = new SimpleDateFormat(format);
        }
        catch (Exception e)
        {
            System.out.println("invalid format using default");
            // eat
        }
        try
        {
            ret = f.format(date);
        }
        catch (Exception e)
        {
            // eat
        }
        return ret;
    }

    public static Date parseDate(String date, String format) throws Exception
    {
        Date d = null;
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
        try
        {
            f = new SimpleDateFormat(format);
        }
        catch (Exception e)
        {
            System.out.println("invalid format using default");
            // eat
        }
        d = f.parse(date);

        return d;
    }

    public static String encodeSpecial(String s)
    {

        if (s != null)
        {

            s = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
            s = s.replaceAll("�", "!");
            s = s.replaceAll("�", "O");
            s = s.replaceAll("�", "o");
            s = s.replaceAll("�", "s");
            s = s.replaceAll("�", "'");
            s = s.replaceAll("�", "'");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", " ");
            s = s.replaceAll("�", "\"");
            s = s.replaceAll("�", "\"");
            s = s.replaceAll("�", "-");
            s = s.replaceAll("�", "-");
        }

        return s;

    }

}

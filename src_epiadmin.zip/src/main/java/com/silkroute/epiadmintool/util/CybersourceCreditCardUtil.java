package com.silkroute.epiadmintool.util;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.silkroute.epiadmintool.controllers.CCProfileController;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.TimeZone;
import java.util.UUID;

public class CybersourceCreditCardUtil {
	
	static Logger LOGGER = Logger.getLogger(CybersourceCreditCardUtil.class);

	public static boolean init = false;
	
    // EPI Admin Tool Payment
	public static String CYBERSOURCE_URL_VALUE = "";
	
    public static final String CYBERSOURCE_PROFILE_ID_KEY = "profile_id";
    public static String CYBERSOURCE_PROFILE_ID_VALUE =  "";//cybersourceProperties.getProperty("cybersource-epiadmintool-profile-id-key","");

    public static final String CYBERSOURCE_ACCESS_KEY_KEY = "access_key";
    public static String CYBERSOURCE_ACCESS_KEY_VALUE =  "";//cybersourceProperties.getProperty("cybersource-epiadmintool-access-key-key","");

    public static final String CYBERSOURCE_SECRET_KEY_KEY = "secret_key";
    public static String CYBERSOURCE_SECRET_KEY_VALUE = "";//cybersourceProperties.getProperty("cybersource-epiadmintool-secret-key-key","");

    public static final String CYBERSOURCE_TRANSACTION_TYPE_KEY = "transaction_type";
    public static final String CYBERSOURCE_TRANSACTION_TYPE_VALUE = "create_payment_token";

    public static final String CYBERSOURCE_PAYMENT_METHOD_KEY = "payment_method";
    public static final String CYBERSOURCE_PAYMENT_METHOD_VALUE = "card";

    public static final String CYBERSOURCE_CURRENCY_KEY = "currency";
    public static final String CYBERSOURCE_CURRENCY_VALUE = "usd";

    public static final String CYBERSOURCE_SIGNED_FIELD_NAMES_KEY = "signed_field_names";
    public static final String CYBERSOURCE_SIGNED_FIELD_NAMES_VALUE = "transaction_uuid,signed_date_time,access_key,profile_id,signed_field_names,unsigned_field_names,locale,transaction_type,reference_number,currency,payment_method,bill_to_forename,bill_to_surname,bill_to_email,bill_to_address_line1,bill_to_address_city,bill_to_address_state,bill_to_address_country,bill_to_address_postal_code";

    public static final String CYBERSOURCE_UNSINGED_FIELD_NAMES_KEY = "unsigned_field_names";
    public static final String CYBERSOURCE_UNSINGED_FIELD_NAMES_VALUE = "card_type,card_number,card_expiry_date";

    public static final String CYBERSOURCE_LOCALE_KEY = "locale";
    public static final String CYBERSOURCE_LOCALE_VALUE = "en";

    public static final String CYBERSOURCE_TRANSACTION_UUID_KEY = "transaction_uuid";

    public static final String CYBERSOURCE_BILL_TO_FORENAME_KEY = "bill_to_forename";
    public static final String CYBERSOURCE_BILL_TO_SURNAME_KEY = "bill_to_surname";
    public static final String CYBERSOURCE_BILL_TO_EMAIL_KEY = "bill_to_email";
    public static final String CYBERSOURCE_BILL_TO_ADDRESS_LINE1_KEY = "bill_to_address_line1";
    public static final String CYBERSOURCE_BILL_TO_ADDRESS_CITY_KEY = "bill_to_address_city";
    public static final String CYBERSOURCE_BILL_TO_ADDRESS_STATE_KEY = "bill_to_address_state";
    public static final String CYBERSOURCE_BILL_TO_ADDRESS_COUNTRY_KEY = "bill_to_address_country";
    public static final String CYBERSOURCE_BILL_TO_ADDRESS_POSTAL_CODE_KEY = "bill_to_address_postal_code";
    public static final String CYBERSOURCE_BILL_TO_PHONE_KEY = "bill_to_phone";
    public static final String CYBERSOURCE_SIGNED_DATE_TIME_KEY = "signed_date_time";
    public static final String CYBERSOURCE_ORDER_COLLECTION_SIGNED_DATE_TIME_KEY = "SIGNED_DATE_TIME";
    public static final String CYBERSOURCE_REFERENCE_NUMBER_KEY = "reference_number";
    public static final String CYBERSOURCE_AMOUNT_KEY = "amount";
    public static final String CYBERSOURCE_AMOUNT_VALUE = "0.00";
    public static final String CYBERSOURCE_ORDER_COLLECTION_TRANSACTION_UUID = "CYBERSOURCE_TRANSACTION_UUID";

    private static final String HMAC_SHA256 = "HmacSHA256";

    public static boolean initialized(Properties properties) {
    	if (!init) {
    		try {
    		CYBERSOURCE_URL_VALUE= properties.getProperty("cybersource-epiadmintool-url", "");
    	    CYBERSOURCE_PROFILE_ID_VALUE = properties.getProperty("cybersource-epiadmintool-profile-id-key","");
    	    CYBERSOURCE_ACCESS_KEY_VALUE = properties.getProperty("cybersource-epiadmintool-access-key-key","");
    	    CYBERSOURCE_SECRET_KEY_VALUE = properties.getProperty("cybersource-epiadmintool-secret-key-key","");
    	    
    	    init = true;
    		} catch (Exception ex) {
    			LOGGER.error(ex);
    		}
    	}
    	return init;
    }

	public static String sign(HashMap params, String secretKey) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
        final String data = buildDataToSign(params);
        return sign(data, secretKey);
    }

    private static String sign(String data, String secretKey) throws InvalidKeyException, NoSuchAlgorithmException, UnsupportedEncodingException {
        SecretKeySpec secretKeySpec = new SecretKeySpec(secretKey.getBytes(), HMAC_SHA256);
        Mac mac = Mac.getInstance(HMAC_SHA256);
        mac.init(secretKeySpec);
        byte[] rawHmac = mac.doFinal(data.getBytes("UTF-8"));
        return DatatypeConverter.printBase64Binary(rawHmac).replace("\n", "");
    }

    private static String buildDataToSign(HashMap params) {
        String[] signedFieldNames = String.valueOf(params.get("signed_field_names")).split(",");
        ArrayList<String> dataToSign = new ArrayList<String>();
        for (String signedFieldName : signedFieldNames) {
            dataToSign.add(signedFieldName + "=" + String.valueOf(params.get(signedFieldName)));
        }
        return commaSeparate(dataToSign);
    }

    private static String commaSeparate(ArrayList<String> dataToSign) {
        StringBuilder csv = new StringBuilder();
        for (Iterator<String> it = dataToSign.iterator(); it.hasNext(); ) {
            csv.append(it.next());
            if (it.hasNext()) {
                csv.append(",");
            }
        }
        return csv.toString();
    }


    public static String getUTCDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());

    }

    public static String getCreditCardTypeFromCybersourceType(String ccType) {

        if ("001".equals(ccType)) return "VI";
        else if ("002".equals(ccType)) return "MC";
        else if ("003".equals(ccType)) return "AX";
        else if ("004".equals(ccType)) return "DI";
        else return "";

    }

    public static UUID getRandomUUID() {
    	return UUID.randomUUID();
    }
}



package com.silkroute.epiadmintool.util;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.naming.NamingException;
import javax.naming.directory.Attributes;

import org.apache.log4j.Logger;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.AndFilter;
import org.springframework.ldap.filter.EqualsFilter;



public class LdapUtil{
	
	private LdapTemplate ldapTemplate;
    private String [] memberOfList = new String[0];
    
    Logger LOGGER = Logger.getLogger(LdapUtil.class);
    
	public LdapUtil(LdapTemplate ldapTemplate) {
		this.ldapTemplate = ldapTemplate;
	}

	public String[] userMemeberOfList(String user){
		AndFilter filter = new AndFilter();
	    if(isValidEmailAddress(user)){
	    	filter.and(new EqualsFilter("userPrincipalName", user));
	    }else{	    	
	    	filter.and(new EqualsFilter("sAMAccountName", user));
	    }
		ldapTemplate.search("", filter.encode(), new PersonAttributesMapper());
		return memberOfList;
	}

	public boolean authenticate(String user, String password) {
		AndFilter filter = new AndFilter();
        ldapTemplate.setIgnorePartialResultException(true); 
        if(isValidEmailAddress(user)){
	    	filter.and(new EqualsFilter("userPrincipalName", user));
	    }else{	    	
	    	filter.and(new EqualsFilter("sAMAccountName", user));
	    }
        return ldapTemplate.authenticate("", filter.toString(), password);
	}
	
	private class PersonAttributesMapper implements AttributesMapper<String[]> {
		public String[] mapFromAttributes(Attributes arg0) throws NamingException {
			
			if(arg0.get("memberOf").size()>0){
				memberOfList = new String[arg0.get("memberOf").size()];
				for(int i=0; i <arg0.get("memberOf").size(); i++){
					memberOfList[i] = arg0.get("memberOf").get(i).toString();		
					LOGGER.debug(arg0.get("memberOf").get(i).toString());
				}
			
			}
			return memberOfList;
		}
	}
	
	public static boolean isValidEmailAddress(String email) {
		boolean result = true;
		try {
			InternetAddress emailAddr = new InternetAddress(email);
			emailAddr.validate();
		} catch (AddressException ex) {
			result = false;
		}
		return result;
	}
}
 

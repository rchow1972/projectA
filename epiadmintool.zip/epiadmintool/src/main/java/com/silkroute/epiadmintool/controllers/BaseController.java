package com.silkroute.epiadmintool.controllers;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.silkroute.epiadmintool.exception.FormException;
import com.silkroute.epiadmintool.model.ErrorList;

@Controller
public class BaseController
{
    

    Logger LOGGER = Logger.getLogger(BaseController.class);
    

    @ExceptionHandler
    @ResponseBody
    ErrorList handleException(FormException e)
    {
        LOGGER.error(e);
        return e.getError();
    }
    
    
    
}

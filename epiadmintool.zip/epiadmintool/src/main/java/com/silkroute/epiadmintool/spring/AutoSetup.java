package com.silkroute.epiadmintool.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component("autoSetup")
public class AutoSetup
{
    static AutoSetup obj = null;

    public void init()
    {
        obj = this;
    }

    public static AutoSetup getInstance()
    {
        return obj;
    }
}

package com.silkroute.epiadmintool.contentextract.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;


/**
 * This is informative
 * @author mtorni
 *
 */
@SuppressWarnings("serial")
@XmlRootElement
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL) 
public class ProductMapModel implements Serializable
{

   
    private String productName;

    private String productId;

    private String xEdition;


    public ProductMapModel()
    {

    }


    public String getProductName()
    {
        return productName;
    }

    /*
     * @param productName
     *          
     */
    public void setProductName(String productName)
    {
        this.productName = productName;
    }


    public String getProductId()
    {
        return productId;
    }


    public void setProductId(String productId)
    {
        this.productId = productId;
    }


    public String getxEdition()
    {
        return xEdition;
    }


    public void setxEdition(String xEdition)
    {
        this.xEdition = xEdition;
    }
    
    


}

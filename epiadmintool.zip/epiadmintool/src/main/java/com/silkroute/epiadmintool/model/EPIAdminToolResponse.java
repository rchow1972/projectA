package com.silkroute.epiadmintool.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@SuppressWarnings("serial")
@XmlRootElement
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL) 
public class EPIAdminToolResponse implements Serializable {
	
	private Object data;
	
	private String responseMessage;
	
	private String responseStatus;
	
	private String page;
	
	private String numberOfPages;

	// Empty Constructor
	public EPIAdminToolResponse(){}

	// Status Only Constructor
	public EPIAdminToolResponse(String responseStatus) {
		this.responseMessage = responseStatus;
		this.responseStatus = responseStatus;
		this.data = new ArrayList<Object>();
	}

	//Message Only Constructor
	public EPIAdminToolResponse(String responseStatus, String responseMessage) {
		this.responseMessage = responseMessage;
		this.responseStatus = responseStatus;
		this.data = new ArrayList<Object>();
	}

	// Full Constructor
	public EPIAdminToolResponse(String responseStatus, String responseMessage, List<Object> data) {
		this.responseMessage = responseMessage;
		this.responseStatus = responseStatus;
		this.data = data;
	}
	
	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public String getResponseMessage() {
		return responseMessage;
	}

	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}

	public String getResponseStatus() {
		return responseStatus;
	}

	public void setResponseStatus(String responseStatus) {
		this.responseStatus = responseStatus;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

	public String getNumberOfPages() {
		return numberOfPages;
	}

	public void setNumberOfPages(String numOfPages) {
		this.numberOfPages = numOfPages;
	}
}

package com.silkroute.epiadmintool.util;

import java.security.Security;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.bouncycastle.util.encoders.Hex;

public class EncryptionUtil
{

    private static byte[] KEY_BYTES = "DatapakR3portZVP".getBytes();
    private static byte[] IV_BYTES = "BASFkAtYDiD4VPOL".getBytes();

    public static void main(String[] args) throws Exception
    {
        String clearText = "The quick brown fox jumped over the lazy dog.";
        String encryptedText = EncryptionUtil.encrypt(clearText);
        String decryptedText = EncryptionUtil.decrypt(encryptedText);

        System.out.println(clearText);
        System.out.println(encryptedText);
        System.out.println(decryptedText);
    }

    public static String encrypt(String clearText) throws Exception
    {
        if (!initialized)
        {
            initialize();
        }

        cipher.init(Cipher.ENCRYPT_MODE, key, iv);
        byte[] cipherText = cipher.doFinal(clearText.getBytes());
        byte[] hexText = Hex.encode(cipherText);
        return new String(hexText).toUpperCase();
    }

    public static String decrypt(String encryptedText) throws Exception
    {
        if (!initialized)
        {
            initialize();
        }

        byte[] encryptedBytes = Hex.decode(encryptedText.getBytes());
        cipher.init(Cipher.DECRYPT_MODE, key, iv);
        byte[] plainText = cipher.doFinal(encryptedBytes);
        return new String(plainText);
    }

    private static void initialize() throws Exception
    {
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

        cipher = Cipher.getInstance("AES/CBC/PKCS7Padding", "BC");
        key = new SecretKeySpec(KEY_BYTES, "AES");
        iv = new IvParameterSpec(IV_BYTES);

        initialized = true;
    }

    private static boolean initialized = false;
    private static Cipher cipher = null;
    private static SecretKeySpec key = null;
    private static IvParameterSpec iv = null;

}

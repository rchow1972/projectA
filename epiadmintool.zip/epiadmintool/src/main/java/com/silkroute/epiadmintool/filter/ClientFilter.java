package com.silkroute.epiadmintool.filter;

import java.util.Enumeration;
import java.util.HashMap;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Cookie;

import org.apache.log4j.Logger;

import com.silkroute.epiadmintool.model.LoginResponse;



public class ClientFilter implements Filter
{


    
    private Logger LOGGER = Logger.getLogger(ClientFilter.class);
    private static long requestId = 0;

    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws java.io.IOException, ServletException
    {
        

        LOGGER.debug("start request id: " + requestId);
        

        HttpServletRequest httprequest = ((HttpServletRequest) request);
        HttpServletResponse httpresponse = ((HttpServletResponse) response);
        HttpSession session = httprequest.getSession();

        boolean authenticated = false;
        LOGGER.debug("request uri: " + httprequest.getRequestURI());
        if(httprequest.getRequestURI().contentEquals("/epiadmintool/") || httprequest.getRequestURI().endsWith("login.cmd") || httprequest.getRequestURI().endsWith("logout.cmd")){
            authenticated = true;
        }else{
            if(session.getAttribute("username") != null){
                try {
                    LoginResponse loginResponse = (LoginResponse) session.getAttribute("login");
                    HashMap<String, String> permissionMap = loginResponse.getPermissionMap();
                    LOGGER.debug(permissionMap.toString());
                    
                    if(httprequest.getRequestURI().contains("/epiadmintool/contentextract/")) {
                    	authenticated = Boolean.parseBoolean(permissionMap.get("CE_Mapping"));
                    }
                    
                    if(httprequest.getRequestURI().contains("/epiadmintool/redemptionreset/")) {
                        authenticated = Boolean.parseBoolean(permissionMap.get("RED_Reset"));
                    }
                    
                    if(httprequest.getRequestURI().contains("/epiadmintool/offerindexgenerator/")) {
                        authenticated = Boolean.parseBoolean(permissionMap.get("Offerldx_Generation"));
                    }
                    
                    if(httprequest.getRequestURI().contains("/epiadmintool/info/")) {
                    	authenticated = true;
                    }

                    if(httprequest.getRequestURI().contains("/epiadmintool/creditcardprofile/")) {
//                    	authenticated = Boolean.parseBoolean(permissionMap.get("NotYetImplemented"));
                    	authenticated = true;
                    }

                    if(httprequest.getRequestURI().contains("/epiadmintool/grouporder/")) {
//                    	authenticated = Boolean.parseBoolean(permissionMap.get("NotYetImplemented"));
                    	authenticated = true;
                    }

                    
//                    for (String key :permissionMap.keySet()){
//                        String requestUri = httprequest.getRequestURI().contains();
//                        
//                        if(httprequest.getRequestURI().contains("/epiadmintool/"+ key +"/")) {
//                            authenticated = Boolean.parseBoolean(permissionMap.get(key));
//                            break;
//                        } 
//                    }
                } catch (Exception ex) {
                }            
            }
        }
        LOGGER.debug("request uri: " +"authenticated: " + authenticated);

        if(authenticated){
            chain.doFilter(request, response);            
        }else{
            RequestDispatcher rd = httprequest.getRequestDispatcher("/");
            rd.forward(request, response);
        }
        
        LOGGER.debug("end request id: " + requestId);
        requestId++;
        
   

    }

    private void setCookie(String sessionId, HttpServletRequest request, HttpServletResponse response)
    {
        try
        {
            Cookie set_cook = new Cookie("yang", sessionId);
            set_cook.setMaxAge(60 * 60 * 24);
            response.addCookie(set_cook);
        }
        catch (Exception e)
        {
            LOGGER.error("ClientRequestFilter:SetCookie", e);
        }
    }

    private static String getCookieValue(HttpServletRequest request, String name)
    {
        String ret = null;

        Cookie[] cooks = request.getCookies();
        if (cooks != null)
        {
            for (int i = 0; i < cooks.length; i++)
            {
                if (name.equals(cooks[i].getName()))
                {
                    ret = cooks[i].getValue();
                    break;// last is first
                }
            }
        }

        return ret;

    }
    
    private void printHeaders(HttpServletRequest req){
 //       System.out.println("*********************************************");
        Enumeration<String> headerNames = req.getHeaderNames();
        while (headerNames.hasMoreElements()) {

                String headerName = headerNames.nextElement();
                System.out.println(headerName + ":");
                

                Enumeration<String> headers = req.getHeaders(headerName);
                while (headers.hasMoreElements()) {
                        String headerValue = headers.nextElement();
                        System.out.println(headerValue);
                
                }

        }
//        System.out.println("*********************************************");
    }

    /**
     * Destroy  free up any resources that are being used
     */
    public void destroy()
    {

    }

    /**
     * init
     * 
     * @param filterConfig
     *            Description of the Parameter
     */
    public void init(FilterConfig filterConfig)
    {

    }

}

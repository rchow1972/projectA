package com.silkroute.epiadmintool.redemptionreset.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElements;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.map.annotate.JsonSerialize;


@SuppressWarnings("serial")
@XmlRootElement
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL) 
public class RedemptionModel implements Serializable
{
	String redemptionId;
	String offerId;
	String redemptionLocationId;
	String redeemMethod;
	String redeemDate;
	String resetDate;
	
	String merchant;
	String offerDetail;
	
	String address;

	
    public RedemptionModel()
    {
    }

	public String getRedemptionId() {
		return redemptionId;
	}


	public void setRedemptionId(String id) {
		this.redemptionId = id;
	}

	public String getOfferId() {
		return offerId;
	}


	public void setOfferId(String offerId) {
		this.offerId = offerId;
	}


	public String getRedemptionLocationId() {
		return redemptionLocationId;
	}


	public void setRedemptionLocationId(String redemptionLocationId) {
		this.redemptionLocationId = redemptionLocationId;
	}


	public String getRedeemMethod() {
		return redeemMethod;
	}


	public void setRedeemMethod(String redeemMethod) {
		this.redeemMethod = redeemMethod;
	}


	public String getRedeemDate() {
		return redeemDate;
	}


	public void setRedeemDate(String redeemDate) {
		this.redeemDate = redeemDate;
	}


	public String getResetDate() {
		return resetDate;
	}

	public void setResetDate(String resetDate) {
		this.resetDate = resetDate;
	}

	public String getMerchant() {
		return merchant;
	}


	public void setMerchant(String merchant) {
		this.merchant = merchant;
	}


	public String getOfferDetail() {
		return offerDetail;
	}


	public void setOfferDetail(String offerDetail) {
		this.offerDetail = offerDetail;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}
}

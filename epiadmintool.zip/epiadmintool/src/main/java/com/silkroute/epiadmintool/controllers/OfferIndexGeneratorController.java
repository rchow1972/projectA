package com.silkroute.epiadmintool.controllers;

import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.silkroute.epi.contentextract.dao.ContentExtractOfferIndexGeneratorDao;
import com.silkroute.epi.contentextract.entity.ContentExtractOfferSectionRelationTemp;
import com.silkroute.epiadmintool.model.EPIAdminToolResponse;

/**
 * Handles the request from the browser to upload an excel file Reading the excel file into a list
 * of map objects Mapping query results to the original data from the excel sheet
 * 
 * @author Marika Wegiel (marika.wegiel@silkrouteglobal.com)
 * 
 */
@Controller
public class OfferIndexGeneratorController extends BaseController {

    public Map<Integer, String> excelFormatMap;

    public Map<String, Object> relationMap;
    @Autowired
    ContentExtractOfferIndexGeneratorDao contentExtractOfferIndexGeneratorDao;

    Logger LOGGER = Logger.getLogger(ContentExtractAdminController.class);
    @Autowired
    ContentExtractOfferIndexGeneratorDao offerIndexGeneratorDao;
    public static final String folioNumber = ContentExtractOfferSectionRelationTemp.folioNumberNm;
    public static final String matched = "Matched";
    public static final String offerId = ContentExtractOfferSectionRelationTemp.offerIdNm;
    public static final String offerPk = ContentExtractOfferSectionRelationTemp.offerPkNm;
    public static final String productId = ContentExtractOfferSectionRelationTemp.productIdNm;

    public static final String redemptionLocationId = ContentExtractOfferSectionRelationTemp.redemptionLocationIdNm;

    public static final String version = ContentExtractOfferSectionRelationTemp.versionNm;

    /**
     * Reads the file into a list of maps, mapping the database column name to the value from the
     * workbook
     * 
     * @param is
     *            The name of the file to read
     * @param sheetName
     *            The name of the excel sheet to read
     * @return The list of records, records defined in a map
     * @throws IOException
     *             When a necessary field is not found or there are other issues with opening and
     *             reading the file
     * @throws InvalidFormatException
     *             When the file uploaded is not an excel workbook
     */
    public List<Map<String, Object>> readFile(InputStream is, String sheetName) throws IOException,
            InvalidFormatException {
        LOGGER.debug("Reading from excel file");

        boolean success = true;
        Workbook wb = WorkbookFactory.create(is);
        XSSFSheet ws = (XSSFSheet) wb.getSheet(sheetName);
        List<Map<String, Object>> recordList = new ArrayList<Map<String, Object>>();

        int rowNum = ws.getLastRowNum() + 1;
        String failMessage = new String();
        for (int i = 1; i < rowNum; i++) {
            XSSFRow row = ws.getRow(i);
            relationMap = new HashMap<String, Object>();
            for (Entry<Integer, String> entry : excelFormatMap.entrySet()) {
                int pos = entry.getKey();
                XSSFCell cell = row.getCell(pos);

                if (cell == null) {
                    success = false;
                    failMessage += "Value at column: " + pos + ", row " + i + " is not provided.\n";
                    continue;
                }

                String key = entry.getValue();
                String value = getValue(cell);
                setValue(key, value);
            }
            recordList.add(relationMap);
        }

        if (!success) {
            throw new IOException("Missing values on input file, processing cannot continue\n"
                    + failMessage);
        }
        return recordList;
    }

    /**
     * Maps the ResultSet values to the list of records Logs any records that are missing
     * information
     * 
     * @param resultList
     *            The result set from the query containing the information that wasn't provided in
     *            the excel sheet
     * @param records
     *            The records that exist in memory
     * @return A new list of records, with all fields provided
     * @throws SQLException
     *             Any exception that occurs while reading the result set
     */
    public List<Map<String, Object>> setResults(
            List<ContentExtractOfferSectionRelationTemp> resultList,
            List<Map<String, Object>> records) throws Exception {
        List<Map<String, Object>> newRecords = new ArrayList<Map<String, Object>>();
        LOGGER.debug("Mapping results to original data");

        Iterator<ContentExtractOfferSectionRelationTemp> it = resultList.iterator();
        while (it.hasNext()) {
            ContentExtractOfferSectionRelationTemp entry = it.next();
            String mapOfferId = entry.getOfferId();
            for (int i = 0; i < records.size(); i++) {
                Map<String, Object> record = records.get(i);
                Object recordOfferId = record.get(offerId);
                if (recordOfferId.equals(mapOfferId.toString())) {
                    Map<String, Object> newRecord = setNewRecord(entry, record);
                    newRecords.add(newRecord);
                    record.put(matched, true);
                }
            }
        }

        String failMessage = new String("--------------------------------\n");
        boolean success = true;
        for (int i = 0; i < records.size(); i++) {
            if (!records.get(i).containsKey(matched)) {
                success = false;
                failMessage += "	" + records.get(i).get(offerId)
                        + " could not be matched in the database\n";
            }
        }
        failMessage += "--------------------------------\n";
        if (!success) {
            throw new Exception(
                    "Processing failed because not all offers were found in the database\n"
                            + failMessage);
        }
        return newRecords;
    }

    /**
     * Handles the request from the client to process an excel workbook sheet based on various
     * parameters, where processing means inserting the excel sheet records into the
     * offersectionrelation_temp table, then joining to gather all redemption locations based on the
     * geo market and zip codes, then inserting the final data into the offersectionrelation_book
     * table
     * 
     * @param request
     *            The request from the client containing the file, sheet name to process, geo
     *            market, and zip code list
     * @param response
     *            Success if all of the records could be inserted into the table, otherwise an error
     *            message is displayed
     * @return The response to the client
     */
    @RequestMapping(value = "offerindexgenerator/uploadIndexGenerator.cmd", method = RequestMethod.POST, headers = "Accept=application/xml", produces = "application/json")
    public @ResponseBody
    EPIAdminToolResponse uploadIndexGenerator(MultipartHttpServletRequest request,
            HttpServletResponse response) {
        EPIAdminToolResponse ceResponse = new EPIAdminToolResponse();

        boolean isMultipartContent = ServletFileUpload.isMultipartContent(request);
        if (!isMultipartContent) {
            ceResponse.setResponseStatus("fail");
            ceResponse.setResponseMessage("You must upload a file");
            return ceResponse;
        }

        try {
            String sheetName = request.getParameter("sheetName");
            String geoMarket = request.getParameter("geoMarket");
            String zipCodes = request.getParameter("zipCodes");
            Iterator<String> it = request.getFileNames();

            while (it.hasNext()) {
                String fileName = it.next();
                MultipartFile file = request.getFile(fileName);
                InputStream is = file.getInputStream();
                is.toString();
                List<Map<String, Object>> records = readFile(is, sheetName);
                contentExtractOfferIndexGeneratorDao.clearEntityManager();
                contentExtractOfferIndexGeneratorDao.clearTempTable();
                contentExtractOfferIndexGeneratorDao.insertToTemp(records);
                List<ContentExtractOfferSectionRelationTemp> rs = contentExtractOfferIndexGeneratorDao
                        .getExistingData(geoMarket, zipCodes);
                records = setResults(rs, records);
                contentExtractOfferIndexGeneratorDao.removeExistingProducts(records);
                contentExtractOfferIndexGeneratorDao.insertToBook(records);
            }
        } catch (Exception ex) {
            ceResponse.setResponseStatus("fail");
            ceResponse.setResponseMessage(ex.getMessage());
            return ceResponse;
        }

        ceResponse.setResponseStatus("success");
        ceResponse.setResponseMessage("Your file has successfully been processed");
        return ceResponse;
    }

    /**
     * Sets the map entity in the relation map
     * 
     * @param key
     *            The key to set
     * @param value
     *            The value for the key
     */
    private void setValue(String key, Object value) {
        relationMap.put(key, value);
    }

    /**
     * Converts the value of the cell to a string and removes undesired characters
     * 
     * @param cell
     *            The Excel sheet cell containing the value
     * @return A string representation of the value without undesired characters
     */
    private static String getValue(XSSFCell cell) {
        String value = cell.toString();
        value.trim();
        value.replaceAll("$", "");
        value.replaceAll(",", "");
        int decimalPos = value.indexOf('.');
        if (decimalPos > -1) {
            value = value.substring(0, decimalPos);
        }
        return value;
    }

    /**
     * Creates and returns a new record from the combination of file data and database data Offer ID
     * and Product ID are obtained from the file, while all other fields are set using database
     * values
     * 
     * @param entry
     *            The record from the database query
     * @param fileRecord
     *            The record from the file
     * @return A new record containing the combination of data
     * @throws SQLException
     *             If there are any issues reading the result set
     */
    private static Map<String, Object> setNewRecord(ContentExtractOfferSectionRelationTemp entry,
            Map<String, Object> fileRecord) throws SQLException {
        Map<String, Object> newRecord = new HashMap<String, Object>();
        newRecord.put(offerId, fileRecord.get(offerId));
        newRecord.put(productId, fileRecord.get(productId));
        newRecord.put(offerPk, entry.getOfferPk());
        newRecord.put(folioNumber, entry.getFolioNumber());
        newRecord.put(redemptionLocationId, entry.getRedemptionLocationId());
        newRecord.put(version, entry.getVersion());
        return newRecord;
    }

    /**
     * Initializes the map to read the values from the excel workbook into the relation map
     */
    public OfferIndexGeneratorController() {
        excelFormatMap = new HashMap<Integer, String>();
        excelFormatMap.put(0, folioNumber);
        excelFormatMap.put(1, offerId);
        excelFormatMap.put(2, version);
        excelFormatMap.put(3, productId);

        relationMap = new HashMap<String, Object>();
    }

};
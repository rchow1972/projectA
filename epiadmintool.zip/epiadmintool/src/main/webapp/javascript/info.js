/*
 * File: contentextract.js
 * Purpose: Provide interaction to webservices for Content Extraction Admin Tool
 * Created By: Daniel Buckley 
 * And: Christian Vespa email: christian.vespa@silkrouteglobal.com
 */
$(document).ready(function() {
    // Fields

    // loading items
    var docHeight = $(document).height(); // gets doc size

    var opts = { // options for the loading spinner
        lines : 13, // The number of lines to draw
        length : 20, // The length of each line
        width : 10, // The line thickness
        radius : 30, // The radius of the inner circle
        corners : 1, // Corner roundness (0..1)
        rotate : 0, // The rotation offset
        direction : 1, // 1: clockwise, -1: counterclockwise
        color : '#000', // #rgb or #rrggbb or array of colors
        speed : 1, // Rounds per second
        trail : 100, // Afterglow percentage
        shadow : true, // Whether to render a shadow
        hwaccel : false, // Whether to use hardware acceleration
        className : 'spinner', // The CSS class to assign to the spinner
        zIndex : 2e9, // The z-index (defaults to 2000000000)
        top : 'auto', // Top position relative to parent in px
        left : 'auto' // Left position relative to parent in px
    };
    var spinner = new Spinner(opts); // the initial creation of the spinner

    var loading = function(value) { // the function to have a overlay and spinner well the database is being pulled for
                                    // information

        if (value === "start") {
            $("body").append("<div id='loading'></div><div id='overlay'></div>"); // adds the two divs just after the
                                                                                    // <body>

            var target = document.getElementById('loading');

            $("#overlay").height(docHeight);
            spinner.spin(target);
            return;
        }
        if (value === "stop") {
            spinner.stop();
            $("div[id=overlay]").remove(); // removes the two divs
            $("div[id=loading]").remove();
            return;
        }
    };

    // Web Service Calls
    
    // log4j call
    $('input[id=runLog4j]').click(function(event) {
        console.log("log4j call sent");

        loading("start");

        var url = "log4j.cmd";

        $.ajax({
            url : url,
            type : "GET",
            dataType : "json",
            complete : function(json) {
                console.log("Pass - Parse Data");
                loading("stop");
                $('input[id=log4j]').val(json.responseText);
            },
        });
    });
    
    // cacheStats call
    $('input[id=runCacheStats]').click(function(event) {
        console.log("cacheStats call sent");

        loading("start");

        var url = "cacheStats.cmd";

        $.ajax({
            url : url,
            type : "GET",
            dataType : "json",
            complete : function(json) {
                console.log("Pass - Parse Data");
                loading("stop");
                $('input[id=cacheStats]').val(json.responseText);
            },
        });
    });
    
    // testDb call
    $('input[id=runTestDb]').click(function(event) {
        console.log("testDb call sent");

        loading("start");

        var url = "testDb.cmd";

        $.ajax({
            url : url,
            type : "GET",
            dataType : "json",
            complete : function(json) {
                console.log("Pass - Parse Data");
                loading("stop");
                $('input[id=testDb]').val(json.responseText);
            },
        });
    });
    
    // break call
    $('input[id=runBreak]').click(function(event) {
        console.log("break call sent");

        loading("start");

        var url = "break.cmd";

        $.ajax({
            url : url,
            type : "GET",
            dataType : "json",
            complete : function(json) {
                console.log("Pass - Parse Data");
                loading("stop");
                $('input[id=break]').val(json.responseText);
            },
        });
    });
    
    // break2 call
    $('input[id=runBreak2]').click(function(event) {
        console.log("break2 call sent");

        loading("start");

        var url = "break2.cmd";

        $.ajax({
            url : url,
            type : "GET",
            dataType : "json",
            error : function(json) {
                console.log("Failed - Casue some User Broke the Data");
                loading("stop");
                alert("Hello, Im the Break Test 2 and ... looks like you really did break it. Hey go check the logs to see what you broke.");
            },
        });
    });
});
/*
 * File: login.js
 * Purpose: Provide User Authentication for EPI Admin tool 
 * Created By: Daniel Buckley 
 * And: Christian Vespa email: christian.vespa@silkrouteglobal.com
 */
$(document).ready(function() {

    var logout = function() { // function to call to remove a users session on the back-end
        var url = "/epiadmintool/logout.cmd";

        $.ajax({ // this is the actual ajax request call
            url : url, // the url where we want to POST
            type : "POST", // define the type of HTTP verb we want to use (POST for our form)
            dataType : "json", // what type of data do we expect back from the server
            error : function() { // this is ran if ajax returns is a fail, front-end failure
                console.log("Failed Logout - Parse Data");
                return; // return so nothing else is ran
            },
            success : function(json) { // this is ran if the ajax returns a success, front-end success
                if (json.responseStatus == "success") { // to check to see if our back-end failed but still sent an
                                                        // response
                    console.log("Pass - Logout - Parse Data");
                    $.removeCookie('username', {
                        path : '/'
                    }); // remove username from cookie list
                    $.removeCookie('password', {
                        path : '/'
                    }); // remove password from cookie list
                    window.location.href = '/epiadmintool/';
                    return;
                } else {
                    console.log("Fail - Logout - Parse Data");
                    alert(json.responseMessage);
                    return;
                }
            }
        });
    };

    var login = function(user, pass, auto) { // function to call to authenticate a users session on the back-end

        var url = "/epiadmintool/login.cmd";
        var formData = {
            username : user,
            password : pass
        };

        $.ajax({
            url : url,
            type : "POST",
            dataType : "json",
            data : formData, // our user data sent as a data object
            error : function() {
                console.log("Fail - Parse Data");
                return;
            },
            success : function(json) {
                if (json.responseStatus == "success") { // to check to see if our back-end failed but still sent an
                                                       // response
                    //console.log(json);
                    if (auto == "false") { // check to see if call was auto or user input
                        console.log("Pass - Login - Parse Data");
                        alert(user + ", You have successfully logged in.");
                        $("input[id=username]").val(''); // sets username to blank
                        $("input[id=password]").val(''); // sets password to blank
                    } else {
                        console.log("Pass - AutoLogin - Parse Data");
                    }
                    $("tbody[id=login-table-tbody]").append("<tr> <td align:'left' colspan='4' class='gray'>You are currently logged in as "
                            + user
                            + "</td> <td align:'left' class='gray'><input type='button' id='logout' value='Logout'></td> </tr>");
                    $("input[id=login]").prop('disabled', true); // disables so users can't append more row
                    $('input[id=logout]').click(function(event) { // gives function to the new logout button
                        logout();
                    });
                    if(json.permissionMap.CE_Mapping == "true"){
                        gotoContent();
                    }
                    if(json.permissionMap.RED_Reset == "true"){
                        gotoRedemption();
                    }
                    if(json.permissionMap.Offerldx_Generation == "true"){
                        gotoOfferIndex();
                    }
                    
                    //if(json.permissionMap.RED_Reset == "true"){
                    if(true){
                    	gotoCCProfile();
                    }

                    if(true){
                    	gotoGroupOrder();
                    }
                    
                    return;
                } else {
                    if (auto == "false") { // check to see if call was auto or user input
                        console.log("Fail - Login - Parse Data");
                        alert(json.responseMessage);
                        return;
                    } else {
                        console.log("Fail - AutoLogin - Parse Data");
                        return;
                    }
                }
            }
        });
    };
    
    var gotoContent = function(){
        $("input[id=gotoContent]").prop('disabled', false); // enables the use of button
        $("span[id=link-content]").click(function(event) { // gives function to the content link (span)
            window.location.href = '/epiadmintool/contentextract';
            return;
        });
    };
    
    var gotoRedemption = function(){
        $("input[id=gotoRedemption]").prop('disabled', false); // enables the use of button
        $("span[id=link-redempt]").click(function(event) { // gives function to the redempt link (span)
            window.location.href = '/epiadmintool/redemptionreset';
            return;
        });
    };
    
    var gotoOfferIndex = function(){
        $("input[id=gotoOfferIndex]").prop('disabled', false); // enables the use of button
        $("span[id=link-offer]").click(function(event) { // gives function to the redempt link (span)
            window.location.href = '/epiadmintool/offerindexgenerator';
            return;
        });
    };

    var gotoCCProfile = function(){
        $("input[id=gotoCCProfile]").prop('disabled', false); // enables the use of button
        $("span[id=link-profile]").click(function(event) { // gives function to the redempt link (span)
            window.location.href = '/epiadmintool/creditcardprofile';
            return;
        });
    };

    var gotoGroupOrder = function(){
        $("input[id=gotoGroupOrder]").prop('disabled', false); // enables the use of button
        $("span[id=link-group]").click(function(event) { // gives function to the redempt link (span)
            window.location.href = '/epiadmintool/grouporder';
            return;
        });
    };
    
    if ($.cookie('username') != null) { // Autologin if returning user
        console.log("Ready for autologin");
        login($.cookie('username'), $.cookie('password'), "true"); // run login function with auto as true
    }

    // login button
    $("input[id=login]").click(function(event) {

        var username = $('input[id=username]').val(); // pulling value from username input
        var password = $('input[id=password]').val(); // pulling value from password input

        $.cookie('username', username, {
            expires : 14,
            path : '/'
        }); // add username to site cookie list
        $.cookie('password', password, {
            expires : 14,
            path : '/'
        }); // add password to site cookie list

        login(username, password, "false"); // run login function with auto as false

    });
});
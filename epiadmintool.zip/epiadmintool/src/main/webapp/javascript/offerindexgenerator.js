// Created By Marika Wegiel email: marika.wegiel@silkrouteglobal.com
$(document).ready(function() { // when document is fully rendered
    var uploadForm = function(page) { // function to search the list of all user
        console.log('[log] offer index generation started');

        var fileInput = document.getElementById('fileUploadInput');
        var file = fileInput.files[0];
        var formData = new FormData();

        if (file == null){
            alert('Request failed please select a file to upload.');
            console.log('[error] Request failed please select a file to upload.');
            return;
        }

        formData.append('sheetName', $('input[name=sheetName]').val());
        formData.append('geoMarket', $('input[name=geoMarket]').val());
        formData.append('zipCodes', $('input[name=zipCodes]').val());
        formData.append('file', file);

        $.ajax({
            type : 'POST',
            url : 'uploadIndexGenerator.cmd',
            data : formData,
            dataType : 'json',
            cache : false,
            contentType : false,
            processData : false
        }).success(function(data) {
            if (data.responseStatus == "fail") {
                alert('Request Failed\n' + data.responseMessage);
                console.log('[error] Request Failed: ' + data.responseMessage);
                return;
            }
        }).error(function(data) {
            alert('Request failed please retry upload.');
            console.log('[error] Request failed please retry upload.');
            return;
        });
    };

    $('input[id=upload]').click(function(event) {
        uploadForm();
    });
    
    $('input[id=searchClear]').click(function(event) {
        $('form[id=generate-indexes-form]').each(function(){ // resets the form
            this.reset();
        });
    });
});
